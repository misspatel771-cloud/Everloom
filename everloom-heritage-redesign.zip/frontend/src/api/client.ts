import {
  Product,
  Enquiry,
  Order,
  Customer,
  Review,
  MarketOpportunity,
  PriceComparison,
  BuyerMatch,
  SustainabilityReport,
  User,
  ArtisanProfile
} from '../types';

const BASE_URL = '/api';

function getHeaders() {
  const token = localStorage.getItem('everloom_token') || 'everloom_token_artisan-u1';
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  };
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      ...getHeaders(),
      ...(options.headers || {})
    }
  });

  if (!res.ok) {
    let errMsg = `Request failed: ${res.status}`;
    try {
      const errObj = await res.json();
      if (errObj.error) errMsg = errObj.error;
    } catch {}
    throw new Error(errMsg);
  }

  return res.json();
}

export const api = {
  // Auth
  auth: {
    login: (credentials: { email: string; password: string }) =>
      request<{ token: string; user: User; artisanProfile?: ArtisanProfile }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials)
      }),
    register: (data: any) =>
      request<{ token: string; user: User; artisanProfile?: ArtisanProfile }>('/auth/register', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    getMe: () =>
      request<{ user: User; artisanProfile?: ArtisanProfile }>('/auth/me')
  },

  // Artisan
  artisan: {
    getProfile: () => request<{ user: User; profile: ArtisanProfile }>('/artisans/profile'),
    updateProfile: (data: Partial<ArtisanProfile>) =>
      request<{ message: string; profile: ArtisanProfile }>('/artisans/profile', {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    getById: (id: string) =>
      request<{ profile: ArtisanProfile; user: User | null; products: Product[] }>(`/artisans/${id}`)
  },

  // Products
  products: {
    list: (params?: { artisanId?: string; placement?: string; craftCategory?: string; search?: string }) => {
      const q = new URLSearchParams();
      if (params?.artisanId) q.append('artisanId', params.artisanId);
      if (params?.placement) q.append('placement', params.placement);
      if (params?.craftCategory) q.append('craftCategory', params.craftCategory);
      if (params?.search) q.append('search', params.search);
      return request<{ total: number; products: Product[] }>(`/products?${q.toString()}`);
    },
    get: (id: string) =>
      request<{ product: Product; artisan: any; reviews: Review[] }>(`/products/${id}`),
    create: (data: any) =>
      request<{ message: string; product: Product }>('/products', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    update: (id: string, data: any) =>
      request<{ message: string; product: Product }>(`/products/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    delete: (id: string) =>
      request<{ message: string }>(`/products/${id}`, { method: 'DELETE' }),
    updateStock: (id: string, data: { stockQuantity?: number; isAvailable?: boolean }) =>
      request<{ message: string; product: Product }>(`/products/${id}/stock`, {
        method: 'PATCH',
        body: JSON.stringify(data)
      })
  },

  // AI Catalogue
  catalogue: {
    getStatus: () =>
      request<{ geminiConfigured: boolean; model: string; features: string[] }>('/catalogue/status'),
    enhanceImage: (data: { imageUrl: string; filterMode?: string }) =>
      request<any>('/catalogue/ai/enhance-image', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    generate: (data: {
      rawName: string;
      craftCategory: string;
      artisanStory?: string;
      materials?: string[];
      region?: string;
      language?: string;
    }) =>
      request<any>('/catalogue/ai/generate', {
        method: 'POST',
        body: JSON.stringify(data)
      })
  },

  // Gallery & Marketplace
  gallery: {
    list: (params?: { craftCategory?: string; artisanId?: string }) => {
      const q = new URLSearchParams();
      if (params?.craftCategory) q.append('craftCategory', params.craftCategory);
      if (params?.artisanId) q.append('artisanId', params.artisanId);
      return request<{ total: number; galleryItems: any[] }>(`/gallery?${q.toString()}`);
    }
  },
  marketplace: {
    list: (params?: { category?: string; minPrice?: number; maxPrice?: number; search?: string; sortBy?: string }) => {
      const q = new URLSearchParams();
      if (params?.category) q.append('category', params.category);
      if (params?.minPrice) q.append('minPrice', String(params.minPrice));
      if (params?.maxPrice) q.append('maxPrice', String(params.maxPrice));
      if (params?.search) q.append('search', params.search);
      if (params?.sortBy) q.append('sortBy', params.sortBy);
      return request<{ total: number; products: Product[] }>(`/marketplace/products?${q.toString()}`);
    }
  },

  // Enquiries & Messages
  enquiries: {
    list: () => request<{ enquiries: Enquiry[] }>('/enquiries'),
    create: (data: {
      productId: string;
      buyerName: string;
      buyerEmail: string;
      buyerPhone?: string;
      message: string;
      quantityRequested?: number;
    }) =>
      request<{ message: string; enquiry: Enquiry }>('/enquiries', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    reply: (id: string, message: string, sender: 'artisan' | 'buyer' = 'artisan') =>
      request<{ message: string; reply: any }>(`/enquiries/${id}/reply`, {
        method: 'POST',
        body: JSON.stringify({ message, sender })
      })
  },

  // Orders
  orders: {
    list: () => request<{ orders: Order[] }>('/orders'),
    create: (data: {
      productId: string;
      variantName?: string;
      quantity: number;
      customerName: string;
      customerEmail: string;
      customerPhone?: string;
      shippingAddress: string;
      notes?: string;
    }) =>
      request<{ message: string; order: Order }>('/orders', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateStatus: (id: string, status: string, trackingNumber?: string) =>
      request<{ message: string; order: Order }>(`/orders/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status, trackingNumber })
      })
  },

  // Customers
  customers: {
    list: () => request<{ customers: Customer[] }>('/customers')
  },

  // Insights, Analytics & Sustainability
  insights: {
    get: () =>
      request<{
        artisanCraft: string;
        totalArtisanProducts: number;
        opportunities: MarketOpportunity[];
        priceComparisons: PriceComparison[];
        buyerMatches: BuyerMatch[];
      }>('/market-insights')
  },
  analytics: {
    get: () => request<any>('/analytics')
  },
  sustainability: {
    get: () => request<{ artisanStats: any; productBreakdown: any[]; sustainabilityPillars: any[] }>('/sustainability'),
    calculate: (data: { craftCategory: string; materials: string[]; weightKg?: number; shippingKm?: number }) =>
      request<SustainabilityReport>('/sustainability/calculate', {
        method: 'POST',
        body: JSON.stringify(data)
      })
  },

  // Reviews
  reviews: {
    list: (productId: string) => request<{ reviews: Review[] }>(`/reviews/${productId}`),
    create: (data: { productId: string; userName: string; rating: number; comment: string }) =>
      request<{ message: string; review: Review }>('/reviews', {
        method: 'POST',
        body: JSON.stringify(data)
      })
  }
};
