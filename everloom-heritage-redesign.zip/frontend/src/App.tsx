import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate, useParams } from 'react-router-dom';
import './i18n/index.ts';

import { Navbar } from './components/Navbar.tsx';
import { Footer } from './components/Footer.tsx';
import { ArtisanDashboardPage } from './pages/artisan/ArtisanDashboardPage.tsx';
import { MarketplacePage } from './pages/buyer/MarketplacePage.tsx';
import { DigitalArtGalleryPage } from './pages/buyer/DigitalArtGalleryPage.tsx';
import { ProductDetailPage } from './pages/buyer/ProductDetailPage.tsx';
import { LoginPage } from './pages/auth/LoginPage.tsx';
import { RegisterPage } from './pages/auth/RegisterPage.tsx';
import { EnquiryModal } from './components/modals/EnquiryModal.tsx';
import { OrderCheckoutModal } from './components/modals/OrderCheckoutModal.tsx';
import { Product } from './types';

function ProductDetailWrapper({
  onOpenEnquiryModal,
  onOpenOrderModal
}: {
  onOpenEnquiryModal: (p: Product) => void;
  onOpenOrderModal: (p: Product) => void;
}) {
  const { id } = useParams();
  const navigate = useNavigate();
  return (
    <ProductDetailPage
      productId={id}
      onOpenEnquiryModal={onOpenEnquiryModal}
      onOpenOrderModal={onOpenOrderModal}
      onBack={() => navigate(-1)}
    />
  );
}

export default function App() {
  const [currentRole, setCurrentRole] = useState<'artisan' | 'buyer'>('artisan');
  const [currentUser, setCurrentUser] = useState<any>({
    id: 'artisan-u1',
    name: 'Devendra Ansari',
    role: 'artisan'
  });

  // Global modals
  const [enquiryProduct, setEnquiryProduct] = useState<Product | null>(null);
  const [orderProduct, setOrderProduct] = useState<Product | null>(null);

  const handleSwitchRole = (role: 'artisan' | 'buyer') => {
    setCurrentRole(role);
  };

  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col bg-[#FAF7F2] text-[#241E19]">
        <Navbar currentRole={currentRole} onSwitchRole={handleSwitchRole} />

        <div className="flex-1">
          <Routes>
            {/* Primary Artisan Workflow Route */}
            <Route path="/" element={<ArtisanDashboardPage initialModule="overview" />} />
            <Route path="/artisan" element={<ArtisanDashboardPage initialModule="overview" />} />
            <Route path="/artisan/catalogue" element={<ArtisanDashboardPage initialModule="aiCatalogue" />} />
            <Route path="/artisan/inventory" element={<ArtisanDashboardPage initialModule="inventory" />} />
            <Route path="/artisan/orders" element={<ArtisanDashboardPage initialModule="orders" />} />
            <Route path="/artisan/customers" element={<ArtisanDashboardPage initialModule="customers" />} />
            <Route path="/artisan/products" element={<ArtisanDashboardPage initialModule="allProducts" />} />
            <Route path="/artisan/gallery" element={<ArtisanDashboardPage initialModule="gallery" />} />
            <Route path="/artisan/marketplace" element={<ArtisanDashboardPage initialModule="marketplace" />} />
            <Route path="/artisan/enquiries" element={<ArtisanDashboardPage initialModule="enquiries" />} />
            <Route path="/artisan/insights" element={<ArtisanDashboardPage initialModule="insights" />} />
            <Route path="/artisan/analytics" element={<ArtisanDashboardPage initialModule="analytics" />} />
            <Route path="/artisan/sustainability" element={<ArtisanDashboardPage initialModule="sustainability" />} />
            <Route path="/artisan/profile" element={<ArtisanDashboardPage initialModule="profile" />} />
            <Route path="/artisan/settings" element={<ArtisanDashboardPage initialModule="settings" />} />

            {/* Buyer Experiences */}
            <Route
              path="/marketplace"
              element={
                <MarketplacePage
                  onOpenProductDetail={(id) => window.location.assign(`/products/${id}`)}
                  onOpenEnquiryModal={(p) => setEnquiryProduct(p)}
                  onOpenOrderModal={(p) => setOrderProduct(p)}
                />
              }
            />
            <Route
              path="/gallery"
              element={
                <DigitalArtGalleryPage
                  onOpenProductDetail={(id) => window.location.assign(`/products/${id}`)}
                />
              }
            />
            <Route
              path="/products/:id"
              element={
                <ProductDetailWrapper
                  onOpenEnquiryModal={(p) => setEnquiryProduct(p)}
                  onOpenOrderModal={(p) => setOrderProduct(p)}
                />
              }
            />

            {/* Auth */}
            <Route path="/login" element={<LoginPage onLoginSuccess={setCurrentUser} />} />
            <Route path="/register" element={<RegisterPage onLoginSuccess={setCurrentUser} />} />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/artisan" replace />} />
          </Routes>
        </div>

        <Footer />

        {/* Global Modals */}
        {enquiryProduct && (
          <EnquiryModal
            product={enquiryProduct}
            onClose={() => setEnquiryProduct(null)}
          />
        )}
        {orderProduct && (
          <OrderCheckoutModal
            product={orderProduct}
            onClose={() => setOrderProduct(null)}
          />
        )}
      </div>
    </BrowserRouter>
  );
}
