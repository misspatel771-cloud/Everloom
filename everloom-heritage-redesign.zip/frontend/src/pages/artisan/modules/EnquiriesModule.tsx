import React, { useEffect, useState } from 'react';
import { MessageSquare, Send, Mail, Phone, Package, Clock, CheckCircle2, User, RefreshCw } from 'lucide-react';
import { api } from '../../../api/client.ts';
import { Enquiry } from '../../../types';

export const EnquiriesModule: React.FC = () => {
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedEnquiry, setSelectedEnquiry] = useState<Enquiry | null>(null);
  const [replyText, setReplyText] = useState('');
  const [sending, setSending] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const fetchEnquiries = async () => {
    try {
      setLoading(true);
      const res = await api.enquiries.list();
      setEnquiries(res.enquiries || []);
      if (res.enquiries && res.enquiries.length > 0 && !selectedEnquiry) {
        setSelectedEnquiry(res.enquiries[0]);
      }
    } catch (err) {
      console.error('Error fetching enquiries:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEnquiries();
  }, []);

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEnquiry || !replyText.trim()) return;

    try {
      setSending(true);
      const res = await api.enquiries.reply(selectedEnquiry.id, replyText.trim(), 'artisan');
      const updatedMessages = [...selectedEnquiry.messages, res.reply];
      const updatedEnquiry = { ...selectedEnquiry, messages: updatedMessages, status: 'replied' as const };

      setSelectedEnquiry(updatedEnquiry);
      setEnquiries(prev => prev.map(e => (e.id === selectedEnquiry.id ? updatedEnquiry : e)));
      setReplyText('');
      setFeedback('Reply sent to buyer successfully!');
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(`Failed to send reply: ${err.message}`);
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19]">
            Enquiries & Buyer Conversations
          </h2>
          <p className="text-xs text-[#7A6B5D] mt-1">
            Connect directly with potential buyers, interior designers, and boutique curators interested in your craft.
          </p>
        </div>
        <button
          onClick={fetchEnquiries}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-[#E8DFC8] text-xs font-semibold text-[#4A3E33] hover:bg-[#FAF7F2] transition-colors self-start"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Inbox</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-[#2D5A43]/10 border border-[#2D5A43]/30 text-[#2D5A43] text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>{feedback}</span>
        </div>
      )}

      {enquiries.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-[#E8DFC8]">
          <MessageSquare className="w-12 h-12 text-[#C8B8A6] mx-auto mb-3" />
          <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">No Enquiries Yet</h3>
          <p className="text-xs text-[#7A6B5D] mt-1">
            When buyers have questions about sizing, custom weaves, or bulk orders, their messages will arrive here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[640px]">
          {/* Inbox list */}
          <div className="lg:col-span-5 bg-white rounded-2xl border border-[#E8DFC8] overflow-y-auto p-4 space-y-2 shadow-sm">
            <span className="text-xs font-bold uppercase tracking-wider text-[#7A6B5D] block mb-2">
              Messages ({enquiries.length})
            </span>
            {enquiries.map(enq => {
              const isSelected = selectedEnquiry?.id === enq.id;
              const lastMsg = enq.messages[enq.messages.length - 1];

              return (
                <div
                  key={enq.id}
                  onClick={() => setSelectedEnquiry(enq)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#FAF7F2] border-[#B84A2A] shadow-sm ring-1 ring-[#B84A2A]/20'
                      : 'border-[#E8DFC8] hover:border-[#B84A2A]/40 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-[#241E19]">{enq.buyerName}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                      enq.status === 'open' ? 'bg-[#B84A2A]/10 text-[#B84A2A]' : 'bg-[#2D5A43]/10 text-[#2D5A43]'
                    }`}>
                      {enq.status}
                    </span>
                  </div>

                  <p className="text-[11px] font-medium text-[#7A6B5D] truncate mt-1">
                    Regarding: {enq.product?.title || 'Heritage Creation'}
                  </p>

                  <p className="text-xs text-[#5A4D42] line-clamp-2 mt-1.5 italic">
                    "{lastMsg?.message || 'Inquiry submitted'}"
                  </p>

                  <span className="text-[10px] text-[#A8988B] block mt-2">
                    {new Date(enq.updatedAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Active Conversation Thread */}
          {selectedEnquiry && (
            <div className="lg:col-span-7 bg-white rounded-2xl border border-[#E8DFC8] shadow-sm flex flex-col justify-between overflow-hidden">
              {/* Header */}
              <div className="p-4 border-b border-[#E8DFC8] bg-[#FAF7F2] flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-[#241E19] flex items-center gap-2">
                    <User className="w-4 h-4 text-[#B84A2A]" />
                    <span>{selectedEnquiry.buyerName}</span>
                  </h4>
                  <div className="flex items-center gap-3 text-[11px] text-[#7A6B5D] mt-0.5">
                    <span>{selectedEnquiry.buyerEmail}</span>
                    {selectedEnquiry.buyerPhone && <span>• {selectedEnquiry.buyerPhone}</span>}
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-[#7A6B5D] block">Requested Units</span>
                  <span className="text-xs font-bold text-[#B84A2A]">{selectedEnquiry.quantityRequested} piece(s)</span>
                </div>
              </div>

              {/* Message history */}
              <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#FCFBF8]">
                {selectedEnquiry.messages.map(msg => {
                  const isArtisan = msg.sender === 'artisan';
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isArtisan ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-md p-3.5 rounded-2xl text-xs leading-relaxed ${
                          isArtisan
                            ? 'bg-[#B84A2A] text-white rounded-tr-none'
                            : 'bg-white border border-[#E8DFC8] text-[#241E19] rounded-tl-none shadow-sm'
                        }`}
                      >
                        <span className="text-[10px] font-bold block mb-1 opacity-75">
                          {isArtisan ? 'You (Master Artisan)' : selectedEnquiry.buyerName}
                        </span>
                        <p>{msg.message}</p>
                      </div>
                      <span className="text-[10px] text-[#A8988B] mt-1 px-1">
                        {new Date(msg.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Reply box */}
              <form onSubmit={handleSendReply} className="p-4 border-t border-[#E8DFC8] bg-white flex items-center gap-2">
                <input
                  type="text"
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder="Type a thoughtful reply to the patron..."
                  className="flex-1 px-4 py-2.5 rounded-xl border border-[#D5C9B3] text-xs focus:outline-none focus:border-[#B84A2A]"
                />
                <button
                  type="submit"
                  disabled={sending || !replyText.trim()}
                  className="px-5 py-2.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold flex items-center gap-1.5 hover:bg-[#9E3A1C] disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send</span>
                </button>
              </form>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
