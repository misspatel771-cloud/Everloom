import { Request, Response } from 'express';
import { db } from '../repositories/db.ts';

export const getArtisanProfile = (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  let userId = 'artisan-u1';
  if (authHeader && authHeader.startsWith('Bearer everloom_token_')) {
    userId = authHeader.replace('Bearer everloom_token_', '').trim();
  }

  const user = db.findUserById(userId);
  const profile = db.findArtisanByUserId(userId);

  if (!profile) {
    return res.status(404).json({ error: 'Artisan profile not found' });
  }

  return res.json({
    user,
    profile
  });
};

export const updateArtisanProfile = (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  let userId = 'artisan-u1';
  if (authHeader && authHeader.startsWith('Bearer everloom_token_')) {
    userId = authHeader.replace('Bearer everloom_token_', '').trim();
  }

  const updated = db.createOrUpdateArtisanProfile(userId, req.body);
  return res.json({
    message: 'Profile updated successfully',
    profile: updated
  });
};

export const getArtisanById = (req: Request, res: Response) => {
  const { id } = req.params;
  const profile = db.findArtisanById(id);
  if (!profile) {
    return res.status(404).json({ error: 'Artisan not found' });
  }
  const user = db.findUserById(profile.userId);
  const products = db.getProducts({ artisanId: profile.id });

  return res.json({
    profile,
    user: user ? { id: user.id, name: user.name, avatarUrl: user.avatarUrl, phone: user.phone } : null,
    products
  });
};
