import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Sparkles,
  Upload,
  Image as ImageIcon,
  CheckCircle2,
  Sliders,
  FileText,
  Tag,
  DollarSign,
  Compass,
  ShoppingBag,
  Layers,
  ArrowRight,
  ArrowLeft,
  RefreshCw,
  Plus,
  Trash2,
  Info
} from 'lucide-react';
import { api } from '../../../api/client.ts';
import { Placement } from '../../../types';

interface AICatalogueModuleProps {
  onPublishSuccess?: (newProductId: string) => void;
}

export const AICatalogueModule: React.FC<AICatalogueModuleProps> = ({ onPublishSuccess }) => {
  const { t, i18n } = useTranslation();

  // Step tracker (1 to 6)
  const [currentStep, setCurrentStep] = useState<number>(1);

  // Step A: Image
  const [imageUrl, setImageUrl] = useState<string>(
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=80'
  );
  const [sampleSelected, setSampleSelected] = useState<string>('banarasi');

  // Step B: Enhancement
  const [filterMode, setFilterMode] = useState<'studio_clean' | 'warm_heritage' | 'natural_daylight' | 'high_contrast'>('studio_clean');
  const [enhancing, setEnhancing] = useState<boolean>(false);
  const [enhancementResult, setEnhancementResult] = useState<any>(null);
  const [showEnhancedPreview, setShowEnhancedPreview] = useState<boolean>(true);

  // Step C: AI Generation Inputs & Outputs
  const [rawCraftName, setRawCraftName] = useState<string>('Banarasi Zari Mulberry Silk Dupatta');
  const [craftCategory, setCraftCategory] = useState<string>('Handloom & Textiles');
  const [rawArtisanStory, setRawArtisanStory] = useState<string>('Pit-loom woven by Devendra Ansari in Kotwa, Varanasi. 18 days of manual hand-interlocking.');
  const [generating, setGenerating] = useState<boolean>(false);
  const [language, setLanguage] = useState<'en' | 'hi' | 'mr'>((i18n.language as any) || 'en');

  // Generated & Editable Form Fields
  const [title, setTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [artisanStory, setArtisanStory] = useState<string>('');
  const [materials, setMaterials] = useState<string>('Pure Mulberry Silk, Natural Gold Zari, Organic Indigo Dye');
  const [tags, setTags] = useState<string>('handloom, banarasi, kadwa, sustainable, heritage, silk');
  const [careInstructions, setCareInstructions] = useState<string>('Dry clean only. Wrap in unbleached muslin cloth with neem leaves.');
  const [suggestedPriceRange, setSuggestedPriceRange] = useState<any>(null);
  const [aiServiceUsed, setAiServiceUsed] = useState<string>('');

  // Step D: Commercial Details & Variants
  const [price, setPrice] = useState<number>(6450);
  const [comparePrice, setComparePrice] = useState<number>(8500);
  const [stockQuantity, setStockQuantity] = useState<number>(4);
  const [dimensions, setDimensions] = useState<string>('2.5m x 0.9m');
  const [weightGrams, setWeightGrams] = useState<number>(320);
  const [variants, setVariants] = useState<Array<{ name: string; sku: string; price: number; stock: number }>>([
    { name: 'Royal Crimson & Gold', sku: 'BAN-KAD-CRM', price: 6450, stock: 2 },
    { name: 'Midnight Indigo & Silver', sku: 'BAN-KAD-IND', price: 6450, stock: 2 }
  ]);

  // Step E: Placement
  const [placement, setPlacement] = useState<Placement>('both');

  // Step F: Publishing status
  const [publishing, setPublishing] = useState<boolean>(false);
  const [publishedProduct, setPublishedProduct] = useState<any>(null);

  // Sample genuine artisan crafts for quick testing
  const sampleCrafts = [
    {
      id: 'banarasi',
      name: 'Banarasi Kadwa Dupatta',
      category: 'Handloom & Textiles',
      url: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=80',
      story: 'Woven on a pit-loom in Kotwa, Varanasi with pure Katan silk and gold zari.'
    },
    {
      id: 'terracotta',
      name: 'Riverbed Earthen Water Urn',
      category: 'Terracotta & Pottery',
      url: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=900&auto=format&fit=crop&q=80',
      story: 'River silt collected after monsoon in Gorakhpur, hand-turned and firewood fired.'
    },
    {
      id: 'madhubani',
      name: 'Kalpavriksha Tree of Life Painting',
      category: 'Folk & Tribal Painting',
      url: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=900&auto=format&fit=crop&q=80',
      story: 'Painted with bamboo twigs and turmeric and lampblack dyes on handmade paper in Madhubani.'
    },
    {
      id: 'dhokra',
      name: 'Lost-Wax Dhokra Brass Nandi',
      category: 'Metalcraft & Dhokra',
      url: 'https://images.unsplash.com/photo-1590736969955-71cc94801759?w=900&auto=format&fit=crop&q=80',
      story: 'Ancient 4000-year-old lost wax bell metal casting method from Bastar, Chhattisgarh.'
    }
  ];

  const handleSelectSample = (sample: typeof sampleCrafts[0]) => {
    setSampleSelected(sample.id);
    setImageUrl(sample.url);
    setRawCraftName(sample.name);
    setCraftCategory(sample.category);
    setRawArtisanStory(sample.story);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageUrl(reader.result as string);
        setSampleSelected('');
      };
      reader.readAsDataURL(file);
    }
  };

  // Step B: Trigger AI Enhancement
  const handleEnhanceImage = async () => {
    try {
      setEnhancing(true);
      const res = await api.catalogue.enhanceImage({ imageUrl, filterMode });
      setEnhancementResult(res);
    } catch (err: any) {
      alert(`Image enhancement failed: ${err.message}`);
    } finally {
      setEnhancing(false);
    }
  };

  // Step C: Trigger AI Catalogue Content Generation
  const handleGenerateContent = async () => {
    try {
      setGenerating(true);
      const res = await api.catalogue.generate({
        rawName: rawCraftName,
        craftCategory,
        artisanStory: rawArtisanStory,
        materials: materials.split(',').map(m => m.trim()),
        region: 'Varanasi, India',
        language
      });

      setTitle(res.title);
      setDescription(res.description);
      setArtisanStory(res.artisanStory);
      if (res.materials?.length) setMaterials(res.materials.join(', '));
      if (res.tags?.length) setTags(res.tags.join(', '));
      setCareInstructions(res.careInstructions);
      setSuggestedPriceRange(res.suggestedPriceRange);
      setAiServiceUsed(res.serviceUsed);

      if (res.suggestedPriceRange?.min && (!price || price === 0)) {
        setPrice(res.suggestedPriceRange.min);
      }
    } catch (err: any) {
      alert(`AI Catalogue generation failed: ${err.message}`);
    } finally {
      setGenerating(false);
    }
  };

  // Step D: Add Variant
  const handleAddVariant = () => {
    setVariants(prev => [
      ...prev,
      {
        name: `Edition ${prev.length + 1}`,
        sku: `SKU-${Date.now().toString().slice(-4)}`,
        price: price,
        stock: 2
      }
    ]);
  };

  const handleRemoveVariant = (index: number) => {
    setVariants(prev => prev.filter((_, i) => i !== index));
  };

  // Step F: Publish to Backend
  const handlePublish = async () => {
    try {
      setPublishing(true);
      const payload = {
        title: title || rawCraftName,
        description: description || 'Masterfully handcrafted using generational techniques.',
        artisanStory: artisanStory || rawArtisanStory,
        craftCategory: craftCategory,
        materials: materials.split(',').map(m => m.trim()),
        careInstructions,
        tags: tags.split(',').map(t => t.trim()),
        price: Number(price),
        comparePrice: comparePrice ? Number(comparePrice) : undefined,
        stockQuantity: Number(stockQuantity),
        isAvailable: true,
        placement: placement,
        images: [imageUrl],
        dimensions,
        weightGrams: Number(weightGrams),
        variants: variants
      };

      const res = await api.products.create(payload);
      setPublishedProduct(res.product);
      if (onPublishSuccess) {
        onPublishSuccess(res.product.id);
      }
    } catch (err: any) {
      alert(`Publishing failed: ${err.message}`);
    } finally {
      setPublishing(false);
    }
  };

  // If already published in this session
  if (publishedProduct) {
    return (
      <div className="bg-white rounded-3xl p-8 sm:p-12 border border-[#E8DFC8] shadow-xl text-center max-w-2xl mx-auto space-y-6">
        <div className="w-16 h-16 rounded-full bg-[#2D5A43]/10 text-[#2D5A43] flex items-center justify-center mx-auto ring-8 ring-[#2D5A43]/5">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div>
          <span className="text-xs font-bold uppercase tracking-widest text-[#B84A2A]">
            Successfully Published to Everloom
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif-heritage text-[#241E19] mt-1">
            "{publishedProduct.title}" is Live!
          </h2>
          <p className="text-xs text-[#7A6B5D] mt-2 max-w-md mx-auto">
            Your creation has been persisted and catalogued with verifiable low-carbon credentials and is now discoverable in{' '}
            <strong className="text-[#241E19]">
              {publishedProduct.placement === 'both' ? 'Both Digital Gallery & Marketplace' : publishedProduct.placement === 'gallery' ? 'Digital Art Gallery' : 'Buyer Marketplace'}
            </strong>.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-[#FAF7F2] border border-[#E8DFC8] flex items-center gap-4 text-left">
          <img
            src={publishedProduct.images[0]}
            alt={publishedProduct.title}
            className="w-16 h-16 rounded-xl object-cover border border-[#E8DFC8]"
          />
          <div className="flex-1">
            <span className="text-[10px] uppercase font-bold text-[#8E3015]">{publishedProduct.craftCategory}</span>
            <h4 className="font-bold text-sm text-[#241E19] line-clamp-1">{publishedProduct.title}</h4>
            <div className="flex items-center gap-3 text-xs mt-1">
              <span className="font-bold text-[#B84A2A]">₹{publishedProduct.price.toLocaleString('en-IN')}</span>
              <span className="text-[#2D5A43] font-semibold">Eco Score: {publishedProduct.ecoScore}/100</span>
              <span className="text-[#7A6B5D]">{publishedProduct.stockQuantity} units available</span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
          <button
            onClick={() => {
              setPublishedProduct(null);
              setCurrentStep(1);
              setTitle('');
              setDescription('');
            }}
            className="px-6 py-2.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C]"
          >
            Create Another Catalogue
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Studio Header */}
      <div>
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-[#B84A2A]/10 text-[#B84A2A] border border-[#B84A2A]/20">
            Everloom AI Studio
          </span>
          <span className="text-xs text-[#7A6B5D]">• Smart Multi-Modal Cataloguing Engine</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold font-serif-heritage text-[#241E19] mt-1">
          {t('studio.title')}
        </h2>
        <p className="text-xs text-[#7A6B5D] mt-1 max-w-2xl leading-relaxed">
          {t('studio.subtitle')}
        </p>
      </div>

      {/* 6-Step Visual Process Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {[
          { num: 1, label: t('studio.steps.upload'), icon: Upload },
          { num: 2, label: t('studio.steps.enhance'), icon: Sliders },
          { num: 3, label: t('studio.steps.generate'), icon: FileText },
          { num: 4, label: t('studio.steps.details'), icon: DollarSign },
          { num: 5, label: t('studio.steps.placement'), icon: Layers },
          { num: 6, label: t('studio.steps.preview'), icon: CheckCircle2 }
        ].map(step => {
          const isDone = currentStep > step.num;
          const isCurrent = currentStep === step.num;
          const Icon = step.icon;
          return (
            <button
              key={step.num}
              onClick={() => setCurrentStep(step.num)}
              className={`p-3 rounded-xl border text-left transition-all ${
                isCurrent
                  ? 'bg-[#B84A2A] text-white border-[#B84A2A] shadow-sm'
                  : isDone
                  ? 'bg-white text-[#2D5A43] border-[#2D5A43]/30 hover:bg-[#FAF7F2]'
                  : 'bg-white text-[#7A6B5D] border-[#E8DFC8] opacity-70'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">Step 0{step.num}</span>
                <Icon className="w-3.5 h-3.5" />
              </div>
              <p className="text-xs font-bold line-clamp-1">{step.label}</p>
            </button>
          );
        })}
      </div>

      {/* STEP 1: Upload Product Image */}
      {currentStep === 1 && (
        <div className="bg-white rounded-2xl border border-[#E8DFC8] p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">
              Step 1: Upload Handmade Product Photo
            </h3>
            <p className="text-xs text-[#7A6B5D] mt-1">
              Upload a clear photo of your handmade creation, or select from sample artisan records below.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            {/* Upload Zone */}
            <div className="md:col-span-7">
              <label className="border-2 border-dashed border-[#D5C9B3] hover:border-[#B84A2A] rounded-2xl p-8 flex flex-col items-center justify-center text-center cursor-pointer bg-[#FAF7F2] transition-colors group">
                <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                <div className="w-14 h-14 rounded-full bg-[#EFE7DC] group-hover:bg-[#B84A2A]/10 text-[#B84A2A] flex items-center justify-center transition-colors mb-3">
                  <Upload className="w-6 h-6" />
                </div>
                <span className="font-bold text-sm text-[#241E19]">Click to browse image or drag photo here</span>
                <span className="text-xs text-[#7A6B5D] mt-1">Supports JPG, PNG, WEBP from your phone or camera</span>
              </label>

              {/* Sample Craft Selectors */}
              <div className="mt-4 space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#7A6B5D]">
                  Or choose a traditional craft sample:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {sampleCrafts.map(sample => (
                    <button
                      key={sample.id}
                      onClick={() => handleSelectSample(sample)}
                      className={`p-2.5 rounded-xl border text-left text-xs transition-all flex items-center gap-2.5 ${
                        sampleSelected === sample.id
                          ? 'border-[#B84A2A] bg-[#B84A2A]/5 text-[#8E3015] font-bold'
                          : 'border-[#E8DFC8] hover:bg-[#FAF7F2] text-[#4A3E33]'
                      }`}
                    >
                      <img src={sample.url} alt={sample.name} className="w-9 h-9 rounded-lg object-cover" />
                      <div className="overflow-hidden">
                        <span className="block truncate">{sample.name}</span>
                        <span className="text-[10px] text-[#7A6B5D] block truncate">{sample.category}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Current Image Preview */}
            <div className="md:col-span-5 text-center">
              <div className="aspect-square rounded-2xl overflow-hidden border border-[#E8DFC8] bg-[#FAF7F2] shadow-sm relative">
                <img src={imageUrl} alt="Current upload" className="w-full h-full object-cover" />
                <div className="absolute bottom-3 left-3 right-3 bg-black/60 backdrop-blur-md rounded-xl p-2 text-white text-[11px] text-left">
                  <span className="font-bold block truncate">{rawCraftName}</span>
                  <span className="text-[10px] text-[#D5C9B3]">{craftCategory}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-[#E8DFC8]">
            <button
              onClick={() => {
                handleEnhanceImage();
                setCurrentStep(2);
              }}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C]"
            >
              <span>Continue to Image Studio</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Image Enhancement Studio */}
      {currentStep === 2 && (
        <div className="bg-white rounded-2xl border border-[#E8DFC8] p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">
              Step 2: AI Photography Enhancement & Analysis
            </h3>
            <p className="text-xs text-[#7A6B5D] mt-1">
              Optimize lighting, clarify intricate textures, and extract authentic craft color palettes for exhibition.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Filter modes and critiques */}
            <div className="lg:col-span-5 space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#7A6B5D] mb-2">
                  Select Enhancement Grade:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'studio_clean', name: 'Studio Clean', desc: 'Neutral gallery daylight' },
                    { id: 'warm_heritage', name: 'Warm Heritage', desc: 'Sandalwood & amber tones' },
                    { id: 'natural_daylight', name: 'Natural Daylight', desc: 'Morning courtyard sun' },
                    { id: 'high_contrast', name: 'Contrast Clarity', desc: 'Intense weave texture' }
                  ].map(f => (
                    <button
                      key={f.id}
                      onClick={() => {
                        setFilterMode(f.id as any);
                        handleEnhanceImage();
                      }}
                      className={`p-3 rounded-xl border text-left text-xs transition-all ${
                        filterMode === f.id
                          ? 'border-[#B84A2A] bg-[#B84A2A]/5 text-[#8E3015] font-bold'
                          : 'border-[#E8DFC8] hover:bg-[#FAF7F2] text-[#4A3E33]'
                      }`}
                    >
                      <span className="block">{f.name}</span>
                      <span className="text-[10px] text-[#7A6B5D] font-normal block">{f.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Extracted Craft Palette */}
              {enhancementResult?.palette && (
                <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] space-y-2">
                  <span className="text-xs font-bold text-[#3A2E24] uppercase tracking-wider block">
                    Extracted Heritage Color Palette:
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    {enhancementResult.palette.map((c: any, i: number) => (
                      <div key={i} className="flex items-center gap-2 p-1.5 rounded-lg bg-white border border-[#E8DFC8]">
                        <div className="w-6 h-6 rounded-md shrink-0 border border-black/10" style={{ backgroundColor: c.hex }} />
                        <div className="text-[11px] overflow-hidden">
                          <span className="font-semibold block truncate">{c.name}</span>
                          <span className="text-[10px] text-[#7A6B5D]">{c.hex}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* AI Photography Recommendations */}
              {enhancementResult?.critiqueAndRecommendations && (
                <div className="p-4 rounded-xl bg-[#FFFBF0] border border-[#F3E1B8] text-xs space-y-1.5">
                  <span className="font-bold text-[#8A5E12] uppercase tracking-wider block">
                    AI Studio Photography Critique:
                  </span>
                  <ul className="list-disc list-inside space-y-1 text-[#7A5B20]">
                    {enhancementResult.critiqueAndRecommendations.slice(0, 3).map((tip: string, i: number) => (
                      <li key={i}>{tip}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Live Visual Preview with Toggle */}
            <div className="lg:col-span-7 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#7A6B5D]">Visual Comparison</span>
                <div className="flex items-center gap-1 bg-[#FAF7F2] p-1 rounded-lg border border-[#E8DFC8]">
                  <button
                    onClick={() => setShowEnhancedPreview(false)}
                    className={`px-3 py-1 rounded text-xs font-semibold ${!showEnhancedPreview ? 'bg-white shadow-sm text-[#241E19]' : 'text-[#7A6B5D]'}`}
                  >
                    Original
                  </button>
                  <button
                    onClick={() => setShowEnhancedPreview(true)}
                    className={`px-3 py-1 rounded text-xs font-semibold ${showEnhancedPreview ? 'bg-[#B84A2A] text-white shadow-sm' : 'text-[#7A6B5D]'}`}
                  >
                    AI Enhanced Preview
                  </button>
                </div>
              </div>

              <div className="aspect-4/3 rounded-2xl overflow-hidden border border-[#E8DFC8] bg-[#FAF7F2] relative">
                <img
                  src={imageUrl}
                  alt="Enhanced view"
                  className={`w-full h-full object-cover transition-all duration-300 ${
                    showEnhancedPreview
                      ? filterMode === 'warm_heritage'
                        ? 'brightness-105 contrast-105 sepia-[0.15]'
                        : filterMode === 'natural_daylight'
                        ? 'brightness-110 contrast-100 saturate-110'
                        : filterMode === 'high_contrast'
                        ? 'contrast-125 saturate-115'
                        : 'brightness-105 contrast-110'
                      : ''
                  }`}
                />
                <div className="absolute top-3 left-3 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-black/60 backdrop-blur-md text-white">
                  {showEnhancedPreview ? `Mode: ${filterMode.replace('_', ' ')}` : 'Original Unprocessed'}
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-[#E8DFC8]">
            <button
              onClick={() => setCurrentStep(1)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-[#D5C9B3] text-xs font-semibold text-[#4A3E33]"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Upload</span>
            </button>
            <button
              onClick={() => {
                if (!title) handleGenerateContent();
                setCurrentStep(3);
              }}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C]"
            >
              <span>Continue to AI Story & Content</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: AI Catalogue Generation (Editable) */}
      {currentStep === 3 && (
        <div className="bg-white rounded-2xl border border-[#E8DFC8] p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">
                Step 3: AI Catalogue Story & Metadata
              </h3>
              <p className="text-xs text-[#7A6B5D] mt-1">
                Generate and edit rich product titles, provenance stories, keywords, and care guidelines.
              </p>
            </div>

            <div className="flex items-center gap-2 self-start">
              {/* Language Selector */}
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as any)}
                className="px-3 py-1.5 rounded-xl border border-[#D5C9B3] text-xs font-semibold bg-[#FAF7F2]"
              >
                <option value="en">English</option>
                <option value="hi">हिन्दी (Hindi)</option>
                <option value="mr">मराठी (Marathi)</option>
              </select>

              <button
                onClick={handleGenerateContent}
                disabled={generating}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C] disabled:opacity-50"
              >
                {generating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                <span>{generating ? 'Generating...' : 'Regenerate Content'}</span>
              </button>
            </div>
          </div>

          {aiServiceUsed && (
            <div className="p-2.5 rounded-xl bg-[#2D5A43]/10 border border-[#2D5A43]/30 text-[11px] text-[#2D5A43] font-semibold flex items-center justify-between">
              <span>Engine: {aiServiceUsed === 'gemini-3.8-flash' ? 'Google Gemini 3.8 Flash' : 'Everloom Traditional Craft Rules Engine'}</span>
              <span>All fields below are fully editable</span>
            </div>
          )}

          {/* Editable AI generated fields */}
          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-[#3A2E24] mb-1">Product Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Compelling product title..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3] font-semibold text-sm focus:outline-none focus:border-[#B84A2A]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#3A2E24] mb-1">Product Description</label>
              <textarea
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Tactile, sensual description of craft..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3] leading-relaxed focus:outline-none focus:border-[#B84A2A]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#3A2E24] mb-1">Artisan Heritage & Provenance Story</label>
              <textarea
                rows={3}
                value={artisanStory}
                onChange={(e) => setArtisanStory(e.target.value)}
                placeholder="Generational story behind this creation..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3] leading-relaxed focus:outline-none focus:border-[#B84A2A]"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#3A2E24] mb-1">Craft Category</label>
                <select
                  value={craftCategory}
                  onChange={(e) => setCraftCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
                >
                  <option value="Handloom & Textiles">Handloom & Textiles</option>
                  <option value="Terracotta & Pottery">Terracotta & Pottery</option>
                  <option value="Folk & Tribal Painting">Folk & Tribal Painting</option>
                  <option value="Metalcraft & Dhokra">Metalcraft & Dhokra</option>
                  <option value="Woodcraft & Carving">Woodcraft & Carving</option>
                  <option value="Leather Craft">Leather Craft</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-[#3A2E24] mb-1">Materials (comma separated)</label>
                <input
                  type="text"
                  value={materials}
                  onChange={(e) => setMaterials(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#3A2E24] mb-1">Care & Preservation Instructions</label>
                <input
                  type="text"
                  value={careInstructions}
                  onChange={(e) => setCareInstructions(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#3A2E24] mb-1">Keywords & Search Tags (comma separated)</label>
                <input
                  type="text"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-[#E8DFC8]">
            <button
              onClick={() => setCurrentStep(2)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-[#D5C9B3] text-xs font-semibold text-[#4A3E33]"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Image Studio</span>
            </button>
            <button
              onClick={() => setCurrentStep(4)}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C]"
            >
              <span>Continue to Stock & Variants</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: Commercial Details & Variants */}
      {currentStep === 4 && (
        <div className="bg-white rounded-2xl border border-[#E8DFC8] p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">
              Step 4: Pricing, Inventory Stock & Variants
            </h3>
            <p className="text-xs text-[#7A6B5D] mt-1">
              Configure fair artisan prices, stock counts, physical dimensions, and color/size variants.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-bold text-[#3A2E24] mb-1">Artisan Price (₹)</label>
              <input
                type="number"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3] font-bold text-sm"
              />
              <span className="text-[10px] text-[#7A6B5D] mt-1 block">What the buyer pays</span>
            </div>

            <div>
              <label className="block font-bold text-[#3A2E24] mb-1">Comparable Market Price (₹)</label>
              <input
                type="number"
                value={comparePrice}
                onChange={(e) => setComparePrice(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
              />
              <span className="text-[10px] text-[#7A6B5D] mt-1 block">Typical luxury retail benchmark</span>
            </div>

            <div>
              <label className="block font-bold text-[#3A2E24] mb-1">Available Stock Units</label>
              <input
                type="number"
                value={stockQuantity}
                onChange={(e) => setStockQuantity(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3] font-bold"
              />
              <span className="text-[10px] text-[#7A6B5D] mt-1 block">Physical pieces ready to dispatch</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-bold text-[#3A2E24] mb-1">Dimensions</label>
              <input
                type="text"
                value={dimensions}
                onChange={(e) => setDimensions(e.target.value)}
                placeholder="e.g. 2.5m x 0.9m or 30cm height"
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
              />
            </div>
            <div>
              <label className="block font-bold text-[#3A2E24] mb-1">Weight (Grams)</label>
              <input
                type="number"
                value={weightGrams}
                onChange={(e) => setWeightGrams(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
              />
            </div>
          </div>

          {/* Variants section */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-[#7A6B5D]">
                Product Variants (Colors / Sizes / Editions)
              </span>
              <button
                onClick={handleAddVariant}
                className="flex items-center gap-1 text-xs font-bold text-[#B84A2A] hover:underline"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Variant</span>
              </button>
            </div>

            <div className="space-y-2">
              {variants.map((v, i) => (
                <div key={i} className="flex flex-col sm:flex-row items-center gap-2 p-3 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] text-xs">
                  <input
                    type="text"
                    value={v.name}
                    onChange={(e) => {
                      const next = [...variants];
                      next[i].name = e.target.value;
                      setVariants(next);
                    }}
                    placeholder="Variant name"
                    className="flex-1 px-3 py-1.5 rounded-lg border border-[#D5C9B3] bg-white"
                  />
                  <input
                    type="text"
                    value={v.sku}
                    onChange={(e) => {
                      const next = [...variants];
                      next[i].sku = e.target.value;
                      setVariants(next);
                    }}
                    placeholder="SKU"
                    className="w-28 px-3 py-1.5 rounded-lg border border-[#D5C9B3] bg-white"
                  />
                  <input
                    type="number"
                    value={v.price}
                    onChange={(e) => {
                      const next = [...variants];
                      next[i].price = Number(e.target.value);
                      setVariants(next);
                    }}
                    placeholder="Price"
                    className="w-24 px-3 py-1.5 rounded-lg border border-[#D5C9B3] bg-white"
                  />
                  <input
                    type="number"
                    value={v.stock}
                    onChange={(e) => {
                      const next = [...variants];
                      next[i].stock = Number(e.target.value);
                      setVariants(next);
                    }}
                    placeholder="Stock"
                    className="w-20 px-3 py-1.5 rounded-lg border border-[#D5C9B3] bg-white"
                  />
                  <button
                    onClick={() => handleRemoveVariant(i)}
                    className="p-1.5 text-[#9E2A2B] hover:bg-[#FFF5F5] rounded-lg"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-[#E8DFC8]">
            <button
              onClick={() => setCurrentStep(3)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-[#D5C9B3] text-xs font-semibold text-[#4A3E33]"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Content</span>
            </button>
            <button
              onClick={() => setCurrentStep(5)}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C]"
            >
              <span>Continue to Placement</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 5: Catalogue Placement */}
      {currentStep === 5 && (
        <div className="bg-white rounded-2xl border border-[#E8DFC8] p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">
              Step 5: Select Catalogue Placement Destination
            </h3>
            <p className="text-xs text-[#7A6B5D] mt-1">
              Select exactly one placement according to where your creation should be displayed.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Gallery Choice */}
            <div
              onClick={() => setPlacement('gallery')}
              className={`p-6 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                placement === 'gallery'
                  ? 'border-[#B84A2A] bg-[#B84A2A]/5 shadow-md ring-2 ring-[#B84A2A]/20'
                  : 'border-[#E8DFC8] hover:border-[#B84A2A]/40 bg-white'
              }`}
            >
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-xl bg-[#FAF0E6] text-[#B84A2A] flex items-center justify-center">
                  <Compass className="w-6 h-6" />
                </div>
                <h4 className="font-serif-heritage font-bold text-lg text-[#241E19]">My Gallery</h4>
                <p className="text-xs text-[#6A5D52] leading-relaxed">
                  Exhibition-only display focusing on high-resolution photography, artisan lineage, and cultural storytelling without commercial instant checkout.
                </p>
              </div>
              <div className="pt-4 mt-4 border-t border-[#E8DFC8] flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#7A6B5D]">API: "gallery"</span>
                {placement === 'gallery' && <CheckCircle2 className="w-5 h-5 text-[#B84A2A]" />}
              </div>
            </div>

            {/* Marketplace Choice */}
            <div
              onClick={() => setPlacement('marketplace')}
              className={`p-6 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                placement === 'marketplace'
                  ? 'border-[#B84A2A] bg-[#B84A2A]/5 shadow-md ring-2 ring-[#B84A2A]/20'
                  : 'border-[#E8DFC8] hover:border-[#B84A2A]/40 bg-white'
              }`}
            >
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-xl bg-[#EEF7F2] text-[#2D5A43] flex items-center justify-center">
                  <ShoppingBag className="w-6 h-6" />
                </div>
                <h4 className="font-serif-heritage font-bold text-lg text-[#241E19]">Marketplace</h4>
                <p className="text-xs text-[#6A5D52] leading-relaxed">
                  Direct buyer-facing commerce listing with instant ordering, cart, enquiry messaging, price comparisons, and shipping fulfillment.
                </p>
              </div>
              <div className="pt-4 mt-4 border-t border-[#E8DFC8] flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#7A6B5D]">API: "marketplace"</span>
                {placement === 'marketplace' && <CheckCircle2 className="w-5 h-5 text-[#B84A2A]" />}
              </div>
            </div>

            {/* Both Choice */}
            <div
              onClick={() => setPlacement('both')}
              className={`p-6 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                placement === 'both'
                  ? 'border-[#B84A2A] bg-[#B84A2A]/5 shadow-md ring-2 ring-[#B84A2A]/20'
                  : 'border-[#E8DFC8] hover:border-[#B84A2A]/40 bg-white'
              }`}
            >
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-xl bg-[#EBF3FB] text-[#25416B] flex items-center justify-center">
                  <Layers className="w-6 h-6" />
                </div>
                <h4 className="font-serif-heritage font-bold text-lg text-[#241E19]">Both Destinations</h4>
                <p className="text-xs text-[#6A5D52] leading-relaxed">
                  Full dual-presence: Featured in curated Digital Gallery exhibitions and simultaneously purchasable on the active Buyer Marketplace.
                </p>
              </div>
              <div className="pt-4 mt-4 border-t border-[#E8DFC8] flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#7A6B5D]">API: "both"</span>
                {placement === 'both' && <CheckCircle2 className="w-5 h-5 text-[#B84A2A]" />}
              </div>
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-[#E8DFC8]">
            <button
              onClick={() => setCurrentStep(4)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-[#D5C9B3] text-xs font-semibold text-[#4A3E33]"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Details</span>
            </button>
            <button
              onClick={() => setCurrentStep(6)}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C]"
            >
              <span>Continue to Final Preview</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 6: Final Review & Publish */}
      {currentStep === 6 && (
        <div className="bg-white rounded-2xl border border-[#E8DFC8] p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">
              Step 6: Review & Instant Publish
            </h3>
            <p className="text-xs text-[#7A6B5D] mt-1">
              Verify your finished catalogue card below before persisting to the Everloom database.
            </p>
          </div>

          {/* Finished Card Preview */}
          <div className="max-w-2xl mx-auto rounded-3xl border border-[#E8DFC8] overflow-hidden bg-[#FAF7F2] shadow-md">
            <div className="aspect-16/9 relative overflow-hidden bg-black/5">
              <img src={imageUrl} alt="Final Preview" className="w-full h-full object-cover" />
              <div className="absolute top-4 left-4 flex gap-2">
                <span className="px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-black/60 backdrop-blur-md text-white">
                  Placement: {placement}
                </span>
                <span className="px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-[#2D5A43] text-white">
                  Eco Score: 94/100
                </span>
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#8E3015] block">
                  {craftCategory}
                </span>
                <h3 className="font-serif-heritage text-2xl font-bold text-[#241E19] mt-1">
                  {title || rawCraftName}
                </h3>
              </div>

              <p className="text-xs text-[#4A3E33] leading-relaxed">
                {description}
              </p>

              {artisanStory && (
                <div className="p-4 rounded-xl bg-[#F4EFEA] border border-[#DDD3C1] text-xs">
                  <span className="font-bold text-[#8E3015] uppercase tracking-wider block mb-1">
                    Artisan Provenance Story:
                  </span>
                  <p className="italic text-[#5A4D42]">"{artisanStory}"</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4 text-xs pt-2">
                <div>
                  <span className="text-[#7A6B5D] block">Materials:</span>
                  <span className="font-semibold text-[#241E19]">{materials}</span>
                </div>
                <div>
                  <span className="text-[#7A6B5D] block">Care Guide:</span>
                  <span className="font-semibold text-[#241E19]">{careInstructions}</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-[#E8DFC8]">
                <div>
                  <span className="text-xs text-[#7A6B5D] block">Artisan Fair Price</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-[#241E19]">
                      ₹{price.toLocaleString('en-IN')}
                    </span>
                    {comparePrice && comparePrice > price && (
                      <span className="text-xs text-[#7A6B5D] line-through">
                        ₹{comparePrice.toLocaleString('en-IN')}
                      </span>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs text-[#7A6B5D] block">Inventory Stock</span>
                  <span className="text-xs font-bold text-[#2D5A43]">
                    {stockQuantity} units available
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-[#E8DFC8]">
            <button
              onClick={() => setCurrentStep(5)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-[#D5C9B3] text-xs font-semibold text-[#4A3E33]"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Placement</span>
            </button>
            <button
              onClick={handlePublish}
              disabled={publishing}
              className="flex items-center gap-2 px-8 py-3 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C] shadow-lg hover:scale-105 transition-all disabled:opacity-50"
            >
              {publishing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              <span>{publishing ? 'Publishing to Everloom...' : 'Confirm & Publish to Everloom'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
