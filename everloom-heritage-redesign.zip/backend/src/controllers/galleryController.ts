import { Request, Response } from 'express';
import { db } from '../repositories/db.ts';

// Digital Art Gallery: focuses on artistic exhibition, storytelling, high-resolution visual curation
export const getGalleryItems = (req: Request, res: Response) => {
  const { craftCategory, artisanId } = req.query;

  let products = db.getProducts({
    placement: 'gallery',
    craftCategory: craftCategory as string,
    artisanId: artisanId as string
  });

  const exhibitionItems = products.map(p => {
    const artisan = db.findArtisanById(p.artisanId);
    const user = artisan ? db.findUserById(artisan.userId) : null;
    return {
      id: p.id,
      title: p.title,
      description: p.description,
      artisanStory: p.artisanStory,
      craftCategory: p.craftCategory,
      materials: p.materials,
      images: p.images,
      price: p.price,
      ecoScore: p.ecoScore,
      artisan: {
        id: artisan?.id,
        name: user?.name || 'Master Artisan',
        craftType: artisan?.craftType,
        location: artisan ? `${artisan.villageOrCity}, ${artisan.state}` : 'India',
        awards: artisan?.awards || [],
        experienceYears: artisan?.experienceYears || 10,
        giTagged: artisan?.giTagged,
        handloomMark: artisan?.handloomMark
      }
    };
  });

  return res.json({
    total: exhibitionItems.length,
    galleryItems: exhibitionItems
  });
};
