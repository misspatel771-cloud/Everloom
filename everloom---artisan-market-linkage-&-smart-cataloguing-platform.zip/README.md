# Everloom — AI-Driven Market Linkage & Smart Cataloguing Platform

Everloom is an AI-driven market linkage and smart cataloguing platform created specifically for marginalized and independent artisans across India. Everloom overcomes digital barriers, presents handmade creations with dignified storytelling, tracks inventory and stock, audits low-carbon sustainability metrics, and connects artisans directly with conscious buyers and institutional bulk purchasers.

---

## 1. Project Architecture

Everloom is structured cleanly into separate frontend, backend, and OpenAPI specification directories:

```text
everloom/
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── api/             # Typed REST API client
│   │   ├── components/      # Navbar, Footer, Modals (Enquiry, Checkout, QR)
│   │   ├── i18n/            # Multilingual configuration (English, Hindi, Marathi)
│   │   ├── pages/
│   │   │   ├── artisan/     # All 14 Artisan Workspace modules
│   │   │   ├── buyer/       # Marketplace & Digital Art Gallery exhibitions
│   │   │   └── auth/        # Artisan & Buyer login / registration
│   │   ├── types/           # Core domain TypeScript models
│   │   ├── App.tsx          # Main React router
│   │   └── main.tsx         # Entry point
│   ├── package.json
│   └── .env.example
├── backend/
│   ├── src/
│   │   ├── controllers/     # Auth, Products, Catalogue, Orders, Enquiries, Insights
│   │   ├── integrations/    # AI integration (Google Gen AI SDK & Curated Engine)
│   │   ├── repositories/    # Database persistence layer
│   │   ├── routes/          # Express REST API routes matching OpenAPI
│   │   ├── services/        # AI Service, Sustainability Carbon Life-Cycle Service
│   │   ├── app.ts           # Express application configuration
│   │   └── server.ts        # Standalone backend server entry point
│   ├── prisma/
│   │   ├── schema.prisma    # PostgreSQL Prisma ORM schema
│   │   └── seed.ts          # Database seeder
│   ├── tests/
│   ├── package.json
│   └── .env.example
├── openapi/
│   └── everloom-openapi.yaml # Complete OpenAPI 3.0 specification
├── server.ts                # Full-stack dev & production server (mounts API + Vite)
├── package.json             # Root monorepo / workspace script orchestration
└── README.md
```

---

## 2. All 14 Dedicated Artisan Modules

The Artisan Workspace includes all 14 required modules:

1. **Overview**: Key metrics (active creations, digital views, buyer enquiries, direct order revenue), pending order actions, and low-stock alerts.
2. **Inventory**: Unit counts, low-stock flags, quick inline stock adjustment (+ / -), variant breakdown, and availability toggles.
3. **Order Management**: Order pipeline with statuses (`pending`, `confirmed`, `processing`, `shipped`, `delivered`, `cancelled`), shipping details, customer contact info, and courier tracking updates.
4. **Customer Management**: Patron directory compiled from enquiries and orders, showing customer order frequency, total spend, and contact channels.
5. **All Products**: Searchable, filterable archive of the artisan's creations with quick editing, placement toggles, and deletion with confirmation.
6. **AI Catalogue Studio**: Complete 6-step cataloguing workflow:
   - *A. Image Upload*: Upload handmade item photo or select sample heritage craft.
   - *B. Image Studio*: Original vs. enhanced preview, 4 enhancement grades (*Studio Clean*, *Warm Heritage*, *Natural Daylight*, *High Contrast*), extracted color palette, and photography recommendations.
   - *C. AI Catalogue Content*: Generation of titles, descriptions, tags, care instructions, and artisan heritage stories in English, Hindi, or Marathi.
   - *D. Commercial Details*: Pricing, comparable retail benchmarks, stock, physical dimensions, and variants (colors/sizes).
   - *E. Placement*: Choice between `gallery` (*My Gallery*), `marketplace` (*Marketplace*), or `both`.
   - *F. Review & Publish*: Instant persistence and live exhibition publishing.
7. **Digital Art Gallery**: Curated visual exhibition space highlighting high-resolution photography, artisan biographies, and shareable QR Code cards.
8. **Marketplace Listings**: Controls which creations are active on the buyer marketplace with fair-trade margin monitoring.
9. **Enquiries & Messages**: Real-time message threads between prospective patrons and artisans with instant reply capability.
10. **Market Insights**: High-demand craft trends, transparent price comparisons (Everloom Artisan Price vs. Urban Retail Average with middleman cut audits), and pre-matched institutional buyers.
11. **Analytics**: Real product views, catalogue reads, enquiry conversion rates, and monthly revenue performance.
12. **Sustainability**: IPCC Tier 1 life-cycle carbon footprint calculations comparing manual craft emissions with industrial factories, tree equivalents, and green artisan badges.
13. **My Profile**: Master artisan credentials, craft lineage, village/state, cooperative membership, GI tag & Handloom Mark accreditations, and direct UPI IDs.
14. **Settings**: Multilingual preference (English, हिन्दी, मराठी), currency, and communication alerts.

---

## 3. How to Run Frontend and Backend

### Option A: Full-Stack Mode (Recommended for AI Studio & Development)
To run both the backend API and frontend React client seamlessly together on port 3000:
```bash
npm install
npm run dev
```
Open `http://localhost:3000` in your browser.

### Option B: Standalone Backend
To run the Node.js / Express backend separately:
```bash
cd backend
npm install
cp .env.example .env
npm run dev
```
Backend runs at `http://localhost:5000/api`.

### Option C: Standalone Frontend
To run the Vite / React frontend separately:
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```
Frontend runs at `http://localhost:5173`.

---

## 4. Database Configuration (PostgreSQL & Prisma)

The database schema is defined in `backend/prisma/schema.prisma` covering `User`, `ArtisanProfile`, `Product`, `ProductVariant`, `Enquiry`, `EnquiryMessage`, `Order`, `OrderItem`, and `Review`.

To connect to a live PostgreSQL database:
1. In `backend/.env`, set:
   ```env
   DATABASE_URL="postgresql://user:password@localhost:5432/everloom?schema=public"
   ```
2. Generate Prisma Client & run migrations:
   ```bash
   cd backend
   npx prisma generate
   npx prisma migrate dev --name init
   npm run prisma:seed
   ```
*Note: For out-of-the-box local development and AI Studio preview, Everloom includes a file-persisted JSON repository (`everloom_store.json`) pre-seeded with authentic master artisans (Varanasi Handloom Silk, Gorakhpur Terracotta, Madhubani Art, Bastar Dhokra).*

---

## 5. AI Service Configuration

Everloom integrates with `@google/genai` (model: `gemini-3.8-flash`) for multi-modal image critique, color palette analysis, and catalogue generation.

1. Set your Gemini API key in `.env`:
   ```env
   GEMINI_API_KEY="your-gemini-api-key"
   ```
2. When `GEMINI_API_KEY` is present, the backend automatically uses `gemini-3.8-flash` to craft authentic, evocative descriptions and analyze images.
3. If no key is set or the API is offline, Everloom transparently indicates the service status and runs the curated artisan rules engine without failing or faking AI output.
