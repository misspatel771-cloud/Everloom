import { Request, Response } from 'express';
import { db } from '../repositories/db.ts';

// Marketplace: Buyer-facing discovery, direct enquiry, ordering, price comparisons, craft heritage
export const getMarketplaceProducts = (req: Request, res: Response) => {
  const { category, minPrice, maxPrice, search, sortBy } = req.query;

  let products = db.getProducts({
    placement: 'marketplace',
    craftCategory: category as string,
    search: search as string,
  });

  if (minPrice) {
    products = products.filter(p => p.price >= Number(minPrice));
  }
  if (maxPrice) {
    products = products.filter(p => p.price <= Number(maxPrice));
  }

  if (sortBy === 'price_asc') {
    products.sort((a, b) => a.price - b.price);
  } else if (sortBy === 'price_desc') {
    products.sort((a, b) => b.price - a.price);
  } else if (sortBy === 'newest') {
    products.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  const enriched = products.map(p => {
    const artisan = db.findArtisanById(p.artisanId);
    const user = artisan ? db.findUserById(artisan.userId) : null;
    return {
      ...p,
      artisanName: user?.name || 'Master Artisan',
      artisanLocation: artisan ? `${artisan.villageOrCity}, ${artisan.state}` : 'India',
      handloomMark: artisan?.handloomMark || false,
      giTagged: artisan?.giTagged || false,
      isAvailable: p.stockQuantity > 0 && p.isAvailable
    };
  });

  return res.json({
    total: enriched.length,
    products: enriched
  });
};
