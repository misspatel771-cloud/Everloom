import app from './app.ts';

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`[Everloom Backend] REST API Server running on port ${PORT}`);
});
