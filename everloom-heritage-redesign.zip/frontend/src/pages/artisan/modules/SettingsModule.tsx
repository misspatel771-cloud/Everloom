import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Globe, Bell, Shield, Check, Save } from 'lucide-react';

export const SettingsModule: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [selectedLang, setSelectedLang] = useState(i18n.language || 'en');
  const [currency, setCurrency] = useState('INR');
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [smsNotifs, setSmsNotifs] = useState(true);
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    i18n.changeLanguage(selectedLang);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19]">
          Studio & System Settings
        </h2>
        <p className="text-xs text-[#7A6B5D] mt-1">
          Customize your linguistic interface, notification preferences, and currency display.
        </p>
      </div>

      {saved && (
        <div className="p-3.5 rounded-xl bg-[#2D5A43]/10 border border-[#2D5A43]/30 text-[#2D5A43] text-xs font-semibold flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>Preferences saved successfully!</span>
        </div>
      )}

      <form onSubmit={handleSave} className="bg-white rounded-2xl border border-[#E8DFC8] p-6 sm:p-8 shadow-sm space-y-6 text-xs">
        {/* Language selector */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-[#B84A2A]" />
            <h4 className="font-bold text-sm text-[#241E19]">Language (भाषा)</h4>
          </div>
          <p className="text-[11px] text-[#7A6B5D]">
            Select your preferred language. Everloom supports English, Hindi, and Marathi.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            {[
              { code: 'en', label: 'English', sub: 'Standard' },
              { code: 'hi', label: 'हिन्दी (Hindi)', sub: 'देवनागरी' },
              { code: 'mr', label: 'मराठी (Marathi)', sub: 'देवनागरी' }
            ].map(l => (
              <button
                type="button"
                key={l.code}
                onClick={() => setSelectedLang(l.code)}
                className={`p-3 rounded-xl border text-left transition-all ${
                  selectedLang === l.code
                    ? 'border-[#B84A2A] bg-[#B84A2A]/5 text-[#8E3015] font-bold'
                    : 'border-[#E8DFC8] hover:bg-[#FAF7F2] text-[#4A3E33]'
                }`}
              >
                <span className="block text-sm">{l.label}</span>
                <span className="text-[10px] text-[#7A6B5D] font-normal block">{l.sub}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Currency */}
        <div className="space-y-3 pt-4 border-t border-[#E8DFC8]">
          <h4 className="font-bold text-sm text-[#241E19]">Display Currency</h4>
          <select
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
            className="w-full sm:w-64 px-3.5 py-2.5 rounded-xl border border-[#D5C9B3] bg-[#FAF7F2]"
          >
            <option value="INR">Indian Rupee (₹ INR)</option>
            <option value="USD">US Dollar ($ USD)</option>
            <option value="EUR">Euro (€ EUR)</option>
          </select>
        </div>

        {/* Notifications */}
        <div className="space-y-3 pt-4 border-t border-[#E8DFC8]">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-[#B84A2A]" />
            <h4 className="font-bold text-sm text-[#241E19]">Instant Communication Alerts</h4>
          </div>
          <div className="space-y-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={emailNotifs}
                onChange={(e) => setEmailNotifs(e.target.checked)}
                className="w-4 h-4 text-[#B84A2A] rounded"
              />
              <span className="font-medium text-[#3A2E24]">Email me immediately when a buyer submits an enquiry</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={smsNotifs}
                onChange={(e) => setSmsNotifs(e.target.checked)}
                className="w-4 h-4 text-[#B84A2A] rounded"
              />
              <span className="font-medium text-[#3A2E24]">SMS / WhatsApp notifications for new order confirmations</span>
            </label>
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t border-[#E8DFC8]">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#B84A2A] text-white font-bold hover:bg-[#9E3A1C]"
          >
            <Save className="w-4 h-4" />
            <span>Save Preferences</span>
          </button>
        </div>
      </form>
    </div>
  );
};
