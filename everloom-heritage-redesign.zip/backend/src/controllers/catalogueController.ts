import { Request, Response } from 'express';
import { aiService } from '../services/aiService.ts';

export const getAIStatus = (_req: Request, res: Response) => {
  return res.json({
    geminiConfigured: aiService.isConfigured(),
    model: 'gemini-3.8-flash',
    features: ['AI Catalogue Storyteller', 'Metadata & Tag Generation', 'Aesthetic Image Optimization']
  });
};

export const enhanceImage = async (req: Request, res: Response) => {
  try {
    const { imageUrl, filterMode = 'studio_clean' } = req.body;
    if (!imageUrl) {
      return res.status(400).json({ error: 'Image URL is required' });
    }

    const result = await aiService.enhanceProductImage({ imageUrl, filterMode });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Image enhancement processing failed' });
  }
};

export const generateCatalogue = async (req: Request, res: Response) => {
  try {
    const { rawName, craftCategory, artisanStory, materials, region, language } = req.body;
    if (!rawName || !craftCategory) {
      return res.status(400).json({ error: 'Product name and craft category are required' });
    }

    const catalogue = await aiService.generateCatalogue({
      rawName,
      craftCategory,
      artisanStory,
      materials,
      region,
      language
    });

    return res.json(catalogue);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'AI catalogue generation failed' });
  }
};
