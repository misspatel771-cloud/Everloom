import React, { useEffect, useState } from 'react';
import { Package, Search, Plus, Trash2, Edit3, Eye, Sparkles, Filter, Check } from 'lucide-react';
import { api } from '../../../api/client.ts';
import { Product, Placement } from '../../../types';

interface AllProductsModuleProps {
  onOpenCreateStudio: () => void;
  onOpenProductDetail: (productId: string) => void;
}

export const AllProductsModule: React.FC<AllProductsModuleProps> = ({
  onOpenCreateStudio,
  onOpenProductDetail
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [placementFilter, setPlacementFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const res = await api.products.list();
      setProducts(res.products || []);
    } catch (err) {
      console.error('Error fetching products:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleDelete = async (id: string, title: string) => {
    if (!window.confirm(`Are you sure you want to remove "${title}"? This cannot be undone.`)) {
      return;
    }
    try {
      setDeletingId(id);
      await api.products.delete(id);
      setProducts(prev => prev.filter(p => p.id !== id));
      setFeedback(`Product "${title}" removed successfully.`);
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(`Failed to delete: ${err.message}`);
    } finally {
      setDeletingId(null);
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    try {
      const res = await api.products.update(editingProduct.id, {
        title: editingProduct.title,
        description: editingProduct.description,
        price: Number(editingProduct.price),
        stockQuantity: Number(editingProduct.stockQuantity),
        placement: editingProduct.placement
      });
      setProducts(prev => prev.map(p => (p.id === editingProduct.id ? res.product : p)));
      setEditingProduct(null);
      setFeedback('Product details saved successfully.');
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(`Failed to update product: ${err.message}`);
    }
  };

  const categories = ['all', 'Handloom & Textiles', 'Terracotta & Pottery', 'Folk & Tribal Painting', 'Metalcraft & Dhokra'];

  const filtered = products.filter(p => {
    const matchesSearch =
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase()) ||
      p.tags.some(t => t.toLowerCase().includes(search.toLowerCase()));
    const matchesPlacement =
      placementFilter === 'all' || p.placement === placementFilter || p.placement === 'both';
    const matchesCategory =
      categoryFilter === 'all' || p.craftCategory.toLowerCase().includes(categoryFilter.toLowerCase());
    return matchesSearch && matchesPlacement && matchesCategory;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19]">
            All Artisan Creations
          </h2>
          <p className="text-xs text-[#7A6B5D] mt-1">
            Browse, manage, and edit your complete archive of handcrafted treasures.
          </p>
        </div>
        <button
          onClick={onOpenCreateStudio}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C] transition-all shadow-md self-start"
        >
          <Sparkles className="w-4 h-4" />
          <span>New AI Catalogue</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-[#2D5A43]/10 border border-[#2D5A43]/30 text-[#2D5A43] text-xs font-semibold flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Filter and search controls */}
      <div className="bg-white p-4 rounded-2xl border border-[#E8DFC8] shadow-sm flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-[#7A6B5D] absolute left-3 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by title, description, or tags..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-[#D5C9B3] bg-[#FAF7F2] focus:outline-none focus:border-[#B84A2A]"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          {/* Placement selector */}
          <select
            value={placementFilter}
            onChange={(e) => setPlacementFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-[#D5C9B3] bg-[#FAF7F2] text-[#4A3E33]"
          >
            <option value="all">All Placements</option>
            <option value="gallery">My Gallery</option>
            <option value="marketplace">Marketplace</option>
            <option value="both">Both</option>
          </select>

          {/* Category selector */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-[#D5C9B3] bg-[#FAF7F2] text-[#4A3E33]"
          >
            <option value="all">All Categories</option>
            <option value="Handloom">Handloom</option>
            <option value="Terracotta">Terracotta</option>
            <option value="Painting">Folk Painting</option>
          </select>
        </div>
      </div>

      {/* Product grid / list */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-[#E8DFC8]">
          <Package className="w-12 h-12 text-[#C8B8A6] mx-auto mb-3" />
          <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">No Creations Found</h3>
          <p className="text-xs text-[#7A6B5D] mt-1 max-w-sm mx-auto">
            Try adjusting your search criteria or create a new catalogue through the AI Studio.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((prod) => (
            <div
              key={prod.id}
              className="bg-white rounded-2xl border border-[#E8DFC8] overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Photo & Placement Tag */}
                <div className="relative aspect-4/3 bg-[#FAF7F2] overflow-hidden group">
                  <img
                    src={prod.images[0] || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80'}
                    alt={prod.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3 flex flex-wrap gap-1">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wide uppercase bg-black/60 backdrop-blur-md text-white">
                      {prod.placement === 'both' ? 'Gallery & Market' : prod.placement === 'gallery' ? 'My Gallery' : 'Marketplace'}
                    </span>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wide uppercase bg-[#2D5A43]/80 backdrop-blur-md text-white">
                      Eco: {prod.ecoScore}/100
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-2">
                  <span className="text-[11px] font-semibold text-[#8E3015] uppercase tracking-wider block">
                    {prod.craftCategory}
                  </span>
                  <h3 className="font-bold text-base text-[#241E19] line-clamp-1">
                    {prod.title}
                  </h3>
                  <p className="text-xs text-[#6A5D52] line-clamp-2 leading-relaxed">
                    {prod.description}
                  </p>

                  <div className="flex items-center justify-between pt-3 border-t border-[#F0EAE1]">
                    <div>
                      <span className="text-xs text-[#7A6B5D] block">Price</span>
                      <span className="text-lg font-bold text-[#241E19]">
                        ₹{prod.price.toLocaleString('en-IN')}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs text-[#7A6B5D] block">Stock</span>
                      <span className={`text-xs font-bold ${prod.stockQuantity <= 2 ? 'text-[#C98A1F]' : 'text-[#2D5A43]'}`}>
                        {prod.stockQuantity} in stock
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="px-5 pb-5 pt-1 flex items-center justify-between gap-2 border-t border-[#FAF7F2]">
                <button
                  onClick={() => onOpenProductDetail(prod.id)}
                  className="flex-1 py-2 rounded-xl bg-[#FAF7F2] hover:bg-[#F0EAE1] text-xs font-semibold text-[#3A2E24] flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Eye className="w-3.5 h-3.5 text-[#B84A2A]" />
                  <span>Preview</span>
                </button>
                <button
                  onClick={() => setEditingProduct(prod)}
                  className="p-2 rounded-xl border border-[#D5C9B3] hover:bg-[#FAF7F2] text-[#4A3E33]"
                  title="Edit Product"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDelete(prod.id, prod.title)}
                  disabled={deletingId === prod.id}
                  className="p-2 rounded-xl border border-[#E8DFC8] hover:bg-[#FFF5F5] text-[#9E2A2B] disabled:opacity-40"
                  title="Delete Creation"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit Product Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-[#E8DFC8] space-y-4">
            <h3 className="text-lg font-bold font-serif-heritage text-[#241E19]">
              Edit Creation Details
            </h3>

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-[#4A3E33] mb-1">Title</label>
                <input
                  type="text"
                  value={editingProduct.title}
                  onChange={(e) => setEditingProduct({ ...editingProduct, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-[#4A3E33] mb-1">Description</label>
                <textarea
                  rows={3}
                  value={editingProduct.description}
                  onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#4A3E33] mb-1">Price (₹)</label>
                  <input
                    type="number"
                    value={editingProduct.price}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#4A3E33] mb-1">Stock Units</label>
                  <input
                    type="number"
                    value={editingProduct.stockQuantity}
                    onChange={(e) => setEditingProduct({ ...editingProduct, stockQuantity: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#4A3E33] mb-1">Catalogue Placement</label>
                <select
                  value={editingProduct.placement}
                  onChange={(e) => setEditingProduct({ ...editingProduct, placement: e.target.value as Placement })}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                >
                  <option value="gallery">My Gallery</option>
                  <option value="marketplace">Marketplace</option>
                  <option value="both">Both (Gallery & Marketplace)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#E8DFC8]">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2 rounded-xl border border-[#D5C9B3] text-[#4A3E33] hover:bg-[#FAF7F2]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#B84A2A] text-white font-bold hover:bg-[#9E3A1C]"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
