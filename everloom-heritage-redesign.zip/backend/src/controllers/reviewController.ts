import { Request, Response } from 'express';
import { db } from '../repositories/db.ts';

export const getReviews = (req: Request, res: Response) => {
  const { productId } = req.params;
  const reviews = db.getProductReviews(productId);
  return res.json({ reviews });
};

export const addReview = (req: Request, res: Response) => {
  try {
    const { productId, userName, rating = 5, comment } = req.body;
    if (!productId || !userName || !comment) {
      return res.status(400).json({ error: 'Product ID, user name, and comment are required' });
    }

    const review = db.addReview(productId, userName, Number(rating), comment);
    return res.status(201).json({
      message: 'Review posted successfully',
      review
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to submit review' });
  }
};
