import { Router } from 'express';
import * as authController from '../controllers/authController.ts';
import * as artisanController from '../controllers/artisanController.ts';
import * as productController from '../controllers/productController.ts';
import * as catalogueController from '../controllers/catalogueController.ts';
import * as galleryController from '../controllers/galleryController.ts';
import * as marketplaceController from '../controllers/marketplaceController.ts';
import * as enquiryController from '../controllers/enquiryController.ts';
import * as orderController from '../controllers/orderController.ts';
import * as customerController from '../controllers/customerController.ts';
import * as insightsController from '../controllers/insightsController.ts';
import * as analyticsController from '../controllers/analyticsController.ts';
import * as sustainabilityController from '../controllers/sustainabilityController.ts';
import * as reviewController from '../controllers/reviewController.ts';

const router = Router();

// Auth
router.post('/auth/register', authController.register);
router.post('/auth/login', authController.login);
router.get('/auth/me', authController.getMe);

// Artisan profile
router.get('/artisans/profile', artisanController.getArtisanProfile);
router.put('/artisans/profile', artisanController.updateArtisanProfile);
router.get('/artisans/:id', artisanController.getArtisanById);

// Products
router.get('/products', productController.getProducts);
router.post('/products', productController.createProduct);
router.get('/products/:id', productController.getProductById);
router.put('/products/:id', productController.updateProduct);
router.delete('/products/:id', productController.deleteProduct);
router.patch('/products/:id/stock', productController.updateStock);

// AI Catalogue Studio
router.get('/catalogue/status', catalogueController.getAIStatus);
router.post('/catalogue/ai/enhance-image', catalogueController.enhanceImage);
router.post('/catalogue/ai/generate', catalogueController.generateCatalogue);

// Gallery & Marketplace
router.get('/gallery', galleryController.getGalleryItems);
router.get('/marketplace/products', marketplaceController.getMarketplaceProducts);

// Enquiries & Messaging
router.get('/enquiries', enquiryController.getEnquiries);
router.post('/enquiries', enquiryController.createEnquiry);
router.post('/enquiries/:id/reply', enquiryController.replyEnquiry);

// Orders
router.get('/orders', orderController.getOrders);
router.post('/orders', orderController.createOrder);
router.patch('/orders/:id/status', orderController.updateOrderStatus);

// Customers
router.get('/customers', customerController.getCustomers);

// Insights, Analytics & Sustainability
router.get('/market-insights', insightsController.getMarketInsights);
router.get('/analytics', analyticsController.getAnalytics);
router.get('/sustainability', sustainabilityController.getSustainabilityData);
router.post('/sustainability/calculate', sustainabilityController.calculateProductCarbon);

// Reviews
router.get('/reviews/:productId', reviewController.getReviews);
router.post('/reviews', reviewController.addReview);

export default router;
