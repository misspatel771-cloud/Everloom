import { Request, Response } from 'express';
import { db } from '../repositories/db.ts';

export const register = (req: Request, res: Response) => {
  try {
    const { name, email, password, role = 'artisan', phone, craftType, state, villageOrCity } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required' });
    }

    const existing = db.findUserByEmail(email);
    if (existing) {
      return res.status(400).json({ error: 'An account with this email already exists' });
    }

    const user = db.createUser({
      name,
      email,
      passwordHash: password, // In production, bcrypt hash
      role: role as 'artisan' | 'buyer',
      phone,
      avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}`
    });

    let artisanProfile = null;
    if (user.role === 'artisan') {
      artisanProfile = db.createOrUpdateArtisanProfile(user.id, {
        craftType: craftType || 'Traditional Handcraft',
        state: state || 'Uttar Pradesh',
        villageOrCity: villageOrCity || 'Varanasi',
        experienceYears: 5,
        awards: [],
        verifiedBadge: true
      });
    }

    const token = `everloom_token_${user.id}`;
    return res.status(201).json({
      message: 'Account registered successfully',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        avatarUrl: user.avatarUrl
      },
      artisanProfile
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Registration failed' });
  }
};

export const login = (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const user = db.findUserByEmail(email);
    if (!user || user.passwordHash !== password) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const artisanProfile = user.role === 'artisan' ? db.findArtisanByUserId(user.id) : null;
    const token = `everloom_token_${user.id}`;

    return res.json({
      message: 'Logged in successfully',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        avatarUrl: user.avatarUrl
      },
      artisanProfile
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Login failed' });
  }
};

export const getMe = (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  let userId = 'artisan-u1'; // Default logged-in demo master artisan Devendra Ansari

  if (authHeader && authHeader.startsWith('Bearer everloom_token_')) {
    userId = authHeader.replace('Bearer everloom_token_', '').trim();
  }

  const user = db.findUserById(userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  const artisanProfile = user.role === 'artisan' ? db.findArtisanByUserId(user.id) : null;

  return res.json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      phone: user.phone,
      avatarUrl: user.avatarUrl
    },
    artisanProfile
  });
};
