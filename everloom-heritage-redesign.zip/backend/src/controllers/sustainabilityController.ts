import { Request, Response } from 'express';
import { db } from '../repositories/db.ts';
import { sustainabilityService } from '../services/sustainabilityService.ts';

export const getSustainabilityData = (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  let userId = 'artisan-u1';
  if (authHeader && authHeader.startsWith('Bearer everloom_token_')) {
    userId = authHeader.replace('Bearer everloom_token_', '').trim();
  }

  const artisan = db.findArtisanByUserId(userId);
  const products = db.getProducts({ artisanId: artisan?.id });
  const artisanStats = sustainabilityService.getArtisanSustainabilityStats(products.length);

  const productBreakdown = products.map(p => ({
    id: p.id,
    title: p.title,
    craftCategory: p.craftCategory,
    carbonFootprintKg: p.carbonFootprintKg,
    ecoScore: p.ecoScore,
    materials: p.materials
  }));

  return res.json({
    artisanStats,
    productBreakdown,
    sustainabilityPillars: [
      {
        title: 'Zero-Industrial Embodied Carbon',
        desc: 'Crafted without fossil-fuel powered automated textile machinery or steam generators.'
      },
      {
        title: 'Natural & Biodegradable Materials',
        desc: 'Pure river silt, organic Mulberry silk, desi unbleached cotton, and botanical dyes that decompose safely.'
      },
      {
        title: 'Fair Direct Livelihood Value',
        desc: 'Over 95% of transaction proceeds go directly to artisan households, preventing village migration and preserving ancestral craft knowledge.'
      }
    ]
  });
};

export const calculateProductCarbon = (req: Request, res: Response) => {
  try {
    const { craftCategory, materials = [], weightKg = 0.5, shippingKm } = req.body;
    if (!craftCategory) {
      return res.status(400).json({ error: 'craftCategory is required' });
    }

    const report = sustainabilityService.calculateProductSustainability({
      craftCategory,
      materials,
      weightKg: Number(weightKg),
      shippingKm: shippingKm ? Number(shippingKm) : undefined
    });

    return res.json(report);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Sustainability calculation failed' });
  }
};
