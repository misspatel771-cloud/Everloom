import React, { useEffect, useState } from 'react';
import { User, Award, MapPin, Phone, CheckCircle2, Save, Sparkles } from 'lucide-react';
import { api } from '../../../api/client.ts';
import { ArtisanProfile } from '../../../types';

export const MyProfileModule: React.FC = () => {
  const [profile, setProfile] = useState<ArtisanProfile | null>(null);
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Form state
  const [craftType, setCraftType] = useState('');
  const [bio, setBio] = useState('');
  const [villageOrCity, setVillageOrCity] = useState('');
  const [state, setState] = useState('');
  const [experienceYears, setExperienceYears] = useState(5);
  const [cooperativeName, setCooperativeName] = useState('');
  const [upiId, setUpiId] = useState('');
  const [handloomMark, setHandloomMark] = useState(false);
  const [giTagged, setGiTagged] = useState(false);

  useEffect(() => {
    async function fetchProfile() {
      try {
        setLoading(true);
        const res = await api.artisan.getProfile();
        setUser(res.user);
        setProfile(res.profile);

        if (res.profile) {
          setCraftType(res.profile.craftType || '');
          setBio(res.profile.bio || '');
          setVillageOrCity(res.profile.villageOrCity || '');
          setState(res.profile.state || '');
          setExperienceYears(res.profile.experienceYears || 5);
          setCooperativeName(res.profile.cooperativeName || '');
          setUpiId(res.profile.upiId || '');
          setHandloomMark(Boolean(res.profile.handloomMark));
          setGiTagged(Boolean(res.profile.giTagged));
        }
      } catch (err) {
        console.error('Failed to load artisan profile:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchProfile();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      const res = await api.artisan.updateProfile({
        craftType,
        bio,
        villageOrCity,
        state,
        experienceYears: Number(experienceYears),
        cooperativeName,
        upiId,
        handloomMark,
        giTagged
      });
      setProfile(res.profile);
      setFeedback('Artisan profile credentials updated successfully!');
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(`Save failed: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19]">
          Master Artisan Profile & Heritage Credentials
        </h2>
        <p className="text-xs text-[#7A6B5D] mt-1">
          Your public artisan provenance, GI Tag certifications, and direct UPI payout details.
        </p>
      </div>

      {feedback && (
        <div className="p-3.5 rounded-xl bg-[#2D5A43]/10 border border-[#2D5A43]/30 text-[#2D5A43] text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Header Profile Card */}
      <div className="p-6 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm flex flex-col sm:flex-row items-center gap-6">
        <div className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-[#B84A2A] shrink-0 bg-[#FAF7F2]">
          <img
            src={user?.avatarUrl || 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=200&auto=format&fit=crop&q=80'}
            alt="Artisan Avatar"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1 text-center sm:text-left space-y-1">
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
            <h3 className="font-serif-heritage text-xl font-bold text-[#241E19]">{user?.name}</h3>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-[#2D5A43]/10 text-[#2D5A43] border border-[#2D5A43]/20">
              Verified Master Artisan
            </span>
          </div>
          <p className="text-xs font-semibold text-[#8E3015]">{craftType}</p>
          <p className="text-xs text-[#7A6B5D] flex items-center justify-center sm:justify-start gap-1">
            <MapPin className="w-3.5 h-3.5 text-[#B84A2A]" />
            <span>{villageOrCity}, {state}</span>
          </p>
        </div>
      </div>

      {/* Profile Form */}
      <form onSubmit={handleSave} className="bg-white rounded-2xl border border-[#E8DFC8] p-6 sm:p-8 shadow-sm space-y-6 text-xs">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block font-bold text-[#3A2E24] mb-1">Primary Craft Tradition</label>
            <input
              type="text"
              value={craftType}
              onChange={(e) => setCraftType(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
              required
            />
          </div>

          <div>
            <label className="block font-bold text-[#3A2E24] mb-1">Generational Experience (Years)</label>
            <input
              type="number"
              value={experienceYears}
              onChange={(e) => setExperienceYears(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
              required
            />
          </div>
        </div>

        <div>
          <label className="block font-bold text-[#3A2E24] mb-1">Artisan Biography & Craft Lineage</label>
          <textarea
            rows={4}
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3] leading-relaxed"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block font-bold text-[#3A2E24] mb-1">Village or Workshop City</label>
            <input
              type="text"
              value={villageOrCity}
              onChange={(e) => setVillageOrCity(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
            />
          </div>

          <div>
            <label className="block font-bold text-[#3A2E24] mb-1">State / Province</label>
            <input
              type="text"
              value={state}
              onChange={(e) => setState(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block font-bold text-[#3A2E24] mb-1">Artisan Cooperative or SHG Name</label>
            <input
              type="text"
              value={cooperativeName}
              onChange={(e) => setCooperativeName(e.target.value)}
              placeholder="e.g. Ganga Bunkaar Sangham"
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
            />
          </div>

          <div>
            <label className="block font-bold text-[#3A2E24] mb-1">Direct Bank UPI ID for Direct Payouts</label>
            <input
              type="text"
              value={upiId}
              onChange={(e) => setUpiId(e.target.value)}
              placeholder="e.g. devendra.weaver@okhdfcbank"
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
            />
          </div>
        </div>

        {/* Certifications and Tags */}
        <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] space-y-3">
          <span className="text-xs font-bold text-[#3A2E24] uppercase tracking-wider block">
            Government & Heritage Accreditations:
          </span>
          <div className="flex flex-wrap items-center gap-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={handloomMark}
                onChange={(e) => setHandloomMark(e.target.checked)}
                className="w-4 h-4 text-[#B84A2A] rounded"
              />
              <span className="font-semibold text-[#241E19]">Official Handloom Mark Certified</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={giTagged}
                onChange={(e) => setGiTagged(e.target.checked)}
                className="w-4 h-4 text-[#B84A2A] rounded"
              />
              <span className="font-semibold text-[#241E19]">GI (Geographical Indication) Registered</span>
            </label>
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t border-[#E8DFC8]">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#B84A2A] text-white font-bold hover:bg-[#9E3A1C] disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving...' : 'Save Profile Credentials'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
