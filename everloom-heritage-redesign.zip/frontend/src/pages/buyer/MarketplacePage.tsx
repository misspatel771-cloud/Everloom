import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ShoppingBag,
  Search,
  Filter,
  Leaf,
  Award,
  Heart,
  MessageSquare,
  ShieldCheck,
  Check,
  ChevronDown,
  X
} from 'lucide-react';
import { api } from '../../api/client.ts';
import { Product } from '../../types';

interface MarketplacePageProps {
  onOpenProductDetail: (id: string) => void;
  onOpenEnquiryModal: (product: Product) => void;
  onOpenOrderModal: (product: Product) => void;
}

export const MarketplacePage: React.FC<MarketplacePageProps> = ({
  onOpenProductDetail,
  onOpenEnquiryModal,
  onOpenOrderModal
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [sortBy, setSortBy] = useState('featured');
  const [savedProductIds, setSavedProductIds] = useState<Set<string>>(new Set());

  const fetchMarketplace = async () => {
    try {
      setLoading(true);
      const res = await api.marketplace.list({
        category: category !== 'all' ? category : undefined,
        search: search.trim() || undefined,
        sortBy
      });
      setProducts(res.products || []);
    } catch (err) {
      console.error('Failed to load marketplace:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMarketplace();
  }, [category, sortBy]);

  const toggleSaveProduct = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSavedProductIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const categories = [
    'all',
    'Handloom & Textiles',
    'Terracotta & Pottery',
    'Folk & Tribal Painting',
    'Metalcraft & Dhokra'
  ];

  return (
    <div className="min-h-screen bg-[#FAF7F2] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Marketplace Banner */}
        <div className="rounded-3xl bg-gradient-to-r from-[#241E19] via-[#38281E] to-[#241E19] text-[#FAF7F2] p-8 sm:p-12 shadow-xl relative overflow-hidden">
          <div className="max-w-2xl relative z-10 space-y-3">
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-[#B84A2A]/40 text-[#FAF7F2] border border-[#B84A2A]/50">
              Zero-Middleman Direct Trade
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold font-serif-heritage text-[#FAF7F2]">
              Handcrafted Treasures Direct from Master Artisans
            </h1>
            <p className="text-xs sm:text-sm text-[#C8B8A6] leading-relaxed">
              Every purchase on Everloom sends over 95% of proceeds directly to the artisan household, sustaining indigenous weaving, terracotta, and folk art traditions.
            </p>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="bg-white rounded-2xl border border-[#E8DFC8] p-4 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-[#7A6B5D] absolute left-3 top-3" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && fetchMarketplace()}
              placeholder="Search by craft, material, region, artisan name..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-[#D5C9B3] bg-[#FAF7F2] focus:outline-none focus:border-[#B84A2A]"
            />
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                  category === cat
                    ? 'bg-[#B84A2A] text-white shadow-sm'
                    : 'bg-[#FAF7F2] text-[#4A3E33] hover:bg-[#F0EAE1]'
                }`}
              >
                {cat === 'all' ? 'All Traditions' : cat}
              </button>
            ))}

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-[#FAF7F2] border border-[#D5C9B3] text-[#4A3E33]"
            >
              <option value="featured">Featured Curations</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="newest">Newest First</option>
            </select>
          </div>
        </div>

        {/* Product Grid */}
        {loading ? (
          <div className="flex items-center justify-center p-20">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
          </div>
        ) : products.length === 0 ? (
          <div className="bg-white rounded-2xl p-16 text-center border border-[#E8DFC8]">
            <ShoppingBag className="w-12 h-12 text-[#C8B8A6] mx-auto mb-3" />
            <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">No Listed Products Found</h3>
            <p className="text-xs text-[#7A6B5D] mt-1 max-w-sm mx-auto">
              Try refining your search terms or view items in the Digital Art Gallery.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map(prod => {
              const isSaved = savedProductIds.has(prod.id);

              return (
                <div
                  key={prod.id}
                  onClick={() => onOpenProductDetail(prod.id)}
                  className="bg-white rounded-3xl border border-[#E8DFC8] overflow-hidden shadow-sm hover:shadow-xl transition-all cursor-pointer group flex flex-col justify-between"
                >
                  <div>
                    {/* Product Photo */}
                    <div className="relative aspect-4/3 overflow-hidden bg-[#FAF7F2]">
                      <img
                        src={prod.images[0]}
                        alt={prod.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />

                      {/* Saved Wishlist Heart */}
                      <button
                        onClick={(e) => toggleSaveProduct(prod.id, e)}
                        className="absolute top-3 right-3 p-2 rounded-full bg-white/90 backdrop-blur-md shadow-md text-[#B84A2A] hover:bg-white transition-colors"
                        title={isSaved ? 'Remove from saved' : 'Save creation'}
                      >
                        <Heart className={`w-4 h-4 ${isSaved ? 'fill-[#B84A2A]' : ''}`} />
                      </button>

                      {/* Eco Score Badge */}
                      <div className="absolute bottom-3 left-3 flex gap-1.5">
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-[#2D5A43]/90 backdrop-blur-md text-white flex items-center gap-1">
                          <Leaf className="w-3 h-3" />
                          <span>Eco Score: {prod.ecoScore}/100</span>
                        </span>
                      </div>
                    </div>

                    {/* Details */}
                    <div className="p-6 space-y-3">
                      <div>
                        <div className="flex items-center justify-between text-[11px] text-[#8E3015] font-semibold uppercase tracking-wider">
                          <span>{prod.craftCategory}</span>
                          <span>{prod.artisanLocation || 'Varanasi, UP'}</span>
                        </div>
                        <h3 className="font-serif-heritage text-lg font-bold text-[#241E19] group-hover:text-[#B84A2A] transition-colors mt-0.5 line-clamp-1">
                          {prod.title}
                        </h3>
                      </div>

                      <p className="text-xs text-[#5A4D42] line-clamp-2 leading-relaxed">
                        {prod.description}
                      </p>

                      {/* Artisan Attribution */}
                      <div className="p-2.5 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] text-xs flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-[#7A6B5D] block">Crafted By</span>
                          <span className="font-bold text-[#241E19]">{prod.artisanName || 'Devendra Ansari'}</span>
                        </div>
                        <span className="text-[10px] font-bold text-[#2D5A43] flex items-center gap-1">
                          <Award className="w-3 h-3" />
                          Verified
                        </span>
                      </div>

                      {/* Pricing and Middleman comparison */}
                      <div className="pt-2 border-t border-[#F0EAE1] flex items-baseline justify-between">
                        <div>
                          <span className="text-xl font-bold text-[#241E19]">
                            ₹{prod.price.toLocaleString('en-IN')}
                          </span>
                          {prod.comparePrice && (
                            <span className="text-xs text-[#7A6B5D] line-through ml-2">
                              ₹{prod.comparePrice.toLocaleString('en-IN')}
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-[#2D5A43] font-semibold">
                          Direct to artisan
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="p-4 bg-[#FAF7F2] border-t border-[#E8DFC8] flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenEnquiryModal(prod);
                      }}
                      className="flex-1 py-2 rounded-xl bg-white border border-[#D5C9B3] text-xs font-semibold text-[#4A3E33] hover:bg-[#F0EAE1] flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-[#B84A2A]" />
                      <span>Enquire</span>
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenOrderModal(prod);
                      }}
                      className="flex-1 py-2 rounded-xl bg-[#B84A2A] hover:bg-[#9E3A1C] text-xs font-bold text-white flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Direct Buy</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
