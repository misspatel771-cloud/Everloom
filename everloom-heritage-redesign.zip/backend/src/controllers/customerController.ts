import { Request, Response } from 'express';
import { db } from '../repositories/db.ts';

// Customer Management: Compiles buyers from enquiries and orders for the artisan
export const getCustomers = (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  let userId = 'artisan-u1';
  if (authHeader && authHeader.startsWith('Bearer everloom_token_')) {
    userId = authHeader.replace('Bearer everloom_token_', '').trim();
  }

  const artisan = db.findArtisanByUserId(userId);
  const enquiries = db.getEnquiries({ artisanId: artisan?.id });
  const orders = db.getOrders(artisan?.id);

  const customerMap = new Map<string, any>();

  // Extract from orders
  for (const order of orders) {
    const key = order.customerEmail.toLowerCase();
    if (!customerMap.has(key)) {
      customerMap.set(key, {
        id: `cust-${customerMap.size + 1}`,
        name: order.customerName,
        email: order.customerEmail,
        phone: order.customerPhone || 'N/A',
        totalOrders: 0,
        totalSpent: 0,
        enquiriesCount: 0,
        lastInteracted: order.createdAt,
        shippingAddress: order.shippingAddress,
        type: 'Order Customer'
      });
    }
    const c = customerMap.get(key);
    c.totalOrders += 1;
    c.totalSpent += order.totalAmount;
    if (new Date(order.createdAt) > new Date(c.lastInteracted)) {
      c.lastInteracted = order.createdAt;
    }
  }

  // Extract from enquiries
  for (const enq of enquiries) {
    const key = enq.buyerEmail.toLowerCase();
    if (!customerMap.has(key)) {
      customerMap.set(key, {
        id: `cust-${customerMap.size + 1}`,
        name: enq.buyerName,
        email: enq.buyerEmail,
        phone: enq.buyerPhone || 'N/A',
        totalOrders: 0,
        totalSpent: 0,
        enquiriesCount: 1,
        lastInteracted: enq.updatedAt,
        shippingAddress: 'Not specified yet',
        type: 'Prospective Buyer'
      });
    } else {
      const c = customerMap.get(key);
      c.enquiriesCount += 1;
      if (new Date(enq.updatedAt) > new Date(c.lastInteracted)) {
        c.lastInteracted = enq.updatedAt;
      }
    }
  }

  return res.json({
    customers: Array.from(customerMap.values())
  });
};
