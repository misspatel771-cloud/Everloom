@echo off
title CraftReach Launcher
echo.
echo  ============================================
echo   CraftReach - Turn Craft Into Opportunity
echo  ============================================
echo.
echo  Opening CraftReach in your default browser...
echo.
start "" "%~dp0index.html"
echo  Done! If nothing opened, double-click index.html manually.
echo.
pause
