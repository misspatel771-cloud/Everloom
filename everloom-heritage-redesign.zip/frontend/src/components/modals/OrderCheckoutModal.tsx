import React, { useState } from 'react';
import { X, ShoppingBag, CheckCircle2, ShieldCheck } from 'lucide-react';
import { api } from '../../api/client.ts';
import { Product } from '../../types';

interface OrderCheckoutModalProps {
  product: Product;
  onClose: () => void;
  onSuccess?: () => void;
}

export const OrderCheckoutModal: React.FC<OrderCheckoutModalProps> = ({
  product,
  onClose,
  onSuccess
}) => {
  const [customerName, setCustomerName] = useState('Priya Nambiar');
  const [customerEmail, setCustomerEmail] = useState('priya.nambiar@gmail.com');
  const [customerPhone, setCustomerPhone] = useState('+91 98450 11223');
  const [shippingAddress, setShippingAddress] = useState('14, Palm Avenue, Indiranagar, Bengaluru, Karnataka - 560038');
  const [quantity, setQuantity] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState(
    product.variants[0]?.name || 'Standard Edition'
  );
  const [submitting, setSubmitting] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<any | null>(null);

  const totalAmount = product.price * quantity;

  const handleOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSubmitting(true);
      const res = await api.orders.create({
        productId: product.id,
        variantName: selectedVariant,
        quantity: Number(quantity),
        customerName,
        customerEmail,
        customerPhone,
        shippingAddress
      });
      setConfirmedOrder(res.order);
      if (onSuccess) onSuccess();
    } catch (err: any) {
      alert(`Order placement failed: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-[#E8DFC8] space-y-4">
        <div className="flex items-center justify-between border-b border-[#E8DFC8] pb-4">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#2D5A43]">
              Direct Fair-Trade Checkout
            </span>
            <h3 className="font-serif-heritage text-xl font-bold text-[#241E19]">
              Complete Your Order
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-[#7A6B5D] hover:bg-[#FAF7F2]">
            <X className="w-5 h-5" />
          </button>
        </div>

        {confirmedOrder ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#2D5A43]/10 text-[#2D5A43] flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <h4 className="font-serif-heritage text-xl font-bold text-[#241E19]">
                Order Confirmed!
              </h4>
              <p className="text-xs text-[#7A6B5D] mt-1">
                Order reference #{confirmedOrder.id} has been recorded directly in the artisan's studio dashboard.
              </p>
            </div>
            <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] text-xs text-left space-y-1">
              <div><strong>Recipient:</strong> {confirmedOrder.customerName}</div>
              <div><strong>Amount:</strong> ₹{confirmedOrder.totalAmount.toLocaleString('en-IN')}</div>
              <div><strong>Address:</strong> {confirmedOrder.shippingAddress}</div>
            </div>
            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-[#241E19] text-white text-xs font-bold"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleOrder} className="space-y-4 text-xs">
            {/* Summary */}
            <div className="p-3.5 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img src={product.images[0]} alt={product.title} className="w-12 h-12 rounded-lg object-cover" />
                <div>
                  <span className="font-bold text-[#241E19] line-clamp-1 block">{product.title}</span>
                  <span className="text-[#8E3015] font-semibold">₹{product.price.toLocaleString('en-IN')} / piece</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-[#7A6B5D] block">In Stock</span>
                <span className="font-bold text-[#2D5A43]">{product.stockQuantity} units</span>
              </div>
            </div>

            {/* Quantity and variant */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-[#4A3E33] mb-1">Quantity</label>
                <input
                  type="number"
                  min="1"
                  max={product.stockQuantity || 1}
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                  required
                />
              </div>

              {product.variants.length > 0 && (
                <div>
                  <label className="block font-semibold text-[#4A3E33] mb-1">Variant / Color</label>
                  <select
                    value={selectedVariant}
                    onChange={(e) => setSelectedVariant(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3] bg-white"
                  >
                    {product.variants.map((v, i) => (
                      <option key={i} value={v.name}>{v.name}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-[#4A3E33] mb-1">Customer Full Name</label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-[#4A3E33] mb-1">Contact Phone</label>
                <input
                  type="text"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-[#4A3E33] mb-1">Email Address</label>
              <input
                type="email"
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-[#4A3E33] mb-1">Shipping Postal Address</label>
              <textarea
                rows={2}
                value={shippingAddress}
                onChange={(e) => setShippingAddress(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3] leading-relaxed"
                required
              />
            </div>

            {/* Total calculation */}
            <div className="p-3.5 rounded-xl bg-[#2D5A43]/10 border border-[#2D5A43]/20 flex items-center justify-between">
              <div>
                <span className="text-xs text-[#2D5A43] font-semibold block">Total Fair-Trade Payable:</span>
                <span className="text-[10px] text-[#7A6B5D]">Zero hidden platform fees</span>
              </div>
              <span className="text-2xl font-bold text-[#241E19]">
                ₹{totalAmount.toLocaleString('en-IN')}
              </span>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E8DFC8]">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-[#D5C9B3] text-[#4A3E33] hover:bg-[#FAF7F2]"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-6 py-2.5 rounded-xl bg-[#B84A2A] text-white font-bold hover:bg-[#9E3A1C] flex items-center gap-2 shadow-sm disabled:opacity-50"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{submitting ? 'Placing Order...' : 'Confirm & Place Order'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
