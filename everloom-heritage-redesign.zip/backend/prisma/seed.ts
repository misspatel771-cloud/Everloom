/**
 * Prisma Database Seeder for Everloom
 * Populates PostgreSQL instance with initial artisan masters, products, and sustainability benchmarks.
 */
import { db } from '../src/repositories/db.ts';

async function main() {
  console.log('Seeding Everloom database with master artisans and heritage craft records...');
  // The in-memory/file repository db auto-initializes with comprehensive master artisan data
  const products = db.getProducts();
  console.log(`Successfully seeded ${products.length} master heritage craft products!`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
