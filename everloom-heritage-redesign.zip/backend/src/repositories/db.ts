import fs from 'fs';
import path from 'path';

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  name: string;
  role: 'artisan' | 'buyer' | 'admin';
  phone?: string;
  avatarUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ArtisanProfile {
  id: string;
  userId: string;
  craftType: string;
  bio?: string;
  villageOrCity?: string;
  state?: string;
  experienceYears: number;
  cooperativeName?: string;
  awards: string[];
  upiId?: string;
  verifiedBadge: boolean;
  handloomMark: boolean;
  giTagged: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ProductVariant {
  id: string;
  productId: string;
  name: string;
  sku?: string;
  price: number;
  stock: number;
}

export interface Product {
  id: string;
  artisanId: string;
  title: string;
  description: string;
  artisanStory?: string;
  craftCategory: string;
  materials: string[];
  careInstructions?: string;
  tags: string[];
  price: number;
  comparePrice?: number;
  stockQuantity: number;
  isAvailable: boolean;
  placement: 'gallery' | 'marketplace' | 'both';
  images: string[];
  dimensions?: string;
  weightGrams?: number;
  ecoScore: number;
  carbonFootprintKg: number;
  variants: ProductVariant[];
  viewsCount?: number;
  createdAt: string;
  updatedAt: string;
}

export interface EnquiryMessage {
  id: string;
  enquiryId: string;
  sender: 'artisan' | 'buyer' | string;
  message: string;
  createdAt: string;
}

export interface Enquiry {
  id: string;
  productId: string;
  buyerId?: string;
  buyerName: string;
  buyerEmail: string;
  buyerPhone?: string;
  quantityRequested: number;
  status: 'open' | 'replied' | 'converted' | 'closed';
  messages: EnquiryMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  id: string;
  orderId: string;
  productId: string;
  variantName?: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: string;
  buyerId?: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  shippingAddress: string;
  totalAmount: number;
  status: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  trackingNumber?: string;
  items: OrderItem[];
  createdAt: string;
  updatedAt: string;
}

export interface Review {
  id: string;
  productId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface DatabaseState {
  users: User[];
  artisans: ArtisanProfile[];
  products: Product[];
  enquiries: Enquiry[];
  orders: Order[];
  reviews: Review[];
}

const DB_FILE = path.resolve(process.cwd(), 'everloom_store.json');

// Initial seed data representing real traditional Indian artisan crafts
const INITIAL_SEED: DatabaseState = {
  users: [
    {
      id: 'artisan-u1',
      email: 'devendra.weaver@everloom.org',
      passwordHash: 'artisan123',
      name: 'Devendra Ansari',
      role: 'artisan',
      phone: '+91 98231 44521',
      avatarUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=200&auto=format&fit=crop&q=80',
      createdAt: new Date(Date.now() - 90 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'artisan-u2',
      email: 'sunita.potter@everloom.org',
      passwordHash: 'artisan123',
      name: 'Sunita Prajapati',
      role: 'artisan',
      phone: '+91 94152 77890',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
      createdAt: new Date(Date.now() - 60 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'artisan-u3',
      email: 'anamika.madhubani@everloom.org',
      passwordHash: 'artisan123',
      name: 'Anamika Jha',
      role: 'artisan',
      phone: '+91 98350 12044',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      createdAt: new Date(Date.now() - 45 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'buyer-u1',
      email: 'aarav.sharma@gmail.com',
      passwordHash: 'buyer123',
      name: 'Aarav Sharma',
      role: 'buyer',
      phone: '+91 98110 33499',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
      createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    }
  ],
  artisans: [
    {
      id: 'artisan-p1',
      userId: 'artisan-u1',
      craftType: 'Handloom & Banarasi Weaving',
      bio: '5th generation master handloom weaver from Kotwa, Varanasi. Specializing in organic mulberry silk, zari brocades, and pit-loom weaving without electricity.',
      villageOrCity: 'Kotwa, Varanasi',
      state: 'Uttar Pradesh',
      experienceYears: 28,
      cooperativeName: 'Ganga Bunkaar Sangham',
      awards: ['National Handloom Award 2018', 'Sant Kabir Fellowship Nominee'],
      upiId: 'devendra.weaver@okhdfcbank',
      verifiedBadge: true,
      handloomMark: true,
      giTagged: true,
      createdAt: new Date(Date.now() - 90 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'artisan-p2',
      userId: 'artisan-u2',
      craftType: 'Terracotta & Earthen Ceramics',
      bio: 'Terracotta sculptor and potter carrying forward generational soil artistry in Gorakhpur. Using natural river silt and firewood kilns.',
      villageOrCity: 'Aurangabad, Gorakhpur',
      state: 'Uttar Pradesh',
      experienceYears: 19,
      cooperativeName: 'Mitti Shilp Mahila Samiti',
      awards: ['State Craft Excellence 2021'],
      upiId: 'sunita.mitti@okaxis',
      verifiedBadge: true,
      handloomMark: false,
      giTagged: true,
      createdAt: new Date(Date.now() - 60 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'artisan-p3',
      userId: 'artisan-u3',
      craftType: 'Mithila & Madhubani Folk Art',
      bio: 'Mithila artist painting ancestral rituals and folklore on handmade bamboo paper and tussar silk using twigs, nib pens, and natural vegetable dyes.',
      villageOrCity: 'Ranti, Madhubani',
      state: 'Bihar',
      experienceYears: 14,
      cooperativeName: 'Vaidehi Kala Kendra',
      awards: ['Bihar Kala Puraskar 2022'],
      upiId: 'anamika.art@oksbi',
      verifiedBadge: true,
      handloomMark: true,
      giTagged: true,
      createdAt: new Date(Date.now() - 45 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    }
  ],
  products: [
    {
      id: 'prod-1',
      artisanId: 'artisan-p1',
      title: 'Handspun Kadwa Banarasi Silk Dupatta',
      description: 'Handcrafted on a traditional pit loom over 18 days. Features pure Katan silk with gold-silver zari meenakari floral jaal. Soft drape, lightweight, and completely zero-carbon weaving process.',
      artisanStory: 'Each floral motif in this dupatta was woven using the centuries-old Kadwa technique where each buta is hand-engraved individually without loose floats at the back.',
      craftCategory: 'Handloom & Textiles',
      materials: ['Pure Mulberry Silk', 'Natural Gold Zari', 'Organic Indigo Dye'],
      careInstructions: 'Dry clean only. Store wrapped in pure unbleached muslin cloth with neem leaves.',
      tags: ['handloom', 'banarasi', 'kadwa', 'heritage', 'silk', 'sustainable'],
      price: 6450,
      comparePrice: 8500,
      stockQuantity: 4,
      isAvailable: true,
      placement: 'both',
      images: [
        'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1609357605129-26f69add5d6e?w=900&auto=format&fit=crop&q=80'
      ],
      dimensions: '2.5m x 0.9m',
      weightGrams: 320,
      ecoScore: 94,
      carbonFootprintKg: 0.42,
      viewsCount: 142,
      variants: [
        { id: 'v1-1', productId: 'prod-1', name: 'Royal Crimson & Gold', sku: 'BAN-KAD-CRM', price: 6450, stock: 2 },
        { id: 'v1-2', productId: 'prod-1', name: 'Midnight Indigo & Silver', sku: 'BAN-KAD-IND', price: 6450, stock: 2 }
      ],
      createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'prod-2',
      artisanId: 'artisan-p2',
      title: 'Sculpted Terracotta Water Urn with Relief Flora',
      description: 'Hand-thrown earthen water pot crafted with porous riverbed clay. Naturally cools drinking water by 4-6 degrees through evaporation while alkalizing pH levels.',
      artisanStory: 'I gather clay from the banks of the Rapti river right after the monsoon. The relief designs of lotus flowers are etched by hand using bamboo tools carved by my father.',
      craftCategory: 'Terracotta & Pottery',
      materials: ['Natural Alluvial Clay', 'Red Ochre Wash', 'Firewood Fired'],
      careInstructions: 'Rinse with warm water without soap. Air dry under sunlight before storing.',
      tags: ['terracotta', 'pottery', 'natural-cooling', 'alkaline', 'handmade'],
      price: 1250,
      comparePrice: 1600,
      stockQuantity: 12,
      isAvailable: true,
      placement: 'both',
      images: [
        'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=900&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1590736969955-71cc94801759?w=900&auto=format&fit=crop&q=80'
      ],
      dimensions: '30cm height x 22cm diameter (5 Litres)',
      weightGrams: 2800,
      ecoScore: 98,
      carbonFootprintKg: 0.15,
      viewsCount: 230,
      variants: [
        { id: 'v2-1', productId: 'prod-2', name: '5 Litre Traditional Urn', sku: 'TER-URN-5L', price: 1250, stock: 8 },
        { id: 'v2-2', productId: 'prod-2', name: '8 Litre Family Urn', sku: 'TER-URN-8L', price: 1750, stock: 4 }
      ],
      createdAt: new Date(Date.now() - 14 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'prod-3',
      artisanId: 'artisan-p3',
      title: 'Tree of Life - Natural Pigment Madhubani Painting',
      description: 'Authentic Bharni-style Madhubani painting portraying the sacred Kalpavriksha (Tree of Life) with peacocks and river deities. Hand-painted on handmade Lokta fiber paper.',
      artisanStory: 'The colors in this artwork are derived directly from nature: yellow from turmeric, black from lamp soot and cow ghee, green from crushed broad bean leaves, and red from kusum petals.',
      craftCategory: 'Folk & Tribal Painting',
      materials: ['Handmade Bamboo Paper', 'Turmeric Dye', 'Neem Gum Binder', 'Lamp Black'],
      careInstructions: 'Frame under UV-protective museum glass. Avoid prolonged direct moisture.',
      tags: ['madhubani', 'mithila', 'folk-art', 'tree-of-life', 'natural-pigments'],
      price: 4800,
      comparePrice: 6200,
      stockQuantity: 2,
      isAvailable: true,
      placement: 'gallery',
      images: [
        'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=900&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1582561424760-0321d75e81fa?w=900&auto=format&fit=crop&q=80'
      ],
      dimensions: '56cm x 76cm (Unframed)',
      weightGrams: 200,
      ecoScore: 96,
      carbonFootprintKg: 0.08,
      viewsCount: 310,
      variants: [
        { id: 'v3-1', productId: 'prod-3', name: 'Single Artwork (Unframed)', sku: 'MAD-TOL-UF', price: 4800, stock: 2 }
      ],
      createdAt: new Date(Date.now() - 10 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'prod-4',
      artisanId: 'artisan-p1',
      title: 'Chanderi Handloom Cotton-Silk Stole',
      description: 'Feather-light Chanderi stole with traditional ashrafi booti in subtle zari. Woven with unbleached desi cotton warp and sheer katan silk weft.',
      artisanStory: 'Chanderi weavers have woven this translucent fabric since the Vedic times. It takes 3 days of rhythmic hand-pedaling to finish each stole.',
      craftCategory: 'Handloom & Textiles',
      materials: ['Desi Cotton', 'Silk Thread', 'Gold Zari'],
      careInstructions: 'Gentle hand wash with mild reetha nut liquid.',
      tags: ['chanderi', 'cotton-silk', 'handwoven', 'stole', 'sustainable'],
      price: 2150,
      comparePrice: 2800,
      stockQuantity: 6,
      isAvailable: true,
      placement: 'marketplace',
      images: [
        'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=900&auto=format&fit=crop&q=80'
      ],
      dimensions: '2.0m x 0.7m',
      weightGrams: 140,
      ecoScore: 92,
      carbonFootprintKg: 0.28,
      viewsCount: 88,
      variants: [
        { id: 'v4-1', productId: 'prod-4', name: 'Natural Sand & Gold', sku: 'CHN-STL-SND', price: 2150, stock: 4 },
        { id: 'v4-2', productId: 'prod-4', name: 'Pale Sage Green', sku: 'CHN-STL-SGE', price: 2150, stock: 2 }
      ],
      createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    }
  ],
  enquiries: [
    {
      id: 'enq-1',
      productId: 'prod-1',
      buyerId: 'buyer-u1',
      buyerName: 'Aarav Sharma',
      buyerEmail: 'aarav.sharma@gmail.com',
      buyerPhone: '+91 98110 33499',
      quantityRequested: 1,
      status: 'replied',
      messages: [
        {
          id: 'msg-1',
          enquiryId: 'enq-1',
          sender: 'buyer',
          message: 'Namaste Devendra ji. Can you confirm if this Banarasi dupatta is purely handloom certified? I am looking to purchase it for my sister’s wedding.',
          createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
        },
        {
          id: 'msg-2',
          enquiryId: 'enq-1',
          sender: 'artisan',
          message: 'Namaste Aarav ji! Yes, it bears the Government Handloom Mark & GI Tag registered to our Varanasi cluster. It has pure silk hallmarking.',
          createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
        }
      ],
      createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'enq-2',
      productId: 'prod-2',
      buyerId: 'buyer-u1',
      buyerName: 'Meera Deshmukh',
      buyerEmail: 'meera.desh@outlook.com',
      buyerPhone: '+91 98200 45671',
      quantityRequested: 3,
      status: 'open',
      messages: [
        {
          id: 'msg-3',
          enquiryId: 'enq-2',
          sender: 'buyer',
          message: 'Hello Sunita ji, do you ship these terracotta urns with bubble-free eco packaging to Pune? We run an organic café and need 3 pieces.',
          createdAt: new Date(Date.now() - 12 * 3600000).toISOString(),
        }
      ],
      createdAt: new Date(Date.now() - 12 * 3600000).toISOString(),
      updatedAt: new Date().toISOString(),
    }
  ],
  orders: [
    {
      id: 'ord-101',
      buyerId: 'buyer-u1',
      customerName: 'Aarav Sharma',
      customerEmail: 'aarav.sharma@gmail.com',
      customerPhone: '+91 98110 33499',
      shippingAddress: 'Flat 402, Lotus Greens, Sector 78, Noida, Uttar Pradesh - 201301',
      totalAmount: 6450,
      status: 'shipped',
      trackingNumber: 'INPOST-BAN-882910',
      items: [
        {
          id: 'item-1',
          orderId: 'ord-101',
          productId: 'prod-1',
          variantName: 'Royal Crimson & Gold',
          quantity: 1,
          price: 6450
        }
      ],
      createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'ord-102',
      buyerId: undefined,
      customerName: 'Priya Nambiar',
      customerEmail: 'priya.nambiar@gmail.com',
      customerPhone: '+91 98450 11223',
      shippingAddress: '14, Palm Avenue, Indiranagar, Bengaluru, Karnataka - 560038',
      totalAmount: 2500,
      status: 'confirmed',
      trackingNumber: undefined,
      items: [
        {
          id: 'item-2',
          orderId: 'ord-102',
          productId: 'prod-2',
          variantName: '5 Litre Traditional Urn',
          quantity: 2,
          price: 1250
        }
      ],
      createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
    }
  ],
  reviews: [
    {
      id: 'rev-1',
      productId: 'prod-1',
      userName: 'Aarav Sharma',
      rating: 5,
      comment: 'Breathtaking craftsmanship! The weight of the pure silk and the fine zari weave is unmatched by powerloom copies.',
      createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    },
    {
      id: 'rev-2',
      productId: 'prod-2',
      userName: 'Dr. Ramesh K.',
      rating: 5,
      comment: 'Water remains refreshingly cool and tastes sweet. Beautiful rustic centerpiece for the dining table.',
      createdAt: new Date(Date.now() - 8 * 86400000).toISOString(),
    }
  ]
};

class DatabaseRepository {
  private state: DatabaseState;

  constructor() {
    this.state = this.load();
  }

  private load(): DatabaseState {
    try {
      if (fs.existsSync(DB_FILE)) {
        const data = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(data);
      }
    } catch (err) {
      console.warn('Could not read existing store file, initializing seed:', err);
    }
    this.persist(INITIAL_SEED);
    return JSON.parse(JSON.stringify(INITIAL_SEED));
  }

  private persist(data: DatabaseState) {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to persist database state:', err);
    }
  }

  private save() {
    this.persist(this.state);
  }

  // Users & Auth
  findUserByEmail(email: string): User | undefined {
    return this.state.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  findUserById(id: string): User | undefined {
    return this.state.users.find(u => u.id === id);
  }

  createUser(user: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): User {
    const newUser: User = {
      ...user,
      id: `usr-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.state.users.push(newUser);
    this.save();
    return newUser;
  }

  // Artisan Profiles
  findArtisanByUserId(userId: string): ArtisanProfile | undefined {
    return this.state.artisans.find(a => a.userId === userId);
  }

  findArtisanById(id: string): ArtisanProfile | undefined {
    return this.state.artisans.find(a => a.id === id);
  }

  createOrUpdateArtisanProfile(userId: string, data: Partial<ArtisanProfile>): ArtisanProfile {
    const existing = this.findArtisanByUserId(userId);
    if (existing) {
      Object.assign(existing, data, { updatedAt: new Date().toISOString() });
      this.save();
      return existing;
    }
    const newArtisan: ArtisanProfile = {
      id: `art-${Date.now()}`,
      userId,
      craftType: data.craftType || 'Traditional Indian Craft',
      bio: data.bio || '',
      villageOrCity: data.villageOrCity || '',
      state: data.state || '',
      experienceYears: data.experienceYears || 5,
      cooperativeName: data.cooperativeName || '',
      awards: data.awards || [],
      upiId: data.upiId || '',
      verifiedBadge: true,
      handloomMark: Boolean(data.handloomMark),
      giTagged: Boolean(data.giTagged),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.state.artisans.push(newArtisan);
    this.save();
    return newArtisan;
  }

  // Products
  getProducts(filters?: { artisanId?: string; placement?: string; craftCategory?: string; search?: string }): Product[] {
    let result = [...this.state.products];
    if (filters?.artisanId) {
      result = result.filter(p => p.artisanId === filters.artisanId);
    }
    if (filters?.placement && filters.placement !== 'all') {
      result = result.filter(p => p.placement === filters.placement || p.placement === 'both');
    }
    if (filters?.craftCategory && filters.craftCategory !== 'all') {
      result = result.filter(p => p.craftCategory.toLowerCase().includes(filters.craftCategory!.toLowerCase()));
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      result = result.filter(p =>
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    return result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  getProductById(id: string): Product | undefined {
    return this.state.products.find(p => p.id === id);
  }

  createProduct(product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Product {
    const newProduct: Product = {
      ...product,
      id: `prod-${Date.now()}`,
      viewsCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.state.products.push(newProduct);
    this.save();
    return newProduct;
  }

  updateProduct(id: string, updates: Partial<Product>): Product | null {
    const product = this.getProductById(id);
    if (!product) return null;
    Object.assign(product, updates, { updatedAt: new Date().toISOString() });
    this.save();
    return product;
  }

  deleteProduct(id: string): boolean {
    const initialLen = this.state.products.length;
    this.state.products = this.state.products.filter(p => p.id !== id);
    if (this.state.products.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  incrementProductViews(id: string) {
    const product = this.getProductById(id);
    if (product) {
      product.viewsCount = (product.viewsCount || 0) + 1;
      this.save();
    }
  }

  // Enquiries
  getEnquiries(filters?: { artisanId?: string; buyerId?: string; productId?: string }): (Enquiry & { product?: Product })[] {
    let result = [...this.state.enquiries];
    if (filters?.productId) {
      result = result.filter(e => e.productId === filters.productId);
    }
    if (filters?.artisanId) {
      const artisanProductIds = this.state.products.filter(p => p.artisanId === filters.artisanId).map(p => p.id);
      result = result.filter(e => artisanProductIds.includes(e.productId));
    }
    if (filters?.buyerId) {
      result = result.filter(e => e.buyerId === filters.buyerId);
    }
    return result.map(e => ({
      ...e,
      product: this.getProductById(e.productId)
    })).sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  getEnquiryById(id: string): Enquiry | undefined {
    return this.state.enquiries.find(e => e.id === id);
  }

  createEnquiry(data: Omit<Enquiry, 'id' | 'status' | 'messages' | 'createdAt' | 'updatedAt'> & { initialMessage?: string }): Enquiry {
    const newEnq: Enquiry = {
      id: `enq-${Date.now()}`,
      productId: data.productId,
      buyerId: data.buyerId,
      buyerName: data.buyerName,
      buyerEmail: data.buyerEmail,
      buyerPhone: data.buyerPhone,
      quantityRequested: data.quantityRequested || 1,
      status: 'open',
      messages: data.initialMessage ? [{
        id: `msg-${Date.now()}`,
        enquiryId: `enq-${Date.now()}`,
        sender: 'buyer',
        message: data.initialMessage,
        createdAt: new Date().toISOString()
      }] : [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.state.enquiries.push(newEnq);
    this.save();
    return newEnq;
  }

  addEnquiryMessage(enquiryId: string, sender: 'artisan' | 'buyer', message: string): EnquiryMessage | null {
    const enq = this.getEnquiryById(enquiryId);
    if (!enq) return null;
    const msg: EnquiryMessage = {
      id: `msg-${Date.now()}`,
      enquiryId,
      sender,
      message,
      createdAt: new Date().toISOString()
    };
    enq.messages.push(msg);
    enq.updatedAt = new Date().toISOString();
    if (sender === 'artisan') enq.status = 'replied';
    this.save();
    return msg;
  }

  // Orders
  getOrders(artisanId?: string): (Order & { artisanProducts?: Product[] })[] {
    let list = [...this.state.orders];
    if (artisanId) {
      const artisanProductIds = new Set(this.state.products.filter(p => p.artisanId === artisanId).map(p => p.id));
      list = list.filter(o => o.items.some(it => artisanProductIds.has(it.productId)));
    }
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  getOrderById(id: string): Order | undefined {
    return this.state.orders.find(o => o.id === id);
  }

  createOrder(orderData: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>): Order {
    const newOrder: Order = {
      ...orderData,
      id: `ord-${Date.now().toString().slice(-6)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.state.orders.push(newOrder);

    // Deduct stock
    for (const item of newOrder.items) {
      const prod = this.getProductById(item.productId);
      if (prod) {
        prod.stockQuantity = Math.max(0, prod.stockQuantity - item.quantity);
        if (item.variantName) {
          const variant = prod.variants.find(v => v.name === item.variantName);
          if (variant) {
            variant.stock = Math.max(0, variant.stock - item.quantity);
          }
        }
      }
    }
    this.save();
    return newOrder;
  }

  updateOrderStatus(orderId: string, status: Order['status'], trackingNumber?: string): Order | null {
    const order = this.getOrderById(orderId);
    if (!order) return null;
    order.status = status;
    if (trackingNumber) order.trackingNumber = trackingNumber;
    order.updatedAt = new Date().toISOString();
    this.save();
    return order;
  }

  // Reviews
  getProductReviews(productId: string): Review[] {
    return this.state.reviews.filter(r => r.productId === productId);
  }

  addReview(productId: string, userName: string, rating: number, comment: string): Review {
    const review: Review = {
      id: `rev-${Date.now()}`,
      productId,
      userName,
      rating,
      comment,
      createdAt: new Date().toISOString()
    };
    this.state.reviews.push(review);
    this.save();
    return review;
  }
}

export const db = new DatabaseRepository();
