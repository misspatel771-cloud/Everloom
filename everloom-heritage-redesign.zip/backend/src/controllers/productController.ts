import { Request, Response } from 'express';
import { db } from '../repositories/db.ts';
import { sustainabilityService } from '../services/sustainabilityService.ts';

export const getProducts = (req: Request, res: Response) => {
  const { artisanId, placement, craftCategory, search } = req.query;
  const products = db.getProducts({
    artisanId: artisanId as string,
    placement: placement as string,
    craftCategory: craftCategory as string,
    search: search as string,
  });

  const enriched = products.map(p => {
    const artisan = db.findArtisanById(p.artisanId);
    const artisanUser = artisan ? db.findUserById(artisan.userId) : null;
    return {
      ...p,
      artisanName: artisanUser?.name || 'Master Artisan',
      artisanCraft: artisan?.craftType || p.craftCategory,
      artisanLocation: artisan ? `${artisan.villageOrCity}, ${artisan.state}` : 'India'
    };
  });

  return res.json({
    total: enriched.length,
    products: enriched
  });
};

export const getProductById = (req: Request, res: Response) => {
  const { id } = req.params;
  const product = db.getProductById(id);
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }

  db.incrementProductViews(id);
  const artisan = db.findArtisanById(product.artisanId);
  const artisanUser = artisan ? db.findUserById(artisan.userId) : null;
  const reviews = db.getProductReviews(id);

  return res.json({
    product,
    artisan: artisan ? {
      ...artisan,
      name: artisanUser?.name || 'Master Artisan',
      avatarUrl: artisanUser?.avatarUrl
    } : null,
    reviews
  });
};

export const createProduct = (req: Request, res: Response) => {
  try {
    const authHeader = req.headers.authorization;
    let userId = 'artisan-u1';
    if (authHeader && authHeader.startsWith('Bearer everloom_token_')) {
      userId = authHeader.replace('Bearer everloom_token_', '').trim();
    }

    let artisan = db.findArtisanByUserId(userId);
    if (!artisan) {
      artisan = db.createOrUpdateArtisanProfile(userId, { craftType: 'Traditional Craft' });
    }

    const {
      title,
      description,
      artisanStory,
      craftCategory = 'Handloom & Textiles',
      materials = ['Natural Fibers'],
      careInstructions,
      tags = ['artisan', 'handmade'],
      price,
      comparePrice,
      stockQuantity = 1,
      isAvailable = true,
      placement = 'both',
      images = [],
      dimensions,
      weightGrams = 500,
      variants = []
    } = req.body;

    if (!title || !description || price === undefined) {
      return res.status(400).json({ error: 'Title, description, and price are required' });
    }

    // Auto-calculate sustainability metrics
    const sust = sustainabilityService.calculateProductSustainability({
      craftCategory,
      materials,
      weightKg: (weightGrams || 500) / 1000
    });

    const newProduct = db.createProduct({
      artisanId: artisan.id,
      title,
      description,
      artisanStory: artisanStory || '',
      craftCategory,
      materials,
      careInstructions: careInstructions || 'Handle with gentle care.',
      tags,
      price: Number(price),
      comparePrice: comparePrice ? Number(comparePrice) : undefined,
      stockQuantity: Number(stockQuantity),
      isAvailable: Boolean(isAvailable),
      placement: placement as 'gallery' | 'marketplace' | 'both',
      images: images.length > 0 ? images : ['https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=80'],
      dimensions,
      weightGrams: Number(weightGrams),
      ecoScore: sust.ecoScore,
      carbonFootprintKg: sust.totalCarbonFootprintKg,
      variants: variants.map((v: any, index: number) => ({
        id: v.id || `var-${Date.now()}-${index}`,
        productId: '',
        name: v.name || `Variant ${index + 1}`,
        sku: v.sku || `SKU-${Date.now().toString().slice(-4)}`,
        price: Number(v.price || price),
        stock: Number(v.stock || stockQuantity)
      }))
    });

    return res.status(201).json({
      message: 'Product created successfully',
      product: newProduct
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to create product' });
  }
};

export const updateProduct = (req: Request, res: Response) => {
  const { id } = req.params;
  const updated = db.updateProduct(id, req.body);
  if (!updated) {
    return res.status(404).json({ error: 'Product not found' });
  }
  return res.json({
    message: 'Product updated successfully',
    product: updated
  });
};

export const deleteProduct = (req: Request, res: Response) => {
  const { id } = req.params;
  const deleted = db.deleteProduct(id);
  if (!deleted) {
    return res.status(404).json({ error: 'Product not found' });
  }
  return res.json({ message: 'Product removed successfully' });
};

export const updateStock = (req: Request, res: Response) => {
  const { id } = req.params;
  const { stockQuantity, isAvailable } = req.body;
  const updates: any = {};
  if (stockQuantity !== undefined) updates.stockQuantity = Number(stockQuantity);
  if (isAvailable !== undefined) updates.isAvailable = Boolean(isAvailable);

  const updated = db.updateProduct(id, updates);
  if (!updated) {
    return res.status(404).json({ error: 'Product not found' });
  }
  return res.json({
    message: 'Stock updated successfully',
    product: updated
  });
};
