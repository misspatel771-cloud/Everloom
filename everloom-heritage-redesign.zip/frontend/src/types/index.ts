export type Role = 'artisan' | 'buyer' | 'admin';
export type Placement = 'gallery' | 'marketplace' | 'both';
export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  phone?: string;
  avatarUrl?: string;
}

export interface ArtisanProfile {
  id: string;
  userId: string;
  craftType: string;
  bio?: string;
  villageOrCity?: string;
  state?: string;
  experienceYears: number;
  cooperativeName?: string;
  awards: string[];
  upiId?: string;
  verifiedBadge: boolean;
  handloomMark: boolean;
  giTagged: boolean;
}

export interface ProductVariant {
  id: string;
  productId?: string;
  name: string;
  sku?: string;
  price: number;
  stock: number;
}

export interface Product {
  id: string;
  artisanId: string;
  artisanName?: string;
  artisanCraft?: string;
  artisanLocation?: string;
  title: string;
  description: string;
  artisanStory?: string;
  craftCategory: string;
  materials: string[];
  careInstructions?: string;
  tags: string[];
  price: number;
  comparePrice?: number;
  stockQuantity: number;
  isAvailable: boolean;
  placement: Placement;
  images: string[];
  dimensions?: string;
  weightGrams?: number;
  ecoScore: number;
  carbonFootprintKg: number;
  variants: ProductVariant[];
  viewsCount?: number;
  createdAt: string;
  updatedAt: string;
}

export interface EnquiryMessage {
  id: string;
  enquiryId: string;
  sender: 'artisan' | 'buyer' | string;
  message: string;
  createdAt: string;
}

export interface Enquiry {
  id: string;
  productId: string;
  product?: Product;
  buyerId?: string;
  buyerName: string;
  buyerEmail: string;
  buyerPhone?: string;
  quantityRequested: number;
  status: 'open' | 'replied' | 'converted' | 'closed';
  messages: EnquiryMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  id: string;
  orderId: string;
  productId: string;
  variantName?: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: string;
  buyerId?: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  shippingAddress: string;
  totalAmount: number;
  status: OrderStatus;
  trackingNumber?: string;
  items: OrderItem[];
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  totalOrders: number;
  totalSpent: number;
  enquiriesCount: number;
  lastInteracted: string;
  shippingAddress: string;
  type: string;
}

export interface Review {
  id: string;
  productId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface MarketOpportunity {
  id: string;
  title: string;
  craftCategory: string;
  trendScore: number;
  trendDirection: string;
  description: string;
  actionableRecommendation: string;
  urgency: string;
}

export interface PriceComparison {
  craftItem: string;
  everloomArtisanPrice: number;
  marketRetailAverage: number;
  middlemanMarginCutPercent: number;
  sourceNote: string;
  fairTradeAdvantage: string;
}

export interface BuyerMatch {
  id: string;
  buyerEntity: string;
  location: string;
  interestedIn: string;
  orderScale: string;
  verifiedContact: string;
  matchScore: number;
}

export interface SustainabilityReport {
  craftCategory: string;
  totalCarbonFootprintKg: number;
  factoryComparisonKg: number;
  carbonSavedKg: number;
  carbonReductionPercent: number;
  ecoScore: number;
  materialEcoBreakdown: Array<{
    material: string;
    footprintKg: number;
    biodegradable: boolean;
    renewable: boolean;
  }>;
  sustainabilityBadges: string[];
  auditNotes: string;
}
