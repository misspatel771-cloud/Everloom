import React, { useEffect, useState } from 'react';
import { TrendingUp, DollarSign, Target, Award, Sparkles, ArrowUpRight, ShieldCheck, Mail } from 'lucide-react';
import { api } from '../../../api/client.ts';
import { MarketOpportunity, PriceComparison, BuyerMatch } from '../../../types';

export const MarketInsightsModule: React.FC = () => {
  const [opportunities, setOpportunities] = useState<MarketOpportunity[]>([]);
  const [priceComparisons, setPriceComparisons] = useState<PriceComparison[]>([]);
  const [buyerMatches, setBuyerMatches] = useState<BuyerMatch[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchInsights() {
      try {
        setLoading(true);
        const res = await api.insights.get();
        setOpportunities(res.opportunities || []);
        setPriceComparisons(res.priceComparisons || []);
        setBuyerMatches(res.buyerMatches || []);
      } catch (err) {
        console.error('Failed to load market insights:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchInsights();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div>
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-[#D4A359]/20 text-[#8E5E10] border border-[#D4A359]/30">
            Market Linkage Intelligence
          </span>
          <span className="text-xs text-[#7A6B5D]">• Real Artisan Demand Benchmarks</span>
        </div>
        <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19] mt-1">
          Market Insights & Strategic Opportunities
        </h2>
        <p className="text-xs text-[#7A6B5D] mt-1 max-w-2xl leading-relaxed">
          Grounded data on emerging consumer craft trends, transparent middleman margin reductions, and pre-matched institutional buyers.
        </p>
      </div>

      {/* 1. Market Opportunities */}
      <div className="space-y-4">
        <h3 className="font-serif-heritage text-lg font-bold text-[#241E19] flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-[#B84A2A]" />
          <span>High-Growth Craft Opportunities</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {opportunities.map(opp => (
            <div key={opp.id} className="p-6 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm flex flex-col justify-between space-y-4">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-[#FAF0E6] text-[#A65B32] px-2 py-0.5 rounded-full">
                    {opp.craftCategory}
                  </span>
                  <span className="text-xs font-bold text-[#2D5A43] flex items-center gap-0.5">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    Demand: {opp.trendScore}/100
                  </span>
                </div>

                <h4 className="font-bold text-base text-[#241E19] leading-snug">{opp.title}</h4>
                <p className="text-xs text-[#5A4D42] leading-relaxed">{opp.description}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] text-xs">
                <span className="font-bold text-[#8E3015] block mb-1">Recommended Action:</span>
                <p className="text-[#3A2E24]">{opp.actionableRecommendation}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. Transparent Price Comparisons */}
      <div className="space-y-4">
        <div>
          <h3 className="font-serif-heritage text-lg font-bold text-[#241E19] flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-[#2D5A43]" />
            <span>Fair Trade Price Comparisons & Middleman Margin Audits</span>
          </h3>
          <p className="text-xs text-[#7A6B5D] mt-0.5">
            Transparently comparing what you earn vs. what traditional urban boutiques charge with verified source citations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {priceComparisons.map((pc, idx) => (
            <div key={idx} className="p-6 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm space-y-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#7A6B5D]">Benchmarked Craft Item</span>
                <h4 className="font-bold text-sm text-[#241E19] mt-0.5">{pc.craftItem}</h4>
              </div>

              <div className="grid grid-cols-2 gap-3 p-4 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8]">
                <div>
                  <span className="text-[10px] text-[#7A6B5D] block">Your Fair Price</span>
                  <span className="text-xl font-bold text-[#2D5A43]">₹{pc.everloomArtisanPrice.toLocaleString('en-IN')}</span>
                  <span className="text-[10px] text-[#2D5A43] font-semibold block">96% to artisan</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#7A6B5D] block">Urban Retail Avg</span>
                  <span className="text-xl font-bold text-[#7A6B5D] line-through">₹{pc.marketRetailAverage.toLocaleString('en-IN')}</span>
                  <span className="text-[10px] text-[#9E2A2B] font-semibold block">{pc.middlemanMarginCutPercent}% middleman markup</span>
                </div>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="text-[#3A2E24] font-medium flex items-start gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#2D5A43] shrink-0 mt-0.5" />
                  <span>{pc.fairTradeAdvantage}</span>
                </div>
                <p className="text-[11px] text-[#8C7D70] italic border-t border-[#F0EAE1] pt-2">
                  Source: {pc.sourceNote}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Verified Buyer Matching Leads */}
      <div className="space-y-4">
        <div>
          <h3 className="font-serif-heritage text-lg font-bold text-[#241E19] flex items-center gap-2">
            <Target className="w-5 h-5 text-[#25416B]" />
            <span>Pre-Matched Institutional & Boutique Buyers</span>
          </h3>
          <p className="text-xs text-[#7A6B5D] mt-0.5">
            Verified corporate gifting trusts, craft trusts, and boutique retailers looking to purchase direct from artisan clusters.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {buyerMatches.map(bm => (
            <div key={bm.id} className="p-6 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm space-y-4 flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-[#EBF3FB] text-[#25416B] px-2 py-0.5 rounded-full">
                    Match Score: {bm.matchScore}%
                  </span>
                  <span className="text-xs text-[#7A6B5D]">{bm.location}</span>
                </div>

                <h4 className="font-bold text-base text-[#241E19]">{bm.buyerEntity}</h4>
                <p className="text-xs text-[#5A4D42]">
                  <strong>Interested In:</strong> {bm.interestedIn}
                </p>
                <p className="text-xs text-[#5A4D42]">
                  <strong>Target Scale:</strong> {bm.orderScale}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-[#3A2E24] font-medium truncate">
                  <Mail className="w-3.5 h-3.5 text-[#B84A2A]" />
                  <span className="truncate">{bm.verifiedContact}</span>
                </div>
                <a
                  href={`mailto:${bm.verifiedContact}?subject=Everloom Master Artisan Craft Introduction`}
                  className="px-3 py-1 rounded-lg bg-[#241E19] text-white text-[11px] font-bold shrink-0 hover:bg-[#3D332B]"
                >
                  Connect
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
