import React, { useState } from 'react';
import { X, Send, MessageSquare, CheckCircle2 } from 'lucide-react';
import { api } from '../../api/client.ts';
import { Product } from '../../types';

interface EnquiryModalProps {
  product: Product;
  onClose: () => void;
  onSuccess?: () => void;
}

export const EnquiryModal: React.FC<EnquiryModalProps> = ({ product, onClose, onSuccess }) => {
  const [buyerName, setBuyerName] = useState('Aarav Sharma');
  const [buyerEmail, setBuyerEmail] = useState('aarav.sharma@gmail.com');
  const [buyerPhone, setBuyerPhone] = useState('+91 98110 33499');
  const [quantity, setQuantity] = useState(1);
  const [message, setMessage] = useState('Namaste, I am interested in ordering this handcrafted piece. Could you please share details on delivery timeframe and care guidelines?');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSending(true);
      await api.enquiries.create({
        productId: product.id,
        buyerName,
        buyerEmail,
        buyerPhone,
        message,
        quantityRequested: Number(quantity)
      });
      setSent(true);
      if (onSuccess) onSuccess();
      setTimeout(() => onClose(), 2000);
    } catch (err: any) {
      alert(`Failed to send enquiry: ${err.message}`);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-[#E8DFC8] space-y-4">
        <div className="flex items-center justify-between border-b border-[#E8DFC8] pb-4">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#B84A2A]">
              Direct Artisan Linkage
            </span>
            <h3 className="font-serif-heritage text-xl font-bold text-[#241E19]">
              Send Enquiry to Master Artisan
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-[#7A6B5D] hover:bg-[#FAF7F2]">
            <X className="w-5 h-5" />
          </button>
        </div>

        {sent ? (
          <div className="p-8 text-center space-y-3">
            <CheckCircle2 className="w-12 h-12 text-[#2D5A43] mx-auto" />
            <h4 className="font-bold text-base text-[#241E19]">Enquiry Sent to Artisan!</h4>
            <p className="text-xs text-[#7A6B5D]">
              The artisan will review your inquiry in their workspace and respond directly.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {/* Creation summary */}
            <div className="p-3 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] flex items-center gap-3">
              <img src={product.images[0]} alt={product.title} className="w-12 h-12 rounded-lg object-cover" />
              <div>
                <span className="font-bold text-[#241E19] line-clamp-1 block">{product.title}</span>
                <span className="text-[#8E3015] font-semibold">₹{product.price.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-[#4A3E33] mb-1">Your Full Name</label>
                <input
                  type="text"
                  value={buyerName}
                  onChange={(e) => setBuyerName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-[#4A3E33] mb-1">Quantity Needed</label>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-[#4A3E33] mb-1">Email Address</label>
                <input
                  type="email"
                  value={buyerEmail}
                  onChange={(e) => setBuyerEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-[#4A3E33] mb-1">Phone / WhatsApp</label>
                <input
                  type="text"
                  value={buyerPhone}
                  onChange={(e) => setBuyerPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-[#4A3E33] mb-1">Your Question / Message</label>
              <textarea
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3] leading-relaxed"
                required
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#E8DFC8]">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-[#D5C9B3] text-[#4A3E33] hover:bg-[#FAF7F2]"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={sending}
                className="px-5 py-2 rounded-xl bg-[#B84A2A] text-white font-bold hover:bg-[#9E3A1C] flex items-center gap-1.5 disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{sending ? 'Sending...' : 'Send Enquiry'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
