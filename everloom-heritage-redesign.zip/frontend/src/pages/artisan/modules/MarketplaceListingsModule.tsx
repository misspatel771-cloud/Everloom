import React, { useEffect, useState } from 'react';
import { ShoppingBag, Eye, CheckCircle2, Sliders, ExternalLink, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { api } from '../../../api/client.ts';
import { Product } from '../../../types';

export const MarketplaceListingsModule: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [togglingId, setTogglingId] = useState<string | null>(null);

  const fetchListings = async () => {
    try {
      setLoading(true);
      const res = await api.products.list();
      setProducts(res.products || []);
    } catch (err) {
      console.error('Error loading marketplace listings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchListings();
  }, []);

  const handleToggleMarketplace = async (product: Product) => {
    // If currently 'gallery', switch to 'both'; if 'both' or 'marketplace', switch to 'gallery'
    const newPlacement = product.placement === 'gallery' ? 'both' : 'gallery';
    try {
      setTogglingId(product.id);
      const res = await api.products.update(product.id, { placement: newPlacement });
      setProducts(prev => prev.map(p => (p.id === product.id ? res.product : p)));
    } catch (err: any) {
      alert(`Failed to update marketplace listing: ${err.message}`);
    } finally {
      setTogglingId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  const liveOnMarket = products.filter(p => p.placement === 'marketplace' || p.placement === 'both');

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19]">
            Marketplace Listings & Visibility
          </h2>
          <p className="text-xs text-[#7A6B5D] mt-1">
            Control which handcrafted creations are discoverable by prospective buyers and retail boutiques.
          </p>
        </div>

        <Link
          to="/marketplace"
          target="_blank"
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white border border-[#E8DFC8] text-xs font-semibold text-[#4A3E33] hover:bg-[#FAF7F2] transition-colors self-start"
        >
          <span>View Live Public Marketplace</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </Link>
      </div>

      {/* Overview status pills */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Live for Buyers</span>
          <p className="text-2xl font-bold text-[#2D5A43] mt-1">{liveOnMarket.length} products</p>
        </div>
        <div className="p-4 rounded-xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Gallery-Only (Private)</span>
          <p className="text-2xl font-bold text-[#7A6B5D] mt-1">
            {products.filter(p => p.placement === 'gallery').length} products
          </p>
        </div>
        <div className="p-4 rounded-xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Average Fair Margin</span>
          <p className="text-2xl font-bold text-[#B84A2A] mt-1">96.2%</p>
        </div>
      </div>

      {/* Listings Table */}
      <div className="bg-white rounded-2xl border border-[#E8DFC8] shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#FAF7F2] border-b border-[#E8DFC8] text-[#7A6B5D] font-semibold uppercase tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Creation</th>
                <th className="py-3.5 px-4">Market Price</th>
                <th className="py-3.5 px-4">Stock Ready</th>
                <th className="py-3.5 px-4">Marketplace Status</th>
                <th className="py-3.5 px-4 text-right">Visibility Switch</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F0EAE1]">
              {products.map(product => {
                const isLive = product.placement === 'marketplace' || product.placement === 'both';
                const isToggling = togglingId === product.id;

                return (
                  <tr key={product.id} className="hover:bg-[#FAF7F2]/60 transition-colors">
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={product.images[0]}
                          alt={product.title}
                          className="w-11 h-11 rounded-lg object-cover border border-[#E8DFC8]"
                        />
                        <div>
                          <span className="font-bold text-xs text-[#241E19] block truncate max-w-xs">
                            {product.title}
                          </span>
                          <span className="text-[11px] text-[#7A6B5D]">{product.craftCategory}</span>
                        </div>
                      </div>
                    </td>

                    <td className="py-4 px-4">
                      <span className="font-bold text-sm text-[#241E19]">
                        ₹{product.price.toLocaleString('en-IN')}
                      </span>
                    </td>

                    <td className="py-4 px-4">
                      <span className={`font-semibold ${product.stockQuantity <= 2 ? 'text-[#C98A1F]' : 'text-[#2D5A43]'}`}>
                        {product.stockQuantity} units
                      </span>
                    </td>

                    <td className="py-4 px-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                        isLive
                          ? 'bg-[#2D5A43]/10 text-[#2D5A43] border border-[#2D5A43]/20'
                          : 'bg-[#7A6B5D]/10 text-[#7A6B5D] border border-[#7A6B5D]/20'
                      }`}>
                        {isLive ? <CheckCircle2 className="w-3 h-3" /> : null}
                        <span>{isLive ? 'Active in Marketplace' : 'Hidden from Marketplace'}</span>
                      </span>
                    </td>

                    <td className="py-4 px-4 text-right">
                      <button
                        onClick={() => handleToggleMarketplace(product)}
                        disabled={isToggling}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                          isLive
                            ? 'bg-[#FAF0E6] text-[#A65B32] hover:bg-[#F0E0D2]'
                            : 'bg-[#B84A2A] text-white hover:bg-[#9E3A1C]'
                        }`}
                      >
                        {isLive ? 'Unpublish from Market' : 'Publish to Market'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
