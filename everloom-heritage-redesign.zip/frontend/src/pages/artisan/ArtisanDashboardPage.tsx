import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  LayoutDashboard,
  Package,
  ShoppingBag,
  Users,
  Grid,
  Sparkles,
  Compass,
  Store,
  MessageSquare,
  TrendingUp,
  BarChart3,
  Leaf,
  User,
  Settings,
  ChevronRight,
  Menu,
  X
} from 'lucide-react';

import { OverviewModule } from './modules/OverviewModule.tsx';
import { InventoryModule } from './modules/InventoryModule.tsx';
import { OrderManagementModule } from './modules/OrderManagementModule.tsx';
import { CustomerManagementModule } from './modules/CustomerManagementModule.tsx';
import { AllProductsModule } from './modules/AllProductsModule.tsx';
import { AICatalogueModule } from './modules/AICatalogueModule.tsx';
import { DigitalArtGalleryModule } from './modules/DigitalArtGalleryModule.tsx';
import { MarketplaceListingsModule } from './modules/MarketplaceListingsModule.tsx';
import { EnquiriesModule } from './modules/EnquiriesModule.tsx';
import { MarketInsightsModule } from './modules/MarketInsightsModule.tsx';
import { AnalyticsModule } from './modules/AnalyticsModule.tsx';
import { SustainabilityModule } from './modules/SustainabilityModule.tsx';
import { MyProfileModule } from './modules/MyProfileModule.tsx';
import { SettingsModule } from './modules/SettingsModule.tsx';

interface ArtisanDashboardProps {
  initialModule?: string;
  onOpenProductDetail?: (productId: string) => void;
}

export const ArtisanDashboardPage: React.FC<ArtisanDashboardProps> = ({
  initialModule = 'overview',
  onOpenProductDetail
}) => {
  const { t } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();

  // Determine active module based on prop or route
  const [activeModule, setActiveModule] = useState<string>(initialModule);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    // Sync if route specifies sub-path
    if (location.pathname.includes('/artisan/catalogue')) {
      setActiveModule('aiCatalogue');
    } else if (location.pathname.includes('/artisan/inventory')) {
      setActiveModule('inventory');
    } else if (location.pathname.includes('/artisan/orders')) {
      setActiveModule('orders');
    } else if (location.pathname.includes('/artisan/insights')) {
      setActiveModule('insights');
    } else if (location.pathname.includes('/artisan/sustainability')) {
      setActiveModule('sustainability');
    } else if (location.pathname.includes('/artisan/profile')) {
      setActiveModule('profile');
    }
  }, [location.pathname]);

  const modules = [
    { id: 'overview', label: t('dashboard.modules.overview'), icon: LayoutDashboard },
    { id: 'inventory', label: t('dashboard.modules.inventory'), icon: Package },
    { id: 'orders', label: t('dashboard.modules.orders'), icon: ShoppingBag },
    { id: 'customers', label: t('dashboard.modules.customers'), icon: Users },
    { id: 'allProducts', label: t('dashboard.modules.allProducts'), icon: Grid },
    { id: 'aiCatalogue', label: t('dashboard.modules.aiCatalogue'), icon: Sparkles, badge: 'AI Studio' },
    { id: 'gallery', label: t('dashboard.modules.gallery'), icon: Compass },
    { id: 'marketplace', label: t('dashboard.modules.marketplace'), icon: Store },
    { id: 'enquiries', label: t('dashboard.modules.enquiries'), icon: MessageSquare },
    { id: 'insights', label: t('dashboard.modules.insights'), icon: TrendingUp },
    { id: 'analytics', label: t('dashboard.modules.analytics'), icon: BarChart3 },
    { id: 'sustainability', label: t('dashboard.modules.sustainability'), icon: Leaf },
    { id: 'profile', label: t('dashboard.modules.profile'), icon: User },
    { id: 'settings', label: t('dashboard.modules.settings'), icon: Settings },
  ];

  const handleSelectModule = (id: string) => {
    setActiveModule(id);
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] flex flex-col">
      {/* Artisan Top Banner */}
      <div className="bg-[#FAF7F2] border-b border-[#E8DFC8] px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden p-2 rounded-xl bg-white border border-[#E8DFC8] text-[#4A3E33]"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <div>
            <span className="text-[11px] font-bold text-[#8E3015] uppercase tracking-wider block">
              Everloom Artisan Workspace
            </span>
            <h1 className="text-sm font-bold text-[#241E19]">
              {modules.find(m => m.id === activeModule)?.label}
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleSelectModule('aiCatalogue')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C] shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Launch AI Studio</span>
          </button>
        </div>
      </div>

      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex gap-8">
        {/* Sidebar Navigation */}
        <aside
          className={`fixed lg:static inset-y-0 left-0 z-40 w-64 bg-white lg:bg-transparent border-r lg:border-r-0 border-[#E8DFC8] p-4 lg:p-0 transition-transform duration-300 lg:translate-x-0 ${
            sidebarOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full lg:translate-x-0'
          }`}
        >
          <div className="bg-white rounded-2xl border border-[#E8DFC8] p-3 shadow-sm space-y-1">
            <span className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-[#7A6B5D] block">
              14 Artisan Modules
            </span>

            {modules.map(mod => {
              const Icon = mod.icon;
              const isActive = activeModule === mod.id;
              return (
                <button
                  key={mod.id}
                  onClick={() => handleSelectModule(mod.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-[#B84A2A] text-white shadow-sm'
                      : 'text-[#4A3E33] hover:bg-[#FAF7F2] hover:text-[#B84A2A]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{mod.label}</span>
                  </div>
                  {mod.badge && (
                    <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${
                      isActive ? 'bg-white/20 text-white' : 'bg-[#FAF0E6] text-[#A65B32]'
                    }`}>
                      {mod.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </aside>

        {/* Main Module Content Area */}
        <main className="flex-1 min-w-0">
          {activeModule === 'overview' && (
            <OverviewModule onNavigateModule={handleSelectModule} />
          )}
          {activeModule === 'inventory' && <InventoryModule />}
          {activeModule === 'orders' && <OrderManagementModule />}
          {activeModule === 'customers' && <CustomerManagementModule />}
          {activeModule === 'allProducts' && (
            <AllProductsModule
              onOpenCreateStudio={() => handleSelectModule('aiCatalogue')}
              onOpenProductDetail={onOpenProductDetail || ((id) => navigate(`/products/${id}`))}
            />
          )}
          {activeModule === 'aiCatalogue' && (
            <AICatalogueModule
              onPublishSuccess={() => handleSelectModule('allProducts')}
            />
          )}
          {activeModule === 'gallery' && <DigitalArtGalleryModule />}
          {activeModule === 'marketplace' && <MarketplaceListingsModule />}
          {activeModule === 'enquiries' && <EnquiriesModule />}
          {activeModule === 'insights' && <MarketInsightsModule />}
          {activeModule === 'analytics' && <AnalyticsModule />}
          {activeModule === 'sustainability' && <SustainabilityModule />}
          {activeModule === 'profile' && <MyProfileModule />}
          {activeModule === 'settings' && <SettingsModule />}
        </main>
      </div>
    </div>
  );
};
