import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, Leaf, HeartHandshake, Award } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#1F1813] text-[#FAF7F2] border-t border-[#3A2D23] pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Craft Core Commitments Banner */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 pb-12 border-b border-[#3A2D23]">
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-[#B84A2A]/20 text-[#E07A5F]">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-semibold text-sm text-[#F7EFE6]">Direct Artisan Livelihood</h4>
              <p className="text-xs text-[#A8988B] mt-0.5">Eliminating exploitative middlemen so master craftspeople receive 95%+ of proceeds.</p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-[#2D5A43]/30 text-[#85C49F]">
              <Leaf className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-semibold text-sm text-[#F7EFE6]">Verified Low-Carbon Craft</h4>
              <p className="text-xs text-[#A8988B] mt-0.5">Audited manual production with pure river clay, botanical dyes, and handlooms.</p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-[#9B7026]/20 text-[#E8C27B]">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-semibold text-sm text-[#F7EFE6]">GI Tag & Handloom Heritage</h4>
              <p className="text-xs text-[#A8988B] mt-0.5">Authenticity guaranteed with Geographical Indication & Handloom Mark verification.</p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-[#25416B]/30 text-[#8BB2E8]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-semibold text-sm text-[#F7EFE6]">Open & Transparent Pricing</h4>
              <p className="text-xs text-[#A8988B] mt-0.5">Clear breakdown of materials, artisan labor hours, and honest comparative benchmarks.</p>
            </div>
          </div>
        </div>

        {/* Links & Brand Bio */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 py-10">
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#B84A2A] flex items-center justify-center text-white font-bold text-sm">
                E
              </div>
              <span className="font-serif-heritage text-xl font-bold tracking-tight text-[#FAF7F2]">
                EVERLOOM
              </span>
            </div>
            <p className="text-xs text-[#B8A89A] leading-relaxed max-w-sm">
              An AI-driven market linkage and smart cataloguing platform for marginalized and independent artisans across India. Empowering master creators through digital dignity, fair market access, and generational heritage preservation.
            </p>
          </div>

          <div className="md:col-span-2 space-y-2.5">
            <h5 className="text-xs uppercase tracking-wider font-bold text-[#E8C27B]">Artisan Hub</h5>
            <ul className="text-xs space-y-2 text-[#A8988B]">
              <li><Link to="/artisan" className="hover:text-white transition-colors">Artisan Dashboard</Link></li>
              <li><Link to="/artisan/catalogue" className="hover:text-white transition-colors">AI Catalogue Studio</Link></li>
              <li><Link to="/artisan/inventory" className="hover:text-white transition-colors">Inventory Manager</Link></li>
              <li><Link to="/artisan/insights" className="hover:text-white transition-colors">Market Opportunities</Link></li>
              <li><Link to="/artisan/sustainability" className="hover:text-white transition-colors">Eco & Carbon Metrics</Link></li>
            </ul>
          </div>

          <div className="md:col-span-2 space-y-2.5">
            <h5 className="text-xs uppercase tracking-wider font-bold text-[#E8C27B]">Exhibitions</h5>
            <ul className="text-xs space-y-2 text-[#A8988B]">
              <li><Link to="/gallery" className="hover:text-white transition-colors">Digital Art Gallery</Link></li>
              <li><Link to="/marketplace" className="hover:text-white transition-colors">Buyer Marketplace</Link></li>
              <li><Link to="/gallery?craftCategory=Handloom" className="hover:text-white transition-colors">Banarasi Handloom</Link></li>
              <li><Link to="/gallery?craftCategory=Terracotta" className="hover:text-white transition-colors">Gorakhpur Terracotta</Link></li>
              <li><Link to="/gallery?craftCategory=Folk" className="hover:text-white transition-colors">Madhubani Folk Art</Link></li>
            </ul>
          </div>

          <div className="md:col-span-3 space-y-2.5">
            <h5 className="text-xs uppercase tracking-wider font-bold text-[#E8C27B]">Languages Supported</h5>
            <p className="text-xs text-[#A8988B]">
              Everloom is built for linguistic accessibility:
            </p>
            <div className="flex items-center gap-2 pt-1">
              <span className="px-2.5 py-1 rounded bg-[#2D231B] text-xs text-[#E8DFC8] border border-[#3E3125]">English</span>
              <span className="px-2.5 py-1 rounded bg-[#2D231B] text-xs text-[#E8DFC8] border border-[#3E3125] font-devanagari">हिन्दी</span>
              <span className="px-2.5 py-1 rounded bg-[#2D231B] text-xs text-[#E8DFC8] border border-[#3E3125] font-devanagari">मराठी</span>
            </div>
            <p className="text-[11px] text-[#807062] pt-2">
              Empowering artisans in their native language with AI assistance.
            </p>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="border-t border-[#2C2118] pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#7A6B5D]">
          <p>© {new Date().getFullYear()} Everloom. All rights reserved. Handcrafted in India.</p>
          <div className="flex items-center gap-4 mt-2 sm:mt-0">
            <span>Fair Trade Verified</span>
            <span>•</span>
            <span>Zero-Middleman Protocol</span>
            <span>•</span>
            <span>IPCC Tier 1 Eco-Accounting</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
