import { Request, Response } from 'express';
import { db } from '../repositories/db.ts';

export const getAnalytics = (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  let userId = 'artisan-u1';
  if (authHeader && authHeader.startsWith('Bearer everloom_token_')) {
    userId = authHeader.replace('Bearer everloom_token_', '').trim();
  }

  const artisan = db.findArtisanByUserId(userId);
  const products = db.getProducts({ artisanId: artisan?.id });
  const enquiries = db.getEnquiries({ artisanId: artisan?.id });
  const orders = db.getOrders(artisan?.id);

  const totalViews = products.reduce((sum, p) => sum + (p.viewsCount || 0), 0);
  const totalRevenue = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const totalStock = products.reduce((sum, p) => sum + p.stockQuantity, 0);
  const totalEnquiries = enquiries.length;
  const repliedEnquiries = enquiries.filter(e => e.status === 'replied' || e.status === 'converted').length;
  const enquiryResponseRate = totalEnquiries > 0 ? Math.round((repliedEnquiries / totalEnquiries) * 100) : 100;

  // Monthly activity
  const monthlyData = [
    { month: 'Jun', views: 85, enquiries: 3, orders: 1, revenue: 6450 },
    { month: 'Jul', views: 120, enquiries: 5, orders: 2, revenue: 11200 },
    { month: 'Aug', views: 190, enquiries: 8, orders: 3, revenue: 16800 },
    { month: 'Sep', views: 240, enquiries: 12, orders: 4, revenue: 21500 },
    { month: 'Oct', views: totalViews || 310, enquiries: totalEnquiries, orders: orders.length, revenue: totalRevenue }
  ];

  return res.json({
    metrics: {
      totalProducts: products.length,
      totalViews,
      totalEnquiries,
      enquiryResponseRate,
      totalOrders: orders.length,
      totalRevenue,
      totalStockUnits: totalStock,
      averageEcoScore: 94
    },
    monthlyData,
    productPerformance: products.map(p => ({
      id: p.id,
      title: p.title,
      views: p.viewsCount || 0,
      stock: p.stockQuantity,
      placement: p.placement,
      price: p.price
    }))
  });
};
