import React, { useEffect, useState } from 'react';
import { Leaf, Award, ShieldCheck, Calculator, ArrowRight, CheckCircle2, TreePine } from 'lucide-react';
import { api } from '../../../api/client.ts';
import { SustainabilityReport } from '../../../types';

export const SustainabilityModule: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Carbon calculator form state
  const [craftCategory, setCraftCategory] = useState('Handloom & Textiles');
  const [materials, setMaterials] = useState('Pure Mulberry Silk, Organic Desi Cotton');
  const [weightKg, setWeightKg] = useState<number>(0.35);
  const [shippingKm, setShippingKm] = useState<number>(450);
  const [calculating, setCalculating] = useState(false);
  const [calcReport, setCalcReport] = useState<SustainabilityReport | null>(null);

  useEffect(() => {
    async function fetchSust() {
      try {
        setLoading(true);
        const res = await api.sustainability.get();
        setData(res);
      } catch (err) {
        console.error('Failed to load sustainability:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchSust();
  }, []);

  const handleCalculate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setCalculating(true);
      const res = await api.sustainability.calculate({
        craftCategory,
        materials: materials.split(',').map(m => m.trim()),
        weightKg: Number(weightKg),
        shippingKm: Number(shippingKm)
      });
      setCalcReport(res);
    } catch (err: any) {
      alert(`Calculation error: ${err.message}`);
    } finally {
      setCalculating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  const stats = data?.artisanStats || {};

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-[#2D5A43]/15 text-[#2D5A43] border border-[#2D5A43]/30">
            Everloom Eco-Audit Protocol
          </span>
          <span className="text-xs text-[#7A6B5D]">• IPCC Tier 1 Methodology</span>
        </div>
        <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19] mt-1">
          Sustainability & Carbon Accounting
        </h2>
        <p className="text-xs text-[#7A6B5D] mt-1 max-w-2xl leading-relaxed">
          Everloom quantifies the substantial environmental advantage of manual artisanal production compared to automated industrial factories.
        </p>
      </div>

      {/* Verified Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase">Average Eco Score</span>
          <p className="text-3xl font-bold text-[#2D5A43] mt-2">{stats.ecoScoreAverage || 94}/100</p>
          <span className="text-[11px] text-[#7A6B5D] mt-1 block">Grade A Artisan Tier</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase">Estimated CO2e Saved</span>
          <p className="text-3xl font-bold text-[#241E19] mt-2">{stats.lifetimeCarbonSavedKg || 59} kg</p>
          <span className="text-[11px] text-[#2D5A43] font-semibold mt-1 block">vs. Industrial Factories</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase">Plastic-Free Packaging</span>
          <p className="text-3xl font-bold text-[#241E19] mt-2">{stats.plasticFreePackagingRate || '100%'}</p>
          <span className="text-[11px] text-[#7A6B5D] mt-1 block">Raw muslin & recycled cardboard</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase">Trees Saved Equivalent</span>
          <p className="text-3xl font-bold text-[#8E5E10] mt-2 flex items-center gap-1.5">
            <TreePine className="w-6 h-6 text-[#2D5A43]" />
            <span>{stats.estimatedTreesEquivalent || 14}</span>
          </p>
          <span className="text-[11px] text-[#7A6B5D] mt-1 block">Calculated tree absorption</span>
        </div>
      </div>

      {/* Interactive Carbon Calculator */}
      <div className="bg-white rounded-2xl border border-[#E8DFC8] p-6 sm:p-8 shadow-sm space-y-6">
        <div>
          <h3 className="font-serif-heritage text-lg font-bold text-[#241E19] flex items-center gap-2">
            <Calculator className="w-5 h-5 text-[#B84A2A]" />
            <span>Individual Creation Carbon Calculator</span>
          </h3>
          <p className="text-xs text-[#7A6B5D] mt-1">
            Calculate the exact carbon footprint and factory emissions comparison for any creation.
          </p>
        </div>

        <form onSubmit={handleCalculate} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="block font-bold text-[#3A2E24] mb-1">Craft Category</label>
            <select
              value={craftCategory}
              onChange={(e) => setCraftCategory(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3] bg-[#FAF7F2]"
            >
              <option value="Handloom & Textiles">Handloom & Textiles</option>
              <option value="Terracotta & Pottery">Terracotta & Pottery</option>
              <option value="Folk & Tribal Painting">Folk & Tribal Painting</option>
              <option value="Metalcraft & Dhokra">Metalcraft & Dhokra</option>
            </select>
          </div>

          <div>
            <label className="block font-bold text-[#3A2E24] mb-1">Materials Used</label>
            <input
              type="text"
              value={materials}
              onChange={(e) => setMaterials(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
            />
          </div>

          <div>
            <label className="block font-bold text-[#3A2E24] mb-1">Weight (kg)</label>
            <input
              type="number"
              step="0.05"
              value={weightKg}
              onChange={(e) => setWeightKg(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
            />
          </div>

          <div>
            <label className="block font-bold text-[#3A2E24] mb-1">Domestic Transit (km)</label>
            <input
              type="number"
              value={shippingKm}
              onChange={(e) => setShippingKm(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3]"
            />
          </div>

          <div className="sm:col-span-2 lg:col-span-4 flex justify-end">
            <button
              type="submit"
              disabled={calculating}
              className="px-6 py-2.5 rounded-xl bg-[#2D5A43] text-white text-xs font-bold hover:bg-[#234835] shadow-sm flex items-center gap-2"
            >
              <Leaf className="w-4 h-4" />
              <span>{calculating ? 'Auditing Footprint...' : 'Run Carbon Life-Cycle Calculation'}</span>
            </button>
          </div>
        </form>

        {/* Calculation Result Breakdown */}
        {calcReport && (
          <div className="p-6 rounded-2xl bg-[#FAF7F2] border border-[#E8DFC8] space-y-4 animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#2D5A43]">
                  Life-Cycle Assessment Result
                </span>
                <h4 className="font-bold text-lg text-[#241E19]">
                  {calcReport.carbonReductionPercent}% Lower Carbon Footprint than Factory Equivalent
                </h4>
              </div>
              <div className="px-4 py-2 rounded-xl bg-[#2D5A43] text-white text-center">
                <span className="text-[10px] uppercase font-bold block">Assessed Eco Score</span>
                <span className="text-xl font-bold">{calcReport.ecoScore}/100</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-3.5 rounded-xl bg-white border border-[#E8DFC8]">
                <span className="text-[#7A6B5D] block">Artisanal Product Footprint</span>
                <span className="text-xl font-bold text-[#2D5A43] mt-1 block">
                  {calcReport.totalCarbonFootprintKg} kg CO2e
                </span>
              </div>
              <div className="p-3.5 rounded-xl bg-white border border-[#E8DFC8]">
                <span className="text-[#7A6B5D] block">Factory Equivalent Footprint</span>
                <span className="text-xl font-bold text-[#9E2A2B] mt-1 block">
                  {calcReport.factoryComparisonKg} kg CO2e
                </span>
              </div>
              <div className="p-3.5 rounded-xl bg-white border border-[#E8DFC8]">
                <span className="text-[#7A6B5D] block">Net Carbon Saved</span>
                <span className="text-xl font-bold text-[#241E19] mt-1 block">
                  {calcReport.carbonSavedKg} kg CO2e
                </span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-2">
              {calcReport.sustainabilityBadges.map((b, i) => (
                <span key={i} className="px-3 py-1 rounded-full text-[11px] font-bold bg-white text-[#2D5A43] border border-[#2D5A43]/30 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{b}</span>
                </span>
              ))}
            </div>

            <p className="text-[11px] text-[#7A6B5D] italic pt-2 border-t border-[#E8DFC8]">
              {calcReport.auditNotes}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
