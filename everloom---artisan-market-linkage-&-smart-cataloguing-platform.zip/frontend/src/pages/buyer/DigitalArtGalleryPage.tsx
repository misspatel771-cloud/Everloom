import React, { useEffect, useState } from 'react';
import { Compass, QrCode, Share2, Eye, Award, Sparkles, X } from 'lucide-react';
import { api } from '../../api/client.ts';
import { Product } from '../../types';

interface DigitalArtGalleryPageProps {
  onOpenProductDetail: (id: string) => void;
}

export const DigitalArtGalleryPage: React.FC<DigitalArtGalleryPageProps> = ({
  onOpenProductDetail
}) => {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('all');
  const [activeExhibitionModal, setActiveExhibitionModal] = useState<any | null>(null);

  useEffect(() => {
    async function loadGallery() {
      try {
        setLoading(true);
        const res = await api.gallery.list();
        setItems(res.galleryItems || []);
      } catch (err) {
        console.error('Failed to load gallery items:', err);
      } finally {
        setLoading(false);
      }
    }
    loadGallery();
  }, []);

  const categories = [
    { id: 'all', label: 'All Heritage Lineages' },
    { id: 'Handloom', label: 'Varanasi Handloom Silk' },
    { id: 'Terracotta', label: 'Gorakhpur Earthen Pottery' },
    { id: 'Painting', label: 'Mithila & Madhubani Art' },
    { id: 'Metalcraft', label: 'Bastar Lost-Wax Dhokra' }
  ];

  const filtered = activeCategory === 'all'
    ? items
    : items.filter(it => it.craftCategory.toLowerCase().includes(activeCategory.toLowerCase()));

  if (loading) {
    return (
      <div className="flex items-center justify-center p-24">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF7F2] py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Curatorial Pavilion Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#1E2C4A]/10 text-[#1E2C4A] border border-[#1E2C4A]/20 text-xs font-bold uppercase tracking-widest">
            <Compass className="w-3.5 h-3.5" />
            <span>Digital Exhibition Pavilion</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-bold font-serif-heritage text-[#241E19] tracking-tight">
            The Living Hands of India
          </h1>

          <p className="text-xs sm:text-sm text-[#6A5D52] leading-relaxed">
            Welcome to the Everloom Digital Art Gallery — an unhurried, museum-quality visual sanctuary honoring centuries of generational craft wisdom, uncompromised by factory speed.
          </p>

          {/* Curatorial Filters */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                  activeCategory === cat.id
                    ? 'bg-[#1E2C4A] text-white shadow-md'
                    : 'bg-white border border-[#E8DFC8] text-[#4A3E33] hover:bg-[#FAF7F2]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Exhibition Grids (Varied artistic aspect ratios) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map((item, idx) => {
            const isFeatured = idx === 0;

            return (
              <div
                key={item.id}
                onClick={() => setActiveExhibitionModal(item)}
                className={`group cursor-pointer rounded-3xl overflow-hidden bg-white border border-[#E8DFC8] shadow-sm hover:shadow-2xl transition-all duration-300 flex flex-col justify-between ${
                  isFeatured ? 'md:col-span-2 lg:col-span-2' : ''
                }`}
              >
                <div>
                  {/* Photo Canvas */}
                  <div className={`relative overflow-hidden bg-[#241E19] ${isFeatured ? 'aspect-16/9' : 'aspect-4/3'}`}>
                    <img
                      src={item.images[0]}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-95 group-hover:opacity-100"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />

                    <div className="absolute top-4 left-4 flex gap-2">
                      <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-white/20 backdrop-blur-md text-white border border-white/20">
                        {item.craftCategory}
                      </span>
                    </div>

                    <div className="absolute bottom-4 left-4 right-4 text-white">
                      <span className="text-[11px] text-[#E8DFC8] tracking-widest uppercase font-mono block">
                        Specimen #{item.id.slice(-4)} • {item.artisan?.location || 'India'}
                      </span>
                      <h3 className="font-serif-heritage text-xl sm:text-2xl font-bold mt-1 leading-snug">
                        {item.title}
                      </h3>
                    </div>
                  </div>

                  {/* Exhibition Narrative Card */}
                  <div className="p-6 space-y-3">
                    <p className="text-xs text-[#5A4D42] leading-relaxed line-clamp-3">
                      {item.description}
                    </p>

                    {item.artisanStory && (
                      <div className="p-3.5 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] text-xs">
                        <span className="text-[10px] uppercase font-bold text-[#8E3015] block">Master Voice:</span>
                        <p className="italic text-[#4A3E33] line-clamp-2 mt-0.5">"{item.artisanStory}"</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Footer metadata */}
                <div className="px-6 py-4 bg-[#FAF7F2] border-t border-[#E8DFC8] flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-[#B84A2A] text-white flex items-center justify-center font-bold text-[10px]">
                      {item.artisan?.name?.[0] || 'M'}
                    </div>
                    <span className="font-semibold text-[#241E19]">{item.artisan?.name || 'Master Artisan'}</span>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenProductDetail(item.id);
                    }}
                    className="font-bold text-[#B84A2A] hover:underline flex items-center gap-1"
                  >
                    <span>View Provenance</span>
                    <span>→</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal for Curator Exhibition Story */}
        {activeExhibitionModal && (
          <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-[#E8DFC8] space-y-6 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between border-b border-[#E8DFC8] pb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-[#1E2C4A]">
                  Exhibition Provenance Dossier
                </span>
                <button
                  onClick={() => setActiveExhibitionModal(null)}
                  className="p-1.5 rounded-lg text-[#7A6B5D] hover:bg-[#FAF7F2]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="aspect-16/9 rounded-2xl overflow-hidden bg-black">
                <img
                  src={activeExhibitionModal.images[0]}
                  alt={activeExhibitionModal.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold uppercase text-[#8E3015]">
                  {activeExhibitionModal.craftCategory}
                </span>
                <h2 className="font-serif-heritage text-2xl sm:text-3xl font-bold text-[#241E19]">
                  {activeExhibitionModal.title}
                </h2>
                <p className="text-xs text-[#7A6B5D]">
                  Location of creation: {activeExhibitionModal.artisan?.location}
                </p>
              </div>

              <p className="text-xs sm:text-sm text-[#4A3E33] leading-relaxed">
                {activeExhibitionModal.description}
              </p>

              {activeExhibitionModal.artisanStory && (
                <div className="p-5 rounded-2xl bg-[#FAF7F2] border border-[#E8DFC8]">
                  <h4 className="font-bold text-xs uppercase text-[#8E3015] mb-1">
                    Ancestral Craft Tradition & Technique
                  </h4>
                  <p className="text-xs italic text-[#4A3E33] leading-relaxed">
                    "{activeExhibitionModal.artisanStory}"
                  </p>
                </div>
              )}

              <div className="flex items-center justify-between pt-4 border-t border-[#E8DFC8]">
                <div>
                  <span className="text-xs text-[#7A6B5D] block">Fair Valuation</span>
                  <span className="text-2xl font-bold text-[#241E19]">
                    ₹{activeExhibitionModal.price.toLocaleString('en-IN')}
                  </span>
                </div>
                <button
                  onClick={() => {
                    const id = activeExhibitionModal.id;
                    setActiveExhibitionModal(null);
                    onOpenProductDetail(id);
                  }}
                  className="px-6 py-2.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C]"
                >
                  Connect & Purchase Directly
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
