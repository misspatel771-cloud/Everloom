import { Request, Response } from 'express';
import { db } from '../repositories/db.ts';

export const getOrders = (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  let userId = 'artisan-u1';
  if (authHeader && authHeader.startsWith('Bearer everloom_token_')) {
    userId = authHeader.replace('Bearer everloom_token_', '').trim();
  }

  const artisan = db.findArtisanByUserId(userId);
  const orders = db.getOrders(artisan?.id);

  return res.json({ orders });
};

export const createOrder = (req: Request, res: Response) => {
  try {
    const { productId, variantName, quantity = 1, customerName, customerEmail, customerPhone, shippingAddress, notes } = req.body;
    if (!productId || !customerName || !customerEmail || !shippingAddress) {
      return res.status(400).json({ error: 'Product, customer details, and shipping address are required' });
    }

    const product = db.getProductById(productId);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    if (product.stockQuantity < quantity) {
      return res.status(400).json({ error: 'Requested quantity exceeds available stock' });
    }

    const price = product.price;
    const totalAmount = price * Number(quantity);

    const order = db.createOrder({
      customerName,
      customerEmail,
      customerPhone,
      shippingAddress,
      totalAmount,
      status: 'pending',
      items: [
        {
          id: `item-${Date.now()}`,
          orderId: '',
          productId,
          variantName,
          quantity: Number(quantity),
          price
        }
      ]
    });

    return res.status(201).json({
      message: 'Order placed successfully',
      order
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Order creation failed' });
  }
};

export const updateOrderStatus = (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, trackingNumber } = req.body;

  if (!status) {
    return res.status(400).json({ error: 'Status is required' });
  }

  const updated = db.updateOrderStatus(id, status, trackingNumber);
  if (!updated) {
    return res.status(404).json({ error: 'Order not found' });
  }

  return res.json({
    message: 'Order status updated',
    order: updated
  });
};
