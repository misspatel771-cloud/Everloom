import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      brand: 'Everloom',
      tagline: 'Artisan Market Linkage & Smart Cataloguing Platform',
      nav: {
        workspace: 'Artisan Workspace',
        studio: 'AI Studio',
        gallery: 'Digital Art Gallery',
        marketplace: 'Marketplace',
        insights: 'Market Insights',
        login: 'Sign In',
        logout: 'Sign Out',
        register: 'Join as Artisan',
        switchRole: 'Switch View'
      },
      dashboard: {
        title: 'Artisan Studio & Management',
        welcome: 'Namaste',
        quickActions: 'Quick Artisan Actions',
        createCatalogue: 'Launch AI Catalogue Studio',
        viewGallery: 'Open Exhibition Gallery',
        checkEnquiries: 'Buyer Enquiries',
        modules: {
          overview: 'Overview',
          inventory: 'Inventory',
          orders: 'Order Management',
          customers: 'Customer Management',
          allProducts: 'All Products',
          aiCatalogue: 'AI Catalogue Studio',
          gallery: 'Digital Art Gallery',
          marketplace: 'Marketplace Listings',
          enquiries: 'Enquiries & Messages',
          insights: 'Market Insights',
          analytics: 'Analytics',
          sustainability: 'Sustainability',
          profile: 'My Profile',
          settings: 'Settings'
        }
      },
      studio: {
        title: 'Smart AI Catalogue Studio',
        subtitle: 'Turn handmade product photos into professional, heritage-honoring digital catalogues in seconds.',
        steps: {
          upload: '1. Product Photo',
          enhance: '2. Image Studio',
          generate: '3. AI Story & Metadata',
          details: '4. Stock & Variants',
          placement: '5. Placement',
          preview: '6. Review & Publish'
        },
        buttons: {
          enhanceImage: 'Enhance with AI',
          generateText: 'Generate Catalogue Story',
          publish: 'Publish to Everloom',
          saveDraft: 'Save Details'
        }
      },
      common: {
        price: 'Price',
        stock: 'Stock',
        status: 'Status',
        actions: 'Actions',
        save: 'Save Changes',
        cancel: 'Cancel',
        delete: 'Delete',
        edit: 'Edit',
        view: 'View',
        send: 'Send',
        filter: 'Filter',
        search: 'Search...',
        all: 'All',
        loading: 'Loading...'
      }
    }
  },
  hi: {
    translation: {
      brand: 'एवरलूम',
      tagline: 'कारीगर बाज़ार संपर्क एवं स्मार्ट कैटलॉगिंग मंच',
      nav: {
        workspace: 'कारीगर कार्यक्षेत्र',
        studio: 'एआई स्टूडियो',
        gallery: 'डिजिटल कला दीर्घा',
        marketplace: 'कारीगर बाज़ार',
        insights: 'बाज़ार अंतर्दृष्टि',
        login: 'लॉग इन',
        logout: 'लॉग आउट',
        register: 'कारीगर के रूप में जुड़ें',
        switchRole: 'भूमिका बदलें'
      },
      dashboard: {
        title: 'कारीगर स्टूडियो एवं व्यवसाय प्रबंधन',
        welcome: 'नमस्ते',
        quickActions: 'त्वरित कारीगर कार्य',
        createCatalogue: 'एआई कैटलॉग स्टूडियो शुरू करें',
        viewGallery: 'कला प्रदर्शनी खोलें',
        checkEnquiries: 'खरीदार पूछताछ',
        modules: {
          overview: 'अवलोकन',
          inventory: 'इन्वेंट्री / भंडार',
          orders: 'ऑर्डर प्रबंधन',
          customers: 'ग्राहक प्रबंधन',
          allProducts: 'सभी उत्पाद',
          aiCatalogue: 'एआई कैटलॉग स्टूडियो',
          gallery: 'डिजिटल कला दीर्घा',
          marketplace: 'बाज़ार लिस्टिंग',
          enquiries: 'पूछताछ एवं संदेश',
          insights: 'बाज़ार अंतर्दृष्टि',
          analytics: 'विश्लेषिकी (एनालिटिक्स)',
          sustainability: 'पर्यावरणीय प्रभाव',
          profile: 'मेरी प्रोफ़ाइल',
          settings: 'सेटिंग्स'
        }
      },
      studio: {
        title: 'स्मार्ट एआई कैटलॉग स्टूडियो',
        subtitle: 'अपने हस्तनिर्मित उत्पादों की तस्वीरों को कुछ ही पलों में पेशेवर और गरिमापूर्ण डिजिटल कैटलॉग में बदलें।',
        steps: {
          upload: '१. उत्पाद तस्वीर',
          enhance: '२. तस्वीर सुधार',
          generate: '३. एआई विवरण व कथा',
          details: '४. मूल्य व भंडार',
          placement: '५. प्रकाशन स्थान',
          preview: '६. समीक्षा व प्रकाशन'
        },
        buttons: {
          enhanceImage: 'एआई द्वारा तस्वीर निखारें',
          generateText: 'कथा व विवरण तैयार करें',
          publish: 'एवरलूम पर प्रकाशित करें',
          saveDraft: 'सहेजें'
        }
      },
      common: {
        price: 'मूल्य',
        stock: 'उपलब्ध संख्या',
        status: 'स्थिति',
        actions: 'कार्य',
        save: 'सहेजें',
        cancel: 'रद्द करें',
        delete: 'हटाएं',
        edit: 'संपादित करें',
        view: 'देखें',
        send: 'भेजें',
        filter: 'फ़िल्टर',
        search: 'खोजें...',
        all: 'सभी',
        loading: 'प्रतीक्षा करें...'
      }
    }
  },
  mr: {
    translation: {
      brand: 'एव्हरलूम',
      tagline: 'कारागीर बाजार जोडणी व स्मार्ट कॅटलॉगिंग व्यासपीठ',
      nav: {
        workspace: 'कारागीर कार्यक्षेत्र',
        studio: 'एआय स्टुडिओ',
        gallery: 'डिजिटल कला दालन',
        marketplace: 'कारागीर बाजार',
        insights: 'बाजार अंतर्दृष्टी',
        login: 'लॉगिन करा',
        logout: 'बाहेर पडा',
        register: 'कारागीर म्हणून सामील व्हा',
        switchRole: 'भूमिका बदला'
      },
      dashboard: {
        title: 'कारागीर स्टुडिओ आणि व्यवसाय व्यवस्थापन',
        welcome: 'नमस्कार',
        quickActions: 'त्वरित कृती',
        createCatalogue: 'एआय कॅटलॉग स्टुडिओ सुरू करा',
        viewGallery: 'कला दालन उघडा',
        checkEnquiries: 'खरेदीदार चौकशी',
        modules: {
          overview: 'विहंगावलोकन',
          inventory: 'इन्व्हेंटरी व साठा',
          orders: 'ऑर्डर व्यवस्थापन',
          customers: 'ग्राहक व्यवस्थापन',
          allProducts: 'सर्व उत्पादने',
          aiCatalogue: 'एआय कॅटलॉग स्टुडिओ',
          gallery: 'डिजिटल कला दालन',
          marketplace: 'बाजार सूची',
          enquiries: 'चौकशी व संदेश',
          insights: 'बाजार अंतर्दृष्टी',
          analytics: 'विश्लेषण',
          sustainability: 'पर्यावरण शाश्वतता',
          profile: 'माझे प्रोफाइल',
          settings: 'सेटिंग्ज'
        }
      },
      studio: {
        title: 'स्मार्ट एआय कॅटलॉग स्टुडिओ',
        subtitle: 'हस्तनिर्मित वस्तूंच्या फोटोंचे काही सेकंदात व्यावसायिक डिजिटल कॅटलॉगमध्ये रूपांतर करा.',
        steps: {
          upload: '१. वस्तूचा फोटो',
          enhance: '२. फोटो संपादन',
          generate: '३. एआय गोष्ट व माहिती',
          details: '४. किंमत व साठा',
          placement: '५. स्थान निवड',
          preview: '६. पुनरावलोकन व प्रसिद्धी'
        },
        buttons: {
          enhanceImage: 'एआय द्वारे फोटो सुधारा',
          generateText: 'कॅटलॉग माहिती तयार करा',
          publish: 'प्रसिद्ध करा',
          saveDraft: 'जतन करा'
        }
      },
      common: {
        price: 'किंमत',
        stock: 'उपलब्ध साठा',
        status: 'स्थिती',
        actions: 'कृती',
        save: 'जतन करा',
        cancel: 'रद्द करा',
        delete: 'हटवा',
        edit: 'संपादित करा',
        view: 'पहा',
        send: 'पाठवा',
        filter: 'फिल्टर',
        search: 'शोधा...',
        all: 'सर्व',
        loading: 'लोड होत आहे...'
      }
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;
