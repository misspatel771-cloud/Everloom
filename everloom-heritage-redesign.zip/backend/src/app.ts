import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import apiRoutes from './routes/apiRoutes.ts';

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Mount all Everloom API endpoints under /api
app.use('/api', apiRoutes);

// Health check
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'Everloom Artisan Market Linkage & Smart Cataloguing API',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

export default app;
