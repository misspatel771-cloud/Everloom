import React, { useEffect, useState } from 'react';
import { Eye, MessageSquare, ShoppingBag, TrendingUp, BarChart3, Package, ArrowUpRight } from 'lucide-react';
import { api } from '../../../api/client.ts';

export const AnalyticsModule: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchAnalytics() {
      try {
        setLoading(true);
        const res = await api.analytics.get();
        setData(res);
      } catch (err) {
        console.error('Failed to load analytics:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchAnalytics();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  const metrics = data?.metrics || {};
  const monthly = data?.monthlyData || [];
  const performance = data?.productPerformance || [];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19]">
          Artisan Performance Analytics
        </h2>
        <p className="text-xs text-[#7A6B5D] mt-1">
          Monitor your studio visibility, buyer enquiries, conversion rates, and fair-trade revenue over time.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="p-5 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm">
          <div className="flex items-center justify-between text-[#7A6B5D]">
            <span className="text-xs font-semibold uppercase">Total Views</span>
            <Eye className="w-4 h-4 text-[#25416B]" />
          </div>
          <div className="mt-3">
            <span className="text-3xl font-bold text-[#241E19]">{metrics.totalViews || 0}</span>
            <span className="text-xs text-[#2D5A43] ml-2 font-bold">+24% MoM</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm">
          <div className="flex items-center justify-between text-[#7A6B5D]">
            <span className="text-xs font-semibold uppercase">Buyer Enquiries</span>
            <MessageSquare className="w-4 h-4 text-[#B84A2A]" />
          </div>
          <div className="mt-3">
            <span className="text-3xl font-bold text-[#241E19]">{metrics.totalEnquiries || 0}</span>
            <span className="text-xs text-[#7A6B5D] ml-2">({metrics.enquiryResponseRate}% replied)</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm">
          <div className="flex items-center justify-between text-[#7A6B5D]">
            <span className="text-xs font-semibold uppercase">Direct Orders</span>
            <ShoppingBag className="w-4 h-4 text-[#2D5A43]" />
          </div>
          <div className="mt-3">
            <span className="text-3xl font-bold text-[#241E19]">{metrics.totalOrders || 0}</span>
            <span className="text-xs text-[#2D5A43] ml-2 font-bold">100% fulfilled</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm">
          <div className="flex items-center justify-between text-[#7A6B5D]">
            <span className="text-xs font-semibold uppercase">Artisan Payouts</span>
            <TrendingUp className="w-4 h-4 text-[#D4A359]" />
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-bold text-[#241E19]">
              ₹{(metrics.totalRevenue || 0).toLocaleString('en-IN')}
            </span>
          </div>
        </div>
      </div>

      {/* Monthly Chart Visual */}
      <div className="p-6 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm space-y-4">
        <h3 className="font-serif-heritage text-lg font-bold text-[#241E19] flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-[#B84A2A]" />
          <span>Monthly Revenue & Enquiries Growth</span>
        </h3>

        <div className="grid grid-cols-5 gap-3 pt-4">
          {monthly.map((m: any, idx: number) => {
            const heightPercent = Math.min(100, Math.max(25, (m.revenue / 25000) * 100));
            return (
              <div key={idx} className="flex flex-col items-center gap-2">
                <span className="text-xs font-bold text-[#241E19]">₹{(m.revenue / 1000).toFixed(1)}k</span>
                <div className="w-full bg-[#FAF7F2] rounded-xl h-36 flex items-end p-1.5 border border-[#E8DFC8]">
                  <div
                    className="w-full rounded-lg bg-gradient-to-t from-[#8E3015] to-[#B84A2A] transition-all duration-500"
                    style={{ height: `${heightPercent}%` }}
                  />
                </div>
                <span className="text-xs font-semibold text-[#7A6B5D]">{m.month}</span>
                <span className="text-[10px] text-[#A8988B]">{m.views} views</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Product breakdown list */}
      <div className="p-6 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm space-y-4">
        <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">
          Creation Engagement Performance
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#FAF7F2] border-b border-[#E8DFC8] text-[#7A6B5D] font-semibold uppercase">
              <tr>
                <th className="py-3 px-4">Creation Title</th>
                <th className="py-3 px-4">Placement</th>
                <th className="py-3 px-4">Unit Price</th>
                <th className="py-3 px-4">Total Views</th>
                <th className="py-3 px-4">Available Stock</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F0EAE1]">
              {performance.map((p: any) => (
                <tr key={p.id}>
                  <td className="py-3 px-4 font-bold text-[#241E19]">{p.title}</td>
                  <td className="py-3 px-4 uppercase text-[10px] font-bold text-[#8E3015]">{p.placement}</td>
                  <td className="py-3 px-4 font-semibold text-[#241E19]">₹{p.price.toLocaleString('en-IN')}</td>
                  <td className="py-3 px-4">{p.views}</td>
                  <td className="py-3 px-4">{p.stock} units</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
