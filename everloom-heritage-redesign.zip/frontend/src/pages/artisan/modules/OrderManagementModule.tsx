import React, { useEffect, useState } from 'react';
import { ShoppingBag, Truck, CheckCircle2, Clock, MapPin, Phone, Mail, ChevronRight, RefreshCw } from 'lucide-react';
import { api } from '../../../api/client.ts';
import { Order, OrderStatus } from '../../../types';

export const OrderManagementModule: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [trackingInput, setTrackingInput] = useState('');
  const [updating, setUpdating] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const res = await api.orders.list();
      setOrders(res.orders || []);
      if (res.orders && res.orders.length > 0 && !selectedOrder) {
        setSelectedOrder(res.orders[0]);
        setTrackingInput(res.orders[0].trackingNumber || '');
      }
    } catch (err) {
      console.error('Failed to load orders:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleUpdateStatus = async (orderId: string, newStatus: OrderStatus) => {
    try {
      setUpdating(true);
      const res = await api.orders.updateStatus(orderId, newStatus, trackingInput || undefined);
      setOrders(prev => prev.map(o => (o.id === orderId ? res.order : o)));
      setSelectedOrder(res.order);
      setFeedback(`Order status updated to ${newStatus}`);
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(`Error updating order: ${err.message}`);
    } finally {
      setUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  const statusOptions: OrderStatus[] = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19]">
            Order Management & Fulfillment
          </h2>
          <p className="text-xs text-[#7A6B5D] mt-1">
            Track customer orders, manage dispatches, generate tracking references, and verify payments.
          </p>
        </div>
        <button
          onClick={fetchOrders}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-[#E8DFC8] text-xs font-semibold text-[#4A3E33] hover:bg-[#FAF7F2] transition-colors self-start"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Orders</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-[#2D5A43]/10 border border-[#2D5A43]/30 text-[#2D5A43] text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>{feedback}</span>
        </div>
      )}

      {orders.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-[#E8DFC8]">
          <ShoppingBag className="w-12 h-12 text-[#C8B8A6] mx-auto mb-3" />
          <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">No Orders Placed Yet</h3>
          <p className="text-xs text-[#7A6B5D] max-w-sm mx-auto mt-1">
            When buyers purchase through the Marketplace or confirm custom orders, they will appear right here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Orders list column */}
          <div className="lg:col-span-5 space-y-3">
            {orders.map(order => {
              const isSelected = selectedOrder?.id === order.id;
              return (
                <div
                  key={order.id}
                  onClick={() => {
                    setSelectedOrder(order);
                    setTrackingInput(order.trackingNumber || '');
                  }}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-white border-[#B84A2A] shadow-md ring-1 ring-[#B84A2A]/20'
                      : 'bg-white border-[#E8DFC8] hover:border-[#B84A2A]/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-[#241E19]">Order #{order.id}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                      order.status === 'delivered' ? 'bg-[#2D5A43]/10 text-[#2D5A43]' :
                      order.status === 'shipped' ? 'bg-[#25416B]/10 text-[#25416B]' :
                      order.status === 'pending' ? 'bg-[#E8A538]/20 text-[#8E5E10]' :
                      'bg-[#FAF0E6] text-[#A65B32]'
                    }`}>
                      {order.status}
                    </span>
                  </div>

                  <p className="text-xs font-medium text-[#4A3E33] mt-2">
                    {order.customerName}
                  </p>

                  <div className="flex items-center justify-between text-xs mt-2 pt-2 border-t border-[#F0EAE1]">
                    <span className="text-[#7A6B5D]">{order.items.length} item(s)</span>
                    <span className="font-bold text-[#B84A2A]">₹{order.totalAmount.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Selected Order Detail Column */}
          {selectedOrder && (
            <div className="lg:col-span-7 bg-white rounded-2xl border border-[#E8DFC8] p-6 shadow-sm space-y-6">
              <div className="flex items-center justify-between border-b border-[#E8DFC8] pb-4">
                <div>
                  <span className="text-xs text-[#7A6B5D]">Order Reference</span>
                  <h3 className="font-bold text-lg text-[#241E19]">#{selectedOrder.id}</h3>
                  <span className="text-[11px] text-[#7A6B5D]">
                    Placed on: {new Date(selectedOrder.createdAt).toLocaleDateString('en-IN', { dateStyle: 'long' })}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-[#7A6B5D]">Total Payout</span>
                  <div className="text-xl font-bold text-[#2D5A43]">
                    ₹{selectedOrder.totalAmount.toLocaleString('en-IN')}
                  </div>
                  <span className="text-[10px] text-[#2D5A43] font-semibold">100% Direct to Artisan</span>
                </div>
              </div>

              {/* Order Status Action Pipeline */}
              <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] space-y-3">
                <span className="text-xs font-bold text-[#3A2E24] uppercase tracking-wider block">
                  Update Order Progress:
                </span>
                <div className="flex flex-wrap gap-2">
                  {statusOptions.map(st => (
                    <button
                      key={st}
                      disabled={updating}
                      onClick={() => handleUpdateStatus(selectedOrder.id, st)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition-all ${
                        selectedOrder.status === st
                          ? 'bg-[#B84A2A] text-white shadow-sm'
                          : 'bg-white border border-[#D5C9B3] text-[#4A3E33] hover:bg-[#F0EAE1]'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
                  <input
                    type="text"
                    value={trackingInput}
                    onChange={(e) => setTrackingInput(e.target.value)}
                    placeholder="Courier Tracking ID (e.g., INPOST-BAN-9921)"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-[#D5C9B3] bg-white"
                  />
                  <button
                    disabled={updating}
                    onClick={() => handleUpdateStatus(selectedOrder.id, selectedOrder.status)}
                    className="px-4 py-2 rounded-lg bg-[#241E19] text-white text-xs font-semibold shrink-0 hover:bg-[#3D332B]"
                  >
                    Save Tracking
                  </button>
                </div>
              </div>

              {/* Customer Info */}
              <div className="space-y-3">
                <h4 className="font-bold text-xs uppercase tracking-wider text-[#7A6B5D]">
                  Customer & Shipping Destination
                </h4>
                <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] space-y-2 text-xs">
                  <div className="flex items-center gap-2 font-bold text-[#241E19]">
                    <span>{selectedOrder.customerName}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[#4A3E33]">
                    <Mail className="w-3.5 h-3.5 text-[#B84A2A]" />
                    <span>{selectedOrder.customerEmail}</span>
                  </div>
                  {selectedOrder.customerPhone && (
                    <div className="flex items-center gap-2 text-[#4A3E33]">
                      <Phone className="w-3.5 h-3.5 text-[#B84A2A]" />
                      <span>{selectedOrder.customerPhone}</span>
                    </div>
                  )}
                  <div className="flex items-start gap-2 text-[#4A3E33] pt-1 border-t border-[#E8DFC8]">
                    <MapPin className="w-3.5 h-3.5 text-[#B84A2A] shrink-0 mt-0.5" />
                    <span>{selectedOrder.shippingAddress}</span>
                  </div>
                </div>
              </div>

              {/* Items Purchased */}
              <div className="space-y-3">
                <h4 className="font-bold text-xs uppercase tracking-wider text-[#7A6B5D]">
                  Ordered Creations ({selectedOrder.items.length})
                </h4>
                <div className="space-y-2">
                  {selectedOrder.items.map(item => (
                    <div key={item.id} className="p-3 rounded-lg border border-[#E8DFC8] flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-[#241E19] block">Item #{item.productId}</span>
                        {item.variantName && (
                          <span className="text-[11px] text-[#7A6B5D]">Edition: {item.variantName}</span>
                        )}
                        <span className="text-[11px] text-[#7A6B5D] block">Quantity: {item.quantity}</span>
                      </div>
                      <span className="font-bold text-sm text-[#241E19]">
                        ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
