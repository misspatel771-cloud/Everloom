import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Package,
  Eye,
  MessageSquare,
  ShoppingBag,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Leaf,
  AlertTriangle,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { api } from '../../../api/client.ts';
import { Product, Enquiry, Order } from '../../../types';

interface OverviewModuleProps {
  onNavigateModule: (module: string) => void;
}

export const OverviewModule: React.FC<OverviewModuleProps> = ({ onNavigateModule }) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<Product[]>([]);
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const [prodRes, enqRes, ordRes, statRes] = await Promise.all([
          api.products.list(),
          api.enquiries.list(),
          api.orders.list(),
          api.analytics.get()
        ]);
        setProducts(prodRes.products || []);
        setEnquiries(enqRes.enquiries || []);
        setOrders(ordRes.orders || []);
        setStats(statRes.metrics || null);
      } catch (err) {
        console.error('Failed to load overview data:', err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const lowStockItems = products.filter(p => p.stockQuantity <= 2);
  const pendingOrders = orders.filter(o => o.status === 'pending');
  const openEnquiries = enquiries.filter(e => e.status === 'open');

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome & Quick Action Bar */}
      <div className="bg-gradient-to-r from-[#241E19] to-[#38281E] rounded-2xl p-6 sm:p-8 text-[#FAF7F2] shadow-xl relative overflow-hidden">
        <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none translate-x-8 translate-y-8">
          <svg className="w-80 h-80" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
            <path d="M4 6h16M4 12h16M4 18h16M8 2v20M16 2v20" />
          </svg>
        </div>
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold tracking-wider uppercase bg-[#B84A2A]/40 text-[#FAF7F2] border border-[#B84A2A]/50">
              Master Artisan Workspace
            </span>
            <span className="text-xs text-[#C8B8A6]">• Handloom & Heritage Hub</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif-heritage text-[#FAF7F2]">
            {t('dashboard.welcome')}, Devendra Ansari ji
          </h2>
          <p className="text-sm text-[#C8B8A6] mt-2 leading-relaxed">
            Your craft studio is live on Everloom. Manage inventory, enhance creations with AI, respond to buyer enquiries, and showcase directly to conscious collectors worldwide.
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-6">
            <button
              onClick={() => onNavigateModule('aiCatalogue')}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#B84A2A] hover:bg-[#9E3A1C] text-white text-xs font-bold transition-all shadow-md hover:scale-[1.02]"
            >
              <Sparkles className="w-4 h-4" />
              <span>{t('dashboard.createCatalogue')}</span>
            </button>
            <button
              onClick={() => onNavigateModule('gallery')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-[#FAF7F2] text-xs font-semibold border border-white/20 transition-all"
            >
              <span>{t('dashboard.viewGallery')}</span>
            </button>
            <button
              onClick={() => onNavigateModule('insights')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-[#FAF7F2] text-xs font-semibold border border-white/20 transition-all"
            >
              <TrendingUp className="w-4 h-4 text-[#D4A359]" />
              <span>Explore Market Trends</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="bg-white rounded-xl p-5 border border-[#E8DFC8] shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Active Creations</span>
            <div className="p-2 rounded-lg bg-[#FAF2EB] text-[#B84A2A]">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-bold text-[#241E19]">{products.length}</span>
            <span className="text-xs text-[#7A6B5D] ml-2 font-medium">({stats?.totalStockUnits || 24} units in stock)</span>
          </div>
          <div className="mt-2 text-xs text-[#7A6B5D] flex items-center gap-1">
            <span className="text-[#2D5A43] font-semibold">100% handmade</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-[#E8DFC8] shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Digital Views</span>
            <div className="p-2 rounded-lg bg-[#EBF3FB] text-[#25416B]">
              <Eye className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-bold text-[#241E19]">{stats?.totalViews || 482}</span>
            <span className="text-xs text-[#2D5A43] ml-2 font-semibold">+18% this month</span>
          </div>
          <div className="mt-2 text-xs text-[#7A6B5D]">
            <span>Across Gallery & Market</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-[#E8DFC8] shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Buyer Enquiries</span>
            <div className="p-2 rounded-lg bg-[#FAF0E6] text-[#A65B32]">
              <MessageSquare className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-bold text-[#241E19]">{enquiries.length}</span>
            {openEnquiries.length > 0 && (
              <span className="text-xs px-2 py-0.5 ml-2 rounded-full font-bold bg-[#B84A2A]/10 text-[#B84A2A]">
                {openEnquiries.length} New
              </span>
            )}
          </div>
          <div className="mt-2 text-xs text-[#7A6B5D]">
            <span>{stats?.enquiryResponseRate || 100}% response rate</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-[#E8DFC8] shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Orders & Direct Sales</span>
            <div className="p-2 rounded-lg bg-[#EEF7F2] text-[#2D5A43]">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-bold text-[#241E19]">
              ₹{(stats?.totalRevenue || 8950).toLocaleString('en-IN')}
            </span>
          </div>
          <div className="mt-2 text-xs text-[#7A6B5D]">
            <span>{orders.length} direct fair-trade orders</span>
          </div>
        </div>
      </div>

      {/* Actionable Alerts & Opportunities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pending Orders & Stock Warnings */}
        <div className="bg-white rounded-2xl p-6 border border-[#E8DFC8] shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-serif-heritage text-lg font-bold text-[#241E19] flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#B84A2A]" />
              <span>Orders Needing Attention</span>
            </h3>
            <button
              onClick={() => onNavigateModule('orders')}
              className="text-xs font-semibold text-[#B84A2A] hover:underline flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {pendingOrders.length === 0 ? (
            <div className="p-6 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] text-center">
              <CheckCircle2 className="w-8 h-8 text-[#2D5A43] mx-auto mb-2" />
              <p className="text-xs font-semibold text-[#3A2E24]">All orders are up to date!</p>
              <p className="text-[11px] text-[#7A6B5D] mt-1">No pending dispatches or packaging required.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingOrders.map(ord => (
                <div key={ord.id} className="p-4 rounded-xl bg-[#FFF9F5] border border-[#F2D7C7] flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-[#241E19]">Order #{ord.id}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-[#E8A538]/20 text-[#8E5E10] uppercase">
                        {ord.status}
                      </span>
                    </div>
                    <p className="text-xs text-[#5A4D42] mt-1">
                      {ord.customerName} • ₹{ord.totalAmount.toLocaleString('en-IN')}
                    </p>
                  </div>
                  <button
                    onClick={() => onNavigateModule('orders')}
                    className="px-3 py-1.5 rounded-lg bg-[#B84A2A] text-white text-xs font-medium hover:bg-[#9E3A1C]"
                  >
                    Manage
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Low stock callout */}
          {lowStockItems.length > 0 && (
            <div className="mt-4 p-3.5 rounded-xl bg-[#FFFBF0] border border-[#F3E1B8] flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-[#C98A1F] shrink-0 mt-0.5" />
              <div className="text-xs">
                <span className="font-bold text-[#8A5E12]">Low stock warning:</span>
                <span className="text-[#7A5B20] ml-1">
                  {lowStockItems.map(p => p.title).join(', ')} ({lowStockItems.length} items have 2 or fewer units left).
                </span>
                <button
                  onClick={() => onNavigateModule('inventory')}
                  className="block mt-1 font-bold text-[#A86E14] hover:underline"
                >
                  Adjust inventory stock →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Recent Enquiries & Messages */}
        <div className="bg-white rounded-2xl p-6 border border-[#E8DFC8] shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-serif-heritage text-lg font-bold text-[#241E19] flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-[#B84A2A]" />
              <span>Direct Buyer Enquiries</span>
            </h3>
            <button
              onClick={() => onNavigateModule('enquiries')}
              className="text-xs font-semibold text-[#B84A2A] hover:underline flex items-center gap-1"
            >
              <span>Inbox ({enquiries.length})</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-3">
            {enquiries.slice(0, 3).map(enq => (
              <div
                key={enq.id}
                onClick={() => onNavigateModule('enquiries')}
                className="p-3.5 rounded-xl border border-[#E8DFC8] hover:border-[#B84A2A]/40 hover:bg-[#FAF7F2] transition-colors cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#241E19]">{enq.buyerName}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                    enq.status === 'open' ? 'bg-[#B84A2A]/10 text-[#B84A2A]' : 'bg-[#2D5A43]/10 text-[#2D5A43]'
                  }`}>
                    {enq.status}
                  </span>
                </div>
                <p className="text-xs text-[#5A4D42] mt-1.5 line-clamp-2 italic">
                  "{enq.messages[enq.messages.length - 1]?.message || 'Interested in this handcrafted piece.'}"
                </p>
                <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#F0EAE1] text-[11px] text-[#7A6B5D]">
                  <span>Product: {enq.product?.title || 'Heritage Creation'}</span>
                  <span className="text-[#B84A2A] font-semibold">Reply →</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Heritage & Sustainability Highlight */}
      <div className="p-6 rounded-2xl bg-[#F4EFEA] border border-[#DDD3C1] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#2D5A43] text-white flex items-center justify-center shrink-0">
            <Leaf className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-serif-heritage font-bold text-base text-[#241E19]">
              Everloom Green Artisan Accreditation
            </h4>
            <p className="text-xs text-[#6A5E53] mt-0.5">
              Your pit-loom mulberry silk and organic dyes save an estimated <strong>14.8 kg CO2e</strong> per piece compared to mechanized textile mills.
            </p>
          </div>
        </div>
        <button
          onClick={() => onNavigateModule('sustainability')}
          className="px-4 py-2 rounded-xl bg-white border border-[#C8B8A6] text-xs font-bold text-[#2D5A43] hover:bg-[#FAF7F2] shrink-0"
        >
          View Eco Score Audit
        </button>
      </div>
    </div>
  );
};
