import React, { useEffect, useState } from 'react';
import { Users, Mail, Phone, ShoppingBag, MessageSquare, MapPin, Search } from 'lucide-react';
import { api } from '../../../api/client.ts';
import { Customer } from '../../../types';

export const CustomerManagementModule: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    async function fetchCustomers() {
      try {
        setLoading(true);
        const res = await api.customers.list();
        setCustomers(res.customers || []);
      } catch (err) {
        console.error('Failed to load customers:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchCustomers();
  }, []);

  const filtered = customers.filter(c =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.phone.includes(searchTerm)
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19]">
            Customer & Buyer Relations
          </h2>
          <p className="text-xs text-[#7A6B5D] mt-1">
            Build lasting patronage with buyers who have enquired or placed orders for your creations.
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-[#7A6B5D] absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by name, email..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-[#D5C9B3] bg-white focus:outline-none focus:border-[#B84A2A]"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Total Patron Contacts</span>
          <p className="text-2xl font-bold text-[#241E19] mt-1">{customers.length}</p>
        </div>
        <div className="p-4 rounded-xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Confirmed Buyers</span>
          <p className="text-2xl font-bold text-[#2D5A43] mt-1">
            {customers.filter(c => c.totalOrders > 0).length}
          </p>
        </div>
        <div className="p-4 rounded-xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Prospective Enquirers</span>
          <p className="text-2xl font-bold text-[#B84A2A] mt-1">
            {customers.filter(c => c.totalOrders === 0).length}
          </p>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-[#E8DFC8]">
          <Users className="w-12 h-12 text-[#C8B8A6] mx-auto mb-3" />
          <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">No Customers Found</h3>
          <p className="text-xs text-[#7A6B5D] mt-1">
            Buyer records compile automatically when prospective patrons enquire or buy your art.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map(cust => (
            <div key={cust.id} className="p-5 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm hover:border-[#B84A2A]/40 transition-colors space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-[#241E19]">{cust.name}</h4>
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase bg-[#FAF0E6] text-[#A65B32]">
                    {cust.type}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-[#7A6B5D]">Total Spend</span>
                  <p className="font-bold text-sm text-[#241E19]">₹{cust.totalSpent.toLocaleString('en-IN')}</p>
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-[#4A3E33] pt-2 border-t border-[#F0EAE1]">
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-[#B84A2A]" />
                  <span>{cust.email}</span>
                </div>
                {cust.phone && (
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-[#B84A2A]" />
                    <span>{cust.phone}</span>
                  </div>
                )}
                {cust.shippingAddress && cust.shippingAddress !== 'Not specified yet' && (
                  <div className="flex items-start gap-2">
                    <MapPin className="w-3.5 h-3.5 text-[#B84A2A] shrink-0 mt-0.5" />
                    <span className="line-clamp-2">{cust.shippingAddress}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-[#F0EAE1] text-[11px] text-[#7A6B5D]">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1">
                    <ShoppingBag className="w-3 h-3 text-[#2D5A43]" />
                    {cust.totalOrders} order(s)
                  </span>
                  <span className="flex items-center gap-1">
                    <MessageSquare className="w-3 h-3 text-[#B84A2A]" />
                    {cust.enquiriesCount} enquiry
                  </span>
                </div>
                <span>
                  Active: {new Date(cust.lastInteracted).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
