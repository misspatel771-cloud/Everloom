import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, UserPlus, CheckCircle2 } from 'lucide-react';
import { api } from '../../api/client.ts';

interface RegisterPageProps {
  onLoginSuccess: (user: any) => void;
}

export const RegisterPage: React.FC<RegisterPageProps> = ({ onLoginSuccess }) => {
  const navigate = useNavigate();
  const [role, setRole] = useState<'artisan' | 'buyer'>('artisan');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [craftType, setCraftType] = useState('Handloom & Banarasi Weaving');
  const [state, setState] = useState('Uttar Pradesh');
  const [villageOrCity, setVillageOrCity] = useState('Varanasi');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      setError(null);
      const res = await api.auth.register({
        name,
        email,
        password,
        role,
        phone,
        craftType: role === 'artisan' ? craftType : undefined,
        state: role === 'artisan' ? state : undefined,
        villageOrCity: role === 'artisan' ? villageOrCity : undefined
      });
      localStorage.setItem('everloom_token', res.token);
      onLoginSuccess(res.user);
      if (role === 'artisan') {
        navigate('/artisan');
      } else {
        navigate('/marketplace');
      }
    } catch (err: any) {
      setError(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4 bg-[#FAF7F2]">
      <div className="bg-white rounded-3xl border border-[#E8DFC8] p-8 sm:p-10 shadow-xl max-w-lg w-full space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19]">
            Join the Everloom Platform
          </h2>
          <p className="text-xs text-[#7A6B5D]">
            Digitally empower your handmade craft studio or discover verified heritage art.
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-[#9E2A2B]/10 border border-[#9E2A2B]/20 text-[#9E2A2B] text-xs font-semibold">
            {error}
          </div>
        )}

        {/* Role toggle */}
        <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-[#FAF7F2] border border-[#E8DFC8]">
          <button
            type="button"
            onClick={() => setRole('artisan')}
            className={`py-2 rounded-xl text-xs font-bold transition-all ${
              role === 'artisan'
                ? 'bg-[#B84A2A] text-white shadow-sm'
                : 'text-[#4A3E33] hover:text-[#B84A2A]'
            }`}
          >
            I am an Artisan
          </button>
          <button
            type="button"
            onClick={() => setRole('buyer')}
            className={`py-2 rounded-xl text-xs font-bold transition-all ${
              role === 'buyer'
                ? 'bg-[#B84A2A] text-white shadow-sm'
                : 'text-[#4A3E33] hover:text-[#B84A2A]'
            }`}
          >
            I am a Buyer / Patron
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-[#3A2E24] mb-1">Full Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Master Devendra Ansari"
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-[#3A2E24] mb-1">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@email.com"
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-[#3A2E24] mb-1">Phone / WhatsApp</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 ..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-[#3A2E24] mb-1">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
              required
            />
          </div>

          {role === 'artisan' && (
            <div className="p-4 rounded-2xl bg-[#FAF7F2] border border-[#E8DFC8] space-y-3">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#8E3015] block">
                Artisan Studio Onboarding
              </span>

              <div>
                <label className="block font-semibold text-[#3A2E24] mb-1">Craft Tradition</label>
                <select
                  value={craftType}
                  onChange={(e) => setCraftType(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3] bg-white"
                >
                  <option value="Handloom & Banarasi Weaving">Handloom & Banarasi Weaving</option>
                  <option value="Terracotta & Earthen Ceramics">Terracotta & Earthen Ceramics</option>
                  <option value="Mithila & Madhubani Folk Art">Mithila & Madhubani Folk Art</option>
                  <option value="Lost-Wax Dhokra Casting">Lost-Wax Dhokra Casting</option>
                  <option value="Blue Pottery & Tile Work">Blue Pottery & Tile Work</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#3A2E24] mb-1">Village / City</label>
                  <input
                    type="text"
                    value={villageOrCity}
                    onChange={(e) => setVillageOrCity(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3] bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#3A2E24] mb-1">State</label>
                  <input
                    type="text"
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-[#D5C9B3] bg-white"
                  />
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-[#B84A2A] text-white font-bold hover:bg-[#9E3A1C] shadow-md flex items-center justify-center gap-2 text-xs"
          >
            <span>{loading ? 'Creating Account...' : 'Complete Registration'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="text-center text-xs text-[#7A6B5D] pt-2 border-t border-[#E8DFC8]">
          Already have an account?{' '}
          <Link to="/login" className="font-bold text-[#B84A2A] hover:underline">
            Sign In here
          </Link>
        </div>
      </div>
    </div>
  );
};
