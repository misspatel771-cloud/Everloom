import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Sparkles,
  Layers,
  ShoppingBag,
  TrendingUp,
  Globe,
  User,
  Menu,
  X,
  Compass,
  CheckCircle2,
  ChevronDown
} from 'lucide-react';

interface NavbarProps {
  currentRole: 'artisan' | 'buyer';
  onSwitchRole: (role: 'artisan' | 'buyer') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentRole, onSwitchRole }) => {
  const { t, i18n } = useTranslation();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langMenuOpen, setLangMenuOpen] = useState(false);

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    setLangMenuOpen(false);
  };

  const navItems = [
    {
      to: '/artisan',
      label: t('nav.workspace'),
      icon: Layers,
      highlight: currentRole === 'artisan'
    },
    {
      to: '/artisan/catalogue',
      label: t('nav.studio'),
      icon: Sparkles,
      badge: 'AI'
    },
    {
      to: '/gallery',
      label: t('nav.gallery'),
      icon: Compass
    },
    {
      to: '/marketplace',
      label: t('nav.marketplace'),
      icon: ShoppingBag
    },
    {
      to: '/artisan/insights',
      label: t('nav.insights'),
      icon: TrendingUp
    }
  ];

  const currentLangLabel = i18n.language === 'hi' ? 'हिन्दी' : i18n.language === 'mr' ? 'मराठी' : 'English';

  return (
    <header className="sticky top-0 z-50 bg-[#FAF7F2]/95 backdrop-blur-md border-b border-[#E8DFC8]/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#B84A2A] to-[#8E3015] flex items-center justify-center text-[#FAF7F2] shadow-md group-hover:scale-105 transition-transform duration-200">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 6h16M4 12h16M4 18h16" />
                <path d="M8 2v20M16 2v20" />
                <circle cx="12" cy="12" r="2" fill="currentColor" />
              </svg>
            </div>
            <div>
              <span className="font-serif-heritage text-2xl font-bold tracking-tight text-[#241E19] flex items-center gap-1.5">
                EVERLOOM
                <span className="text-xs px-2 py-0.5 rounded-full font-sans font-semibold tracking-normal bg-[#B84A2A]/10 text-[#B84A2A] border border-[#B84A2A]/20">
                  {currentRole === 'artisan' ? 'Artisan Studio' : 'Marketplace'}
                </span>
              </span>
              <p className="text-[10px] text-[#7A6B5D] tracking-wide uppercase font-medium">
                {t('tagline')}
              </p>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.to || (item.to !== '/' && location.pathname.startsWith(item.to) && item.to !== '/artisan');
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-[#B84A2A] text-white shadow-sm'
                      : 'text-[#4A3E33] hover:text-[#B84A2A] hover:bg-[#F0EAE1]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold uppercase ${
                      isActive ? 'bg-white/20 text-white' : 'bg-[#E8DFC8] text-[#8E3015]'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Right Utilities: Language Switcher, Role Switcher, Artisan Profile */}
          <div className="hidden sm:flex items-center gap-3">
            {/* Multilingual Selector */}
            <div className="relative">
              <button
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#D5C9B3] text-xs font-semibold text-[#4A3E33] bg-[#F7F2EA] hover:bg-[#EFE7DC] transition-colors"
                title="Select Language"
              >
                <Globe className="w-3.5 h-3.5 text-[#B84A2A]" />
                <span>{currentLangLabel}</span>
                <ChevronDown className="w-3 h-3 text-[#7A6B5D]" />
              </button>

              {langMenuOpen && (
                <div className="absolute right-0 mt-2 w-36 bg-white rounded-xl shadow-lg border border-[#E8DFC8] py-1 z-50">
                  <button
                    onClick={() => changeLanguage('en')}
                    className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between hover:bg-[#FAF7F2] ${
                      i18n.language === 'en' ? 'font-bold text-[#B84A2A]' : 'text-[#4A3E33]'
                    }`}
                  >
                    <span>English</span>
                    {i18n.language === 'en' && <CheckCircle2 className="w-3.5 h-3.5 text-[#B84A2A]" />}
                  </button>
                  <button
                    onClick={() => changeLanguage('hi')}
                    className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between hover:bg-[#FAF7F2] font-devanagari ${
                      i18n.language === 'hi' ? 'font-bold text-[#B84A2A]' : 'text-[#4A3E33]'
                    }`}
                  >
                    <span>हिन्दी (Hindi)</span>
                    {i18n.language === 'hi' && <CheckCircle2 className="w-3.5 h-3.5 text-[#B84A2A]" />}
                  </button>
                  <button
                    onClick={() => changeLanguage('mr')}
                    className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between hover:bg-[#FAF7F2] font-devanagari ${
                      i18n.language === 'mr' ? 'font-bold text-[#B84A2A]' : 'text-[#4A3E33]'
                    }`}
                  >
                    <span>मराठी (Marathi)</span>
                    {i18n.language === 'mr' && <CheckCircle2 className="w-3.5 h-3.5 text-[#B84A2A]" />}
                  </button>
                </div>
              )}
            </div>

            {/* Quick Role Switch: Artisan Workspace vs Buyer Marketplace */}
            <button
              onClick={() => onSwitchRole(currentRole === 'artisan' ? 'buyer' : 'artisan')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#B84A2A]/30 bg-[#FAF7F2] text-xs font-semibold text-[#8E3015] hover:bg-[#B84A2A]/10 transition-colors"
            >
              <User className="w-3.5 h-3.5" />
              <span>{currentRole === 'artisan' ? 'View as Buyer' : 'Switch to Artisan'}</span>
            </button>

            {/* Artisan Profile Pill */}
            <Link
              to="/artisan/profile"
              className="flex items-center gap-2 pl-2 pr-3 py-1 rounded-full bg-[#EFE7DC] border border-[#D5C9B3] hover:border-[#B84A2A]/50 transition-colors"
            >
              <div className="w-6 h-6 rounded-full bg-[#B84A2A] text-white flex items-center justify-center text-xs font-bold">
                D
              </div>
              <span className="text-xs font-semibold text-[#3A2E24]">
                Devendra A.
              </span>
            </Link>
          </div>

          {/* Mobile hamburger */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-[#4A3E33] hover:bg-[#EFE7DC]"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FAF7F2] border-b border-[#E8DFC8] px-4 pt-2 pb-6 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center justify-between px-4 py-2.5 rounded-lg text-sm font-medium ${
                  isActive
                    ? 'bg-[#B84A2A] text-white'
                    : 'text-[#4A3E33] hover:bg-[#EFE7DC]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-white/20 text-white font-bold">
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}

          <div className="pt-4 border-t border-[#E8DFC8] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => changeLanguage('en')}
                className={`px-2 py-1 text-xs rounded ${i18n.language === 'en' ? 'bg-[#B84A2A] text-white' : 'bg-[#EFE7DC]'}`}
              >
                EN
              </button>
              <button
                onClick={() => changeLanguage('hi')}
                className={`px-2 py-1 text-xs rounded font-devanagari ${i18n.language === 'hi' ? 'bg-[#B84A2A] text-white' : 'bg-[#EFE7DC]'}`}
              >
                हिन्दी
              </button>
              <button
                onClick={() => changeLanguage('mr')}
                className={`px-2 py-1 text-xs rounded font-devanagari ${i18n.language === 'mr' ? 'bg-[#B84A2A] text-white' : 'bg-[#EFE7DC]'}`}
              >
                मराठी
              </button>
            </div>
            <button
              onClick={() => {
                onSwitchRole(currentRole === 'artisan' ? 'buyer' : 'artisan');
                setMobileMenuOpen(false);
              }}
              className="text-xs font-bold text-[#B84A2A] px-3 py-1.5 rounded-lg border border-[#B84A2A]/40"
            >
              {currentRole === 'artisan' ? 'Buyer Mode' : 'Artisan Mode'}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
