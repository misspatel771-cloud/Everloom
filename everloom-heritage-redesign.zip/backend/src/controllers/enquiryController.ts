import { Request, Response } from 'express';
import { db } from '../repositories/db.ts';

export const getEnquiries = (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  let userId = 'artisan-u1';
  if (authHeader && authHeader.startsWith('Bearer everloom_token_')) {
    userId = authHeader.replace('Bearer everloom_token_', '').trim();
  }

  const artisan = db.findArtisanByUserId(userId);
  const enquiries = db.getEnquiries({
    artisanId: artisan?.id,
    buyerId: !artisan ? userId : undefined
  });

  return res.json({ enquiries });
};

export const createEnquiry = (req: Request, res: Response) => {
  try {
    const { productId, buyerName, buyerEmail, buyerPhone, message, quantityRequested = 1 } = req.body;
    if (!productId || !buyerName || !buyerEmail || !message) {
      return res.status(400).json({ error: 'Product ID, name, email, and message are required' });
    }

    const enq = db.createEnquiry({
      productId,
      buyerName,
      buyerEmail,
      buyerPhone,
      quantityRequested: Number(quantityRequested),
      initialMessage: message
    });

    return res.status(201).json({
      message: 'Enquiry sent to artisan successfully',
      enquiry: enq
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to submit enquiry' });
  }
};

export const replyEnquiry = (req: Request, res: Response) => {
  const { id } = req.params;
  const { message, sender = 'artisan' } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message content is required' });
  }

  const msg = db.addEnquiryMessage(id, sender, message);
  if (!msg) {
    return res.status(404).json({ error: 'Enquiry not found' });
  }

  return res.json({
    message: 'Reply sent successfully',
    reply: msg
  });
};
