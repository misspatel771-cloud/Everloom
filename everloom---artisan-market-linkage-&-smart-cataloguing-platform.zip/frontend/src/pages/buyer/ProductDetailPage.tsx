import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ArrowLeft,
  ShoppingBag,
  MessageSquare,
  Leaf,
  Award,
  Star,
  CheckCircle2,
  ShieldCheck,
  Share2,
  Truck
} from 'lucide-react';
import { api } from '../../api/client.ts';
import { Product, Review } from '../../types';

interface ProductDetailPageProps {
  productId?: string;
  onOpenEnquiryModal: (product: Product) => void;
  onOpenOrderModal: (product: Product) => void;
  onBack: () => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  productId: propProductId,
  onOpenEnquiryModal,
  onOpenOrderModal,
  onBack
}) => {
  const params = useParams();
  const id = propProductId || params.id;

  const [product, setProduct] = useState<Product | null>(null);
  const [artisan, setArtisan] = useState<any | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  // New review form state
  const [userName, setUserName] = useState('');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewSuccess, setReviewSuccess] = useState(false);

  useEffect(() => {
    async function fetchDetail() {
      if (!id) return;
      try {
        setLoading(true);
        const res = await api.products.get(id);
        setProduct(res.product);
        setArtisan(res.artisan);
        setReviews(res.reviews || []);
      } catch (err) {
        console.error('Failed to load product details:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchDetail();
  }, [id]);

  const handleAddReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!product || !userName.trim() || !comment.trim()) return;

    try {
      setSubmittingReview(true);
      const res = await api.reviews.create({
        productId: product.id,
        userName,
        rating: Number(rating),
        comment
      });
      setReviews(prev => [res.review, ...prev]);
      setComment('');
      setUserName('');
      setReviewSuccess(true);
      setTimeout(() => setReviewSuccess(false), 3000);
    } catch (err: any) {
      alert(`Review submission error: ${err.message}`);
    } finally {
      setSubmittingReview(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FAF7F2] flex items-center justify-center p-20">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-[#FAF7F2] p-12 text-center">
        <h3 className="text-lg font-bold text-[#241E19]">Product Not Found</h3>
        <button onClick={onBack} className="mt-4 px-4 py-2 rounded-xl bg-[#B84A2A] text-white text-xs font-bold">
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF7F2] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Back Link */}
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-bold text-[#7A6B5D] hover:text-[#B84A2A] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Catalogues</span>
        </button>

        {/* Main Product Showcase Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Photo Gallery Column */}
          <div className="lg:col-span-6 space-y-4">
            <div className="aspect-square rounded-3xl overflow-hidden bg-white border border-[#E8DFC8] shadow-md relative">
              <img
                src={product.images[0]}
                alt={product.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4 flex gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-[#2D5A43] text-white shadow-sm flex items-center gap-1">
                  <Leaf className="w-3.5 h-3.5" />
                  <span>Eco Score: {product.ecoScore}/100</span>
                </span>
              </div>
            </div>

            {product.images.length > 1 && (
              <div className="grid grid-cols-3 gap-3">
                {product.images.map((img, i) => (
                  <div key={i} className="aspect-square rounded-2xl overflow-hidden border border-[#E8DFC8]">
                    <img src={img} alt="Thumb" className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Details & Action Column */}
          <div className="lg:col-span-6 space-y-6">
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-[#8E3015] uppercase tracking-wider mb-1">
                <span>{product.craftCategory}</span>
                <span>{artisan?.villageOrCity ? `${artisan.villageOrCity}, ${artisan.state}` : 'India'}</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold font-serif-heritage text-[#241E19] leading-snug">
                {product.title}
              </h1>
            </div>

            {/* Price section with middleman transparency */}
            <div className="p-4 rounded-2xl bg-white border border-[#E8DFC8] shadow-sm flex items-center justify-between">
              <div>
                <span className="text-[11px] text-[#7A6B5D] block">Artisan Fair-Trade Direct Price</span>
                <div className="flex items-baseline gap-2 mt-0.5">
                  <span className="text-3xl font-bold text-[#241E19]">
                    ₹{product.price.toLocaleString('en-IN')}
                  </span>
                  {product.comparePrice && (
                    <span className="text-xs text-[#7A6B5D] line-through">
                      ₹{product.comparePrice.toLocaleString('en-IN')}
                    </span>
                  )}
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs font-bold text-[#2D5A43] block">Zero Middleman Cut</span>
                <span className="text-[11px] text-[#7A6B5D]">96% goes directly to artisan</span>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <h3 className="font-bold text-xs uppercase tracking-wider text-[#7A6B5D]">Creation Details</h3>
              <p className="text-xs sm:text-sm text-[#4A3E33] leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Artisan story */}
            {product.artisanStory && (
              <div className="p-4 rounded-2xl bg-[#FAF7F2] border border-[#E8DFC8] space-y-1">
                <span className="font-bold text-xs uppercase tracking-wider text-[#8E3015] block">
                  Artisan Heritage Provenance
                </span>
                <p className="text-xs italic text-[#5A4D42] leading-relaxed">
                  "{product.artisanStory}"
                </p>
              </div>
            )}

            {/* Attributes table */}
            <div className="grid grid-cols-2 gap-4 text-xs p-4 rounded-2xl bg-white border border-[#E8DFC8]">
              <div>
                <span className="text-[#7A6B5D] block">Materials:</span>
                <span className="font-semibold text-[#241E19]">{product.materials.join(', ')}</span>
              </div>
              <div>
                <span className="text-[#7A6B5D] block">Dimensions:</span>
                <span className="font-semibold text-[#241E19]">{product.dimensions || 'Handmade standard'}</span>
              </div>
              <div className="pt-2 border-t border-[#F0EAE1]">
                <span className="text-[#7A6B5D] block">Care Guide:</span>
                <span className="font-semibold text-[#241E19]">{product.careInstructions || 'Dry gentle cleaning'}</span>
              </div>
              <div className="pt-2 border-t border-[#F0EAE1]">
                <span className="text-[#7A6B5D] block">Carbon Footprint:</span>
                <span className="font-bold text-[#2D5A43]">{product.carbonFootprintKg} kg CO2e</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
              <button
                onClick={() => onOpenEnquiryModal(product)}
                className="w-full sm:flex-1 py-3 rounded-xl bg-white border border-[#D5C9B3] text-xs font-bold text-[#4A3E33] hover:bg-[#FAF7F2] flex items-center justify-center gap-2 transition-colors"
              >
                <MessageSquare className="w-4 h-4 text-[#B84A2A]" />
                <span>Enquire with Artisan</span>
              </button>

              <button
                onClick={() => onOpenOrderModal(product)}
                className="w-full sm:flex-1 py-3 rounded-xl bg-[#B84A2A] hover:bg-[#9E3A1C] text-white text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md hover:scale-[1.02]"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Direct Purchase & Order</span>
              </button>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="p-8 rounded-3xl bg-white border border-[#E8DFC8] shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-[#E8DFC8] pb-4">
            <div>
              <h3 className="font-serif-heritage text-xl font-bold text-[#241E19]">
                Patron Reviews & Testimonials
              </h3>
              <p className="text-xs text-[#7A6B5D] mt-0.5">
                Authentic buyer experiences supporting this artisan creation.
              </p>
            </div>
            <span className="text-xs font-bold text-[#B84A2A]">{reviews.length} review(s)</span>
          </div>

          {reviewSuccess && (
            <div className="p-3 rounded-xl bg-[#2D5A43]/10 border border-[#2D5A43]/30 text-[#2D5A43] text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>Your patron review has been posted!</span>
            </div>
          )}

          {/* List existing reviews */}
          <div className="space-y-4">
            {reviews.map(rev => (
              <div key={rev.id} className="p-4 rounded-2xl bg-[#FAF7F2] border border-[#E8DFC8] space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#241E19]">{rev.userName}</span>
                  <div className="flex items-center text-[#D4A359]">
                    {[...Array(rev.rating || 5)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-[#D4A359]" />
                    ))}
                  </div>
                </div>
                <p className="text-[#4A3E33] leading-relaxed">{rev.comment}</p>
                <span className="text-[10px] text-[#A8988B] block mt-1">
                  {new Date(rev.createdAt).toLocaleDateString('en-IN', { dateStyle: 'medium' })}
                </span>
              </div>
            ))}
          </div>

          {/* Write a review form */}
          <form onSubmit={handleAddReview} className="p-6 rounded-2xl bg-[#FAF7F2] border border-[#E8DFC8] space-y-3 text-xs">
            <h4 className="font-bold text-sm text-[#241E19]">Leave an Artisan Review</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="Your Name (e.g., Dr. Ramesh K.)"
                className="px-3.5 py-2 rounded-xl border border-[#D5C9B3] bg-white"
                required
              />
              <select
                value={rating}
                onChange={(e) => setRating(Number(e.target.value))}
                className="px-3.5 py-2 rounded-xl border border-[#D5C9B3] bg-white font-semibold"
              >
                <option value="5">★★★★★ (5 Stars - Exceptional Craft)</option>
                <option value="4">★★★★☆ (4 Stars - Great Quality)</option>
                <option value="3">★★★☆☆ (3 Stars - Average)</option>
              </select>
            </div>
            <textarea
              rows={2}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Describe the tactile feel, weave texture, or artisan story..."
              className="w-full px-3.5 py-2 rounded-xl border border-[#D5C9B3] bg-white"
              required
            />
            <button
              type="submit"
              disabled={submittingReview}
              className="px-5 py-2 rounded-xl bg-[#241E19] text-white font-bold hover:bg-[#3D332B]"
            >
              Post Patron Review
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
