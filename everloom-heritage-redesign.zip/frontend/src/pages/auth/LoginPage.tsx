import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Lock, ArrowRight, ShieldCheck, Check } from 'lucide-react';
import { api } from '../../api/client.ts';

interface LoginPageProps {
  onLoginSuccess: (user: any) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('devendra.weaver@everloom.org');
  const [password, setPassword] = useState('artisan123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      setError(null);
      const res = await api.auth.login({ email, password });
      localStorage.setItem('everloom_token', res.token);
      onLoginSuccess(res.user);
      if (res.user.role === 'artisan') {
        navigate('/artisan');
      } else {
        navigate('/marketplace');
      }
    } catch (err: any) {
      setError(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemo = (role: 'artisan' | 'buyer') => {
    if (role === 'artisan') {
      setEmail('devendra.weaver@everloom.org');
      setPassword('artisan123');
    } else {
      setEmail('aarav.sharma@gmail.com');
      setPassword('buyer123');
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4 bg-[#FAF7F2]">
      <div className="bg-white rounded-3xl border border-[#E8DFC8] p-8 sm:p-10 shadow-xl max-w-md w-full space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-[#B84A2A] text-white flex items-center justify-center mx-auto shadow-md font-serif-heritage text-xl font-bold">
            E
          </div>
          <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19]">
            Sign In to Everloom
          </h2>
          <p className="text-xs text-[#7A6B5D]">
            Access your artisan workspace, AI studio, and orders.
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-[#9E2A2B]/10 border border-[#9E2A2B]/20 text-[#9E2A2B] text-xs font-semibold">
            {error}
          </div>
        )}

        {/* One-click demo roles */}
        <div className="p-3 rounded-2xl bg-[#FAF7F2] border border-[#E8DFC8] space-y-2">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#7A6B5D] block">
            Instant Demo Credentials:
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleQuickDemo('artisan')}
              className="py-1.5 px-2.5 rounded-lg border border-[#B84A2A]/40 bg-white text-[11px] font-bold text-[#8E3015] hover:bg-[#FAF7F2]"
            >
              Master Artisan (Devendra)
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemo('buyer')}
              className="py-1.5 px-2.5 rounded-lg border border-[#D5C9B3] bg-white text-[11px] font-semibold text-[#4A3E33] hover:bg-[#FAF7F2]"
            >
              Buyer (Aarav)
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-[#3A2E24] mb-1">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
              required
            />
          </div>

          <div>
            <label className="block font-semibold text-[#3A2E24] mb-1">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D5C9B3]"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-[#B84A2A] text-white font-bold hover:bg-[#9E3A1C] shadow-md flex items-center justify-center gap-2 text-xs"
          >
            <span>{loading ? 'Authenticating...' : 'Sign In'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="text-center text-xs text-[#7A6B5D] pt-2 border-t border-[#E8DFC8]">
          Don't have an artisan studio account?{' '}
          <Link to="/register" className="font-bold text-[#B84A2A] hover:underline">
            Register as Artisan
          </Link>
        </div>
      </div>
    </div>
  );
};
