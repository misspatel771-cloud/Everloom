import React, { useEffect, useState } from 'react';
import { Compass, QrCode, Share2, Eye, Award, CheckCircle2, X } from 'lucide-react';
import { api } from '../../../api/client.ts';
import { Product } from '../../../types';

export const DigitalArtGalleryModule: React.FC = () => {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('all');
  const [selectedExhibitionItem, setSelectedExhibitionItem] = useState<any | null>(null);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [qrTargetItem, setQrTargetItem] = useState<any | null>(null);

  useEffect(() => {
    async function fetchGallery() {
      try {
        setLoading(true);
        const res = await api.gallery.list();
        setItems(res.galleryItems || []);
      } catch (err) {
        console.error('Failed to load gallery:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchGallery();
  }, []);

  const categories = ['all', 'Handloom & Textiles', 'Terracotta & Pottery', 'Folk & Tribal Painting', 'Metalcraft & Dhokra'];

  const filtered = activeCategory === 'all'
    ? items
    : items.filter(it => it.craftCategory.toLowerCase().includes(activeCategory.toLowerCase()));

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-[#25416B]/10 text-[#25416B]">
              Visual Exhibition Space
            </span>
          </div>
          <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19] mt-1">
            Artisan Digital Art Gallery
          </h2>
          <p className="text-xs text-[#7A6B5D] mt-1">
            A dignified, museum-grade exhibition space spotlighting high-resolution handmade photography and master lineage stories.
          </p>
        </div>

        {/* Categories pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                activeCategory === cat
                  ? 'bg-[#B84A2A] text-white shadow-sm'
                  : 'bg-white border border-[#E8DFC8] text-[#4A3E33] hover:bg-[#FAF7F2]'
              }`}
            >
              {cat === 'all' ? 'All Traditions' : cat}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-[#E8DFC8]">
          <Compass className="w-12 h-12 text-[#C8B8A6] mx-auto mb-3" />
          <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">Gallery Exhibition Empty</h3>
          <p className="text-xs text-[#7A6B5D] mt-1">
            Publish products with placement set to "My Gallery" or "Both" to display them here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map(item => (
            <div
              key={item.id}
              className="bg-white rounded-2xl border border-[#E8DFC8] overflow-hidden shadow-sm hover:shadow-lg transition-all group flex flex-col justify-between"
            >
              <div>
                {/* Photo showcase */}
                <div className="relative aspect-4/3 overflow-hidden bg-[#FAF7F2]">
                  <img
                    src={item.images[0]}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3 flex gap-1.5">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-black/60 backdrop-blur-md text-white">
                      {item.craftCategory}
                    </span>
                  </div>
                  <div className="absolute bottom-3 right-3 flex gap-1.5">
                    <button
                      onClick={() => {
                        setQrTargetItem(item);
                        setQrModalOpen(true);
                      }}
                      className="p-2 rounded-xl bg-white/90 backdrop-blur-md hover:bg-white text-[#241E19] shadow-md transition-colors"
                      title="Shareable QR Exhibition Card"
                    >
                      <QrCode className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Narrative Details */}
                <div className="p-5 space-y-3">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#B84A2A]">
                      Master Creation
                    </span>
                    <h3 className="font-serif-heritage font-bold text-lg text-[#241E19] mt-0.5">
                      {item.title}
                    </h3>
                  </div>

                  <p className="text-xs text-[#6A5D52] line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>

                  {item.artisanStory && (
                    <div className="p-3 rounded-xl bg-[#FAF7F2] border border-[#E8DFC8] text-xs">
                      <span className="font-bold text-[#8E3015] block text-[10px] uppercase">Heritage Lineage:</span>
                      <p className="italic text-[#5A4D42] line-clamp-2 mt-0.5">"{item.artisanStory}"</p>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-xs pt-2 border-t border-[#F0EAE1]">
                    <span className="text-[#7A6B5D]">Exhibition Value</span>
                    <span className="font-bold text-[#241E19]">₹{item.price.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>

              {/* View full exhibition narrative */}
              <div className="p-4 bg-[#FAF7F2] border-t border-[#E8DFC8] flex items-center justify-between">
                <span className="text-[11px] font-semibold text-[#7A6B5D] flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-[#D4A359]" />
                  <span>GI & Handloom Verified</span>
                </span>
                <button
                  onClick={() => setSelectedExhibitionItem(item)}
                  className="text-xs font-bold text-[#B84A2A] hover:underline flex items-center gap-1"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Curator Story</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Curator Story Modal */}
      {selectedExhibitionItem && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-[#E8DFC8] space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#E8DFC8] pb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-[#B84A2A]">
                Digital Gallery Exhibition Specimen
              </span>
              <button
                onClick={() => setSelectedExhibitionItem(null)}
                className="p-1.5 rounded-lg text-[#7A6B5D] hover:bg-[#FAF7F2]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="aspect-16/9 rounded-2xl overflow-hidden bg-[#FAF7F2]">
              <img
                src={selectedExhibitionItem.images[0]}
                alt={selectedExhibitionItem.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div>
              <span className="text-xs font-bold uppercase text-[#8E3015]">{selectedExhibitionItem.craftCategory}</span>
              <h3 className="font-serif-heritage text-2xl font-bold text-[#241E19] mt-1">{selectedExhibitionItem.title}</h3>
            </div>

            <p className="text-xs text-[#4A3E33] leading-relaxed">
              {selectedExhibitionItem.description}
            </p>

            {selectedExhibitionItem.artisanStory && (
              <div className="p-4 rounded-2xl bg-[#FAF7F2] border border-[#E8DFC8]">
                <h5 className="font-bold text-xs uppercase text-[#8E3015] mb-1">Artisan Heritage Story</h5>
                <p className="text-xs italic text-[#5A4D42] leading-relaxed">"{selectedExhibitionItem.artisanStory}"</p>
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-[#E8DFC8]">
              <div>
                <span className="text-xs text-[#7A6B5D]">Artisan Master</span>
                <p className="font-bold text-sm text-[#241E19]">
                  {selectedExhibitionItem.artisan?.name || 'Devendra Ansari'}
                </p>
              </div>
              <button
                onClick={() => {
                  setQrTargetItem(selectedExhibitionItem);
                  setQrModalOpen(true);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#241E19] text-white text-xs font-semibold hover:bg-[#3D332B]"
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>Show QR Exhibition Card</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QR Code Exhibition Modal */}
      {qrModalOpen && qrTargetItem && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#FAF7F2] rounded-3xl max-w-sm w-full p-6 text-center border-2 border-[#E8DFC8] shadow-2xl space-y-4">
            <div className="flex justify-end">
              <button onClick={() => setQrModalOpen(false)} className="text-[#7A6B5D] hover:text-[#241E19]">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="w-12 h-12 rounded-xl bg-[#B84A2A] text-white flex items-center justify-center mx-auto shadow-md">
              <Compass className="w-6 h-6" />
            </div>

            <h3 className="font-serif-heritage text-lg font-bold text-[#241E19]">
              Everloom Smart QR Catalogue
            </h3>

            {/* Render realistic stylized QR placeholder matrix */}
            <div className="p-6 bg-white rounded-2xl border border-[#E8DFC8] shadow-inner inline-block mx-auto">
              <div className="w-44 h-44 relative bg-[#241E19] p-3 rounded-lg flex flex-col justify-between">
                <div className="flex justify-between">
                  <div className="w-10 h-10 border-4 border-white bg-[#241E19] flex items-center justify-center">
                    <div className="w-4 h-4 bg-white" />
                  </div>
                  <div className="w-10 h-10 border-4 border-white bg-[#241E19] flex items-center justify-center">
                    <div className="w-4 h-4 bg-white" />
                  </div>
                </div>
                <div className="text-center text-[10px] text-white font-mono tracking-widest uppercase">
                  EVERLOOM ARTISAN
                </div>
                <div className="flex justify-between items-end">
                  <div className="w-10 h-10 border-4 border-white bg-[#241E19] flex items-center justify-center">
                    <div className="w-4 h-4 bg-white" />
                  </div>
                  <div className="w-8 h-8 bg-white/30 rounded" />
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-bold text-xs text-[#241E19] truncate">{qrTargetItem.title}</h4>
              <p className="text-[11px] text-[#7A6B5D] mt-0.5">
                Scan this QR at handicraft fairs or craft pop-ups to open public verified provenance without exposing private artisan credentials.
              </p>
            </div>

            <button
              onClick={() => {
                navigator.clipboard?.writeText(window.location.origin + `/gallery?item=${qrTargetItem.id}`);
                alert('Public catalogue link copied to clipboard!');
              }}
              className="w-full py-2.5 rounded-xl bg-[#B84A2A] text-white text-xs font-bold hover:bg-[#9E3A1C] shadow-sm flex items-center justify-center gap-2"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Copy Public Exhibition Link</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
