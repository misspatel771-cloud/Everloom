import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import backendApp from './backend/src/app.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Robust resolution for ESM/CJS default export
const app: express.Express = (backendApp as any).use
  ? (backendApp as any)
  : (backendApp as any).default || backendApp;

async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0' },
      appType: 'spa',
    });
    // Mount Vite dev server middlewares for client-side assets & HMR
    app.use(vite.middlewares);
  } else {
    // Production static files serving
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Everloom Platform] Full-stack application running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start Everloom full-stack server:', err);
  process.exit(1);
});
