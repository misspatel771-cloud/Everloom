import React, { useEffect, useState } from 'react';
import { Package, Plus, Minus, AlertCircle, Check, Edit2, RefreshCw } from 'lucide-react';
import { api } from '../../../api/client.ts';
import { Product } from '../../../types';

export const InventoryModule: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState<string | null>(null);
  const [editPriceId, setEditPriceId] = useState<string | null>(null);
  const [tempPrice, setTempPrice] = useState<number>(0);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const res = await api.products.list();
      setProducts(res.products || []);
    } catch (err) {
      console.error('Failed to load inventory:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleStockDelta = async (product: Product, delta: number) => {
    const newQty = Math.max(0, product.stockQuantity + delta);
    setSavingId(product.id);
    try {
      await api.products.updateStock(product.id, {
        stockQuantity: newQty,
        isAvailable: newQty > 0
      });
      setProducts(prev =>
        prev.map(p => (p.id === product.id ? { ...p, stockQuantity: newQty, isAvailable: newQty > 0 } : p))
      );
      showFeedback(`Stock updated for "${product.title}" (${newQty} units)`);
    } catch (err: any) {
      alert(`Failed to update stock: ${err.message}`);
    } finally {
      setSavingId(null);
    }
  };

  const handleToggleAvailability = async (product: Product) => {
    const newAvail = !product.isAvailable;
    setSavingId(product.id);
    try {
      await api.products.updateStock(product.id, { isAvailable: newAvail });
      setProducts(prev =>
        prev.map(p => (p.id === product.id ? { ...p, isAvailable: newAvail } : p))
      );
      showFeedback(`Availability set to ${newAvail ? 'Available' : 'Paused'}`);
    } catch (err: any) {
      alert(`Failed to update availability: ${err.message}`);
    } finally {
      setSavingId(null);
    }
  };

  const handleSavePrice = async (productId: string) => {
    if (tempPrice <= 0) return;
    setSavingId(productId);
    try {
      await api.products.update(productId, { price: tempPrice });
      setProducts(prev =>
        prev.map(p => (p.id === productId ? { ...p, price: tempPrice } : p))
      );
      setEditPriceId(null);
      showFeedback('Price updated successfully');
    } catch (err: any) {
      alert(`Failed to update price: ${err.message}`);
    } finally {
      setSavingId(null);
    }
  };

  const showFeedback = (msg: string) => {
    setFeedbackMsg(msg);
    setTimeout(() => setFeedbackMsg(null), 3000);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#B84A2A] border-t-transparent" />
      </div>
    );
  }

  const totalStock = products.reduce((acc, p) => acc + p.stockQuantity, 0);
  const lowStockCount = products.filter(p => p.stockQuantity <= 2).length;

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold font-serif-heritage text-[#241E19]">
            Inventory & Stock Manager
          </h2>
          <p className="text-xs text-[#7A6B5D] mt-1">
            Track handmade creation availability, manage unit stock counts, and update fair-trade pricing.
          </p>
        </div>
        <button
          onClick={fetchProducts}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-[#E8DFC8] text-xs font-semibold text-[#4A3E33] hover:bg-[#FAF7F2] transition-colors self-start"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Stock</span>
        </button>
      </div>

      {feedbackMsg && (
        <div className="p-3 rounded-xl bg-[#2D5A43]/10 border border-[#2D5A43]/30 text-[#2D5A43] text-xs font-semibold flex items-center gap-2 animate-fadeIn">
          <Check className="w-4 h-4" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* Stock summary badges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Total Handmade Units</span>
          <p className="text-2xl font-bold text-[#241E19] mt-1">{totalStock}</p>
        </div>
        <div className="p-4 rounded-xl bg-white border border-[#E8DFC8] shadow-sm">
          <span className="text-xs font-semibold text-[#7A6B5D] uppercase tracking-wider">Unique Items</span>
          <p className="text-2xl font-bold text-[#241E19] mt-1">{products.length}</p>
        </div>
        <div className="p-4 rounded-xl bg-[#FFFBF0] border border-[#F3E1B8] shadow-sm">
          <span className="text-xs font-bold text-[#A86E14] uppercase tracking-wider">Low Stock Attention</span>
          <p className="text-2xl font-bold text-[#A86E14] mt-1">{lowStockCount} items</p>
        </div>
      </div>

      {/* Products table */}
      <div className="bg-white rounded-2xl border border-[#E8DFC8] shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#FAF7F2] border-b border-[#E8DFC8] text-[#7A6B5D] font-semibold uppercase tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Creation & Photo</th>
                <th className="py-3.5 px-4">Category & Placement</th>
                <th className="py-3.5 px-4">Price (₹)</th>
                <th className="py-3.5 px-4">Units in Stock</th>
                <th className="py-3.5 px-4">Availability</th>
                <th className="py-3.5 px-4 text-right">Quick Stock Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F0EAE1]">
              {products.map((product) => {
                const isLow = product.stockQuantity <= 2;
                const isSaving = savingId === product.id;

                return (
                  <tr key={product.id} className="hover:bg-[#FAF7F2]/60 transition-colors">
                    {/* Item photo & title */}
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={product.images[0] || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=200&auto=format&fit=crop&q=80'}
                          alt={product.title}
                          className="w-12 h-12 rounded-lg object-cover border border-[#E8DFC8]"
                        />
                        <div className="max-w-[220px]">
                          <span className="font-bold text-sm text-[#241E19] line-clamp-1 block">
                            {product.title}
                          </span>
                          <span className="text-[11px] text-[#7A6B5D] block">
                            SKU: {product.variants[0]?.sku || `EVR-${product.id.slice(-4)}`}
                          </span>
                          {product.variants.length > 1 && (
                            <span className="text-[10px] text-[#B84A2A] font-semibold">
                              {product.variants.length} variants
                            </span>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Category & placement */}
                    <td className="py-4 px-4">
                      <span className="font-medium text-[#3A2E24] block">{product.craftCategory}</span>
                      <span className="inline-block mt-1 text-[10px] px-2 py-0.5 rounded font-bold uppercase bg-[#E8DFC8]/60 text-[#5A4D42]">
                        {product.placement}
                      </span>
                    </td>

                    {/* Price edit */}
                    <td className="py-4 px-4">
                      {editPriceId === product.id ? (
                        <div className="flex items-center gap-1.5">
                          <input
                            type="number"
                            value={tempPrice}
                            onChange={(e) => setTempPrice(Number(e.target.value))}
                            className="w-20 px-2 py-1 rounded border border-[#B84A2A] text-xs font-bold"
                          />
                          <button
                            onClick={() => handleSavePrice(product.id)}
                            className="p-1 rounded bg-[#B84A2A] text-white hover:bg-[#9E3A1C]"
                            title="Save Price"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-[#241E19]">
                            ₹{product.price.toLocaleString('en-IN')}
                          </span>
                          <button
                            onClick={() => {
                              setEditPriceId(product.id);
                              setTempPrice(product.price);
                            }}
                            className="text-[#7A6B5D] hover:text-[#B84A2A]"
                            title="Edit Price"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </td>

                    {/* Current Stock */}
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <span className="text-base font-bold text-[#241E19]">
                          {product.stockQuantity}
                        </span>
                        {isLow && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-[#FFFBF0] text-[#A86E14] border border-[#F3E1B8] flex items-center gap-1">
                            <AlertCircle className="w-2.5 h-2.5" /> Low
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Availability toggle */}
                    <td className="py-4 px-4">
                      <button
                        onClick={() => handleToggleAvailability(product)}
                        disabled={isSaving}
                        className={`px-2.5 py-1 rounded-full text-[11px] font-bold uppercase transition-colors ${
                          product.isAvailable && product.stockQuantity > 0
                            ? 'bg-[#2D5A43]/10 text-[#2D5A43] border border-[#2D5A43]/30 hover:bg-[#2D5A43]/20'
                            : 'bg-[#9E2A2B]/10 text-[#9E2A2B] border border-[#9E2A2B]/30 hover:bg-[#9E2A2B]/20'
                        }`}
                      >
                        {product.isAvailable && product.stockQuantity > 0 ? 'Active' : 'Paused / OOS'}
                      </button>
                    </td>

                    {/* Stock adjustments (+ / -) */}
                    <td className="py-4 px-4 text-right">
                      <div className="inline-flex items-center gap-1.5 bg-[#FAF7F2] p-1 rounded-lg border border-[#E8DFC8]">
                        <button
                          onClick={() => handleStockDelta(product, -1)}
                          disabled={isSaving || product.stockQuantity <= 0}
                          className="w-7 h-7 rounded flex items-center justify-center bg-white border border-[#D5C9B3] hover:bg-[#EFE7DC] disabled:opacity-40"
                          title="Decrease 1 unit"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-8 text-center font-bold text-xs">{product.stockQuantity}</span>
                        <button
                          onClick={() => handleStockDelta(product, 1)}
                          disabled={isSaving}
                          className="w-7 h-7 rounded flex items-center justify-center bg-white border border-[#D5C9B3] hover:bg-[#EFE7DC] disabled:opacity-40"
                          title="Add 1 unit"
                        >
                          <Plus className="w-3.5 h-3.5 text-[#2D5A43]" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
